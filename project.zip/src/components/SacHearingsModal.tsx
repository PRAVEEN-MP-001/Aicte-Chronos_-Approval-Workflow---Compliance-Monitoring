import React, { useState } from 'react';
import { SacHearing, Application } from '../types';
import { Scale, ShieldCheck, X, CheckCircle2, AlertOctagon, FileText } from 'lucide-react';
import { formatDateIndian } from '../utils/date';

interface SacHearingsModalProps {
  hearing: SacHearing;
  application?: Application;
  onClose: () => void;
  onSubmitVerdict: (
    hearingId: string,
    verdict: SacHearing['verdict'],
    minutes: string,
    officerRemarks: string
  ) => void;
}

export const SacHearingsModal: React.FC<SacHearingsModalProps> = ({
  hearing,
  application,
  onClose,
  onSubmitVerdict,
}) => {
  const [verdict, setVerdict] = useState<SacHearing['verdict']>(hearing.verdict === 'PENDING' ? 'CONDITIONAL_APPROVAL_WITH_UNDERTAKING' : hearing.verdict);
  const [minutes, setMinutes] = useState(
    hearing.hearingMinutes || 
    'The Standing Appellate Committee heard the Principal and Dean of the institution. Perusal of sanctioned staff roster reveals adjunct faculty engagement in compliance with AICTE norms. Committee resolves to grant conditional approval subject to faculty recruitment undertaking within 90 days.'
  );
  const [officerRemarks, setOfficerRemarks] = useState(
    'Recorded as per proceedings of the Standing Appellate Committee held at AICTE HQ, New Delhi.'
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!minutes.trim()) {
      alert('Formal hearing minutes are mandatory.');
      return;
    }
    onSubmitVerdict(hearing.id, verdict, minutes, officerRemarks);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl max-w-2xl w-full border border-slate-300 overflow-hidden text-slate-800 animate-in fade-in zoom-in-95 duration-150 text-xs">
        
        {/* Header */}
        <div className="bg-[#0A192F] text-white px-5 py-4 flex items-center justify-between border-b border-amber-500/30">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-amber-500/20 border border-amber-500/40 rounded text-amber-300">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs uppercase tracking-wider font-semibold text-amber-300">
                AICTE Standing Appellate Committee (SAC) • APH Clause 1.11
              </span>
              <h3 className="font-bold text-base text-white">
                Appellate Hearing Docket #{hearing.id}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 max-h-[80vh] overflow-y-auto">
          
          <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded border border-slate-200">
            <div>
              <span className="text-slate-500 block">Appellant Institution:</span>
              <span className="font-bold text-slate-900 text-sm">{hearing.institutionName}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Hearing Date &amp; Bench:</span>
              <span className="font-mono-code font-bold text-slate-900">{formatDateIndian(hearing.hearingDate)}</span>
            </div>
          </div>

          {/* Committee Roster */}
          <div className="border border-slate-200 rounded p-3 bg-white space-y-1.5">
            <span className="font-bold text-slate-800 uppercase tracking-wider text-[11px] block">
              Constituted SAC Appellate Bench:
            </span>
            <ul className="space-y-1 text-slate-700">
              {hearing.committeeMembers.map((m, idx) => (
                <li key={idx} className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-900" />
                  <span>{m}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Appeal Grounds */}
          <div>
            <span className="font-bold text-slate-700 block mb-1">Grounds of Appeal / Scrutiny Representation:</span>
            <p className="p-2.5 bg-slate-50 border border-slate-200 rounded text-slate-800 leading-relaxed">
              {hearing.appealGrounds}
            </p>
          </div>

          {/* Verdict Selector */}
          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Statutory Committee Verdict:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              
              <button
                type="button"
                onClick={() => setVerdict('APPEAL_UPHELD_APPROVAL_GRANTED')}
                className={`p-2.5 rounded border text-left transition-all cursor-pointer ${
                  verdict === 'APPEAL_UPHELD_APPROVAL_GRANTED'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-950 ring-2 ring-emerald-500/30'
                    : 'border-slate-300 hover:border-slate-400 bg-white'
                }`}
              >
                <span className="font-bold block text-emerald-800">Appeal Upheld</span>
                <span className="text-[10px] text-slate-500">Unconditional approval granted</span>
              </button>

              <button
                type="button"
                onClick={() => setVerdict('CONDITIONAL_APPROVAL_WITH_UNDERTAKING')}
                className={`p-2.5 rounded border text-left transition-all cursor-pointer ${
                  verdict === 'CONDITIONAL_APPROVAL_WITH_UNDERTAKING'
                    ? 'border-blue-600 bg-blue-50 text-blue-950 ring-2 ring-blue-500/30'
                    : 'border-slate-300 hover:border-slate-400 bg-white'
                }`}
              >
                <span className="font-bold block text-blue-800">Conditional Approval</span>
                <span className="text-[10px] text-slate-500">Subject to time-bound undertaking</span>
              </button>

              <button
                type="button"
                onClick={() => setVerdict('APPEAL_DISMISSED_NO_ADMISSION')}
                className={`p-2.5 rounded border text-left transition-all cursor-pointer ${
                  verdict === 'APPEAL_DISMISSED_NO_ADMISSION'
                    ? 'border-red-600 bg-red-50 text-red-950 ring-2 ring-red-500/30'
                    : 'border-slate-300 hover:border-slate-400 bg-white'
                }`}
              >
                <span className="font-bold block text-red-800">Appeal Dismissed</span>
                <span className="text-[10px] text-slate-500">No Admission category</span>
              </button>

            </div>
          </div>

          {/* Hearing Minutes */}
          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
              Formal Hearing Proceedings &amp; Findings:
            </label>
            <textarea
              value={minutes}
              onChange={(e) => setMinutes(e.target.value)}
              rows={3}
              className="w-full p-2.5 border border-slate-300 rounded text-slate-900 bg-white"
              required
            />
          </div>

          {/* Footer buttons */}
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 rounded text-slate-700 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white rounded font-bold shadow-sm cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span>Seal SAC Verdict &amp; Inscribe into Ledger</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
