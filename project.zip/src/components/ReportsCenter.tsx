import React, { useState } from 'react';
import { Application, AuditLogEntry, DeadlineObligation, EvcInspection, InstitutionalUndertaking, RegionalPerformance } from '../types';
import { 
  Printer, Download, FileSpreadsheet, FileText, CheckCircle2, 
  ShieldCheck, Layers, MapPin, AlertTriangle, Eye, Lock 
} from 'lucide-react';
import { formatDateIndian, formatDateTimeIndian } from '../utils/date';
import { IndiaEmblemSvg, AicteEmblemSvg } from './Emblems';
import { INITIAL_REGIONAL_PERFORMANCE } from '../data/mockData';

interface ReportsCenterProps {
  applications: Application[];
  deadlines: DeadlineObligation[];
  evcQueue: EvcInspection[];
  undertakings: InstitutionalUndertaking[];
  auditLogs: AuditLogEntry[];
  currentSimulatedDate: string;
}

export const ReportsCenter: React.FC<ReportsCenterProps> = ({
  applications,
  deadlines,
  evcQueue,
  undertakings,
  auditLogs,
  currentSimulatedDate,
}) => {
  const [selectedReport, setSelectedReport] = useState<'PENDENCY' | 'REGIONAL' | 'EVC' | 'UNDERTAKINGS' | 'AUDIT_CERT'>('PENDENCY');

  const handlePrint = () => {
    window.print();
  };

  const handleExportCsv = (reportName: string) => {
    let csvContent = "data:text/csv;charset=utf-8,";
    
    if (selectedReport === 'PENDENCY') {
      csvContent += "Application No,Institution Name,Region,Type,Route Pattern,Stage,Status,Dwell Days,SLA Days\n";
      applications.forEach(a => {
        csvContent += `"${a.applicationNo}","${a.institutionName}","${a.region}","${a.type}","${a.routePattern}","${a.stage}","${a.status}",${a.daysInCurrentStage},${a.statutorySlaDays}\n`;
      });
    } else if (selectedReport === 'REGIONAL') {
      csvContent += "Region,Total Apps,Cleared,Active Pending,Overdue,Avg Days,Compliance Score\n";
      INITIAL_REGIONAL_PERFORMANCE.forEach(r => {
        csvContent += `"${r.region}",${r.totalApplications},${r.clearedCount},${r.pendingCount},${r.overdueCount},${r.avgProcessingDays},${r.complianceScore}%\n`;
      });
    } else if (selectedReport === 'UNDERTAKINGS') {
      csvContent += "ID,Institution,Clause,Title,Due Date,Status,Penalty Accrued\n";
      undertakings.forEach(u => {
        csvContent += `"${u.id}","${u.institutionName}","${u.clause}","${u.title}","${u.dueDate}","${u.verificationStatus}",${u.penaltyAccrued}\n`;
      });
    } else {
      csvContent += "Block No,Timestamp,Actor,Role,Action,Entity,SHA256 Hash\n";
      auditLogs.forEach(l => {
        csvContent += `${l.blockIndex},"${l.timestamp}","${l.actor}","${l.role}","${l.action}","${l.entityName}","${l.hash}"\n`;
      });
    }

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `AICTE_Chronos_${reportName}_${currentSimulatedDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-[#0A192F] text-white rounded-lg p-5 border border-amber-500/30 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono-code font-bold uppercase text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded border border-amber-500/30">
                Module F • Gazette &amp; Statutory Reporting
              </span>
              <span className="text-[10px] bg-blue-900 text-blue-200 px-2 py-0.5 rounded">
                Section 10(k), AICTE Act 1987
              </span>
            </div>
            <h3 className="text-base font-bold text-white mt-1 flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-amber-400" />
              <span>Consolidated Statutory Reports &amp; National Audit Center</span>
            </h3>
            <p className="text-xs text-slate-300 mt-0.5">
              Generate formatted gazette reports on application pendency, EVC scheduling, undertaking compliance, and Section 65B cryptographic audit certificates.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => handleExportCsv(selectedReport)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded text-xs font-semibold border border-slate-600 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-amber-400" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white rounded text-xs font-bold transition-colors cursor-pointer shadow-sm"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Gazette Report</span>
            </button>
          </div>
        </div>
      </div>

      {/* Report Selection Tabs */}
      <div className="bg-white rounded-lg border border-slate-200 p-2 shadow-sm flex flex-wrap gap-1.5 text-xs">
        <button
          onClick={() => setSelectedReport('PENDENCY')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded font-semibold transition-colors cursor-pointer ${
            selectedReport === 'PENDENCY'
              ? 'bg-blue-900 text-white shadow-xs'
              : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>1. Application Pendency &amp; Ageing</span>
        </button>

        <button
          onClick={() => setSelectedReport('REGIONAL')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded font-semibold transition-colors cursor-pointer ${
            selectedReport === 'REGIONAL'
              ? 'bg-blue-900 text-white shadow-xs'
              : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          <MapPin className="w-3.5 h-3.5" />
          <span>2. Regional Office Processing Scorecard</span>
        </button>

        <button
          onClick={() => setSelectedReport('EVC')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded font-semibold transition-colors cursor-pointer ${
            selectedReport === 'EVC'
              ? 'bg-blue-900 text-white shadow-xs'
              : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Eye className="w-3.5 h-3.5" />
          <span>3. EVC Inspection Queue Gazette</span>
        </button>

        <button
          onClick={() => setSelectedReport('UNDERTAKINGS')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded font-semibold transition-colors cursor-pointer ${
            selectedReport === 'UNDERTAKINGS'
              ? 'bg-blue-900 text-white shadow-xs'
              : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>4. Time-Bound Undertakings Ledger</span>
        </button>

        <button
          onClick={() => setSelectedReport('AUDIT_CERT')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded font-semibold transition-colors cursor-pointer ${
            selectedReport === 'AUDIT_CERT'
              ? 'bg-blue-900 text-white shadow-xs'
              : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          <span>5. Section 65B SHA-256 Audit Certificate</span>
        </button>
      </div>

      {/* Gazette Report Formatted Document Canvas */}
      <div className="bg-white rounded-lg border border-slate-300 shadow-md p-6 sm:p-8 text-xs space-y-6 printable-document">
        
        {/* Official Letterhead Header */}
        <div className="text-center border-b-2 border-slate-900 pb-4 space-y-1">
          <div className="flex justify-center items-center gap-3 mb-2">
            <IndiaEmblemSvg className="w-8 h-10 text-slate-900" />
            <AicteEmblemSvg className="w-9 h-9 text-slate-900" />
          </div>
          <h2 className="font-bold text-base uppercase tracking-wider text-slate-900 font-serif">
            ALL INDIA COUNCIL FOR TECHNICAL EDUCATION
          </h2>
          <p className="text-[11px] font-semibold text-slate-700">
            (A Statutory Body under Ministry of Education, Govt. of India) • Nelson Mandela Marg, Vasant Kunj, New Delhi-110070
          </p>
          <div className="inline-block px-3 py-0.5 bg-slate-100 border border-slate-300 rounded font-mono-code text-[11px] font-bold text-slate-800 mt-1">
            AICTE CHRONOS STATUTORY GAZETTE BULLETIN • AY 2026-27
          </div>
          <div className="flex justify-between items-center text-[10px] text-slate-500 pt-2 font-mono-code">
            <span>Gazette Ref: AICTE/CHRONOS/HQ/2026-27</span>
            <span>Ledger Date: {formatDateIndian(currentSimulatedDate)}</span>
            <span>Authentication: SHA-256 Hash Chained</span>
          </div>
        </div>

        {/* Report 1: Pendency & Ageing */}
        {selectedReport === 'PENDENCY' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-sm text-slate-900 uppercase">
                1. Stage-wise Application Pendency &amp; Ageing Analysis
              </h3>
              <span className="font-mono-code text-slate-500">Total Docket: {applications.length} Records</span>
            </div>

            <table className="w-full text-left text-xs divide-y divide-slate-300 border border-slate-200">
              <thead className="bg-slate-100 font-bold uppercase text-[10px] text-slate-700">
                <tr>
                  <th className="p-2">Application No</th>
                  <th className="p-2">Institution Name</th>
                  <th className="p-2">Region</th>
                  <th className="p-2">Route Pattern</th>
                  <th className="p-2">Current Stage</th>
                  <th className="p-2">Days / SLA</th>
                  <th className="p-2 text-right">Ageing Flag</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {applications.map(a => {
                  const isBreached = a.daysInCurrentStage > a.statutorySlaDays;
                  return (
                    <tr key={a.id}>
                      <td className="p-2 font-mono-code font-bold text-blue-950">{a.applicationNo}</td>
                      <td className="p-2 font-semibold text-slate-900">{a.institutionName}</td>
                      <td className="p-2">{a.region}</td>
                      <td className="p-2 font-mono-code text-[10px]">{a.routePattern}</td>
                      <td className="p-2 font-bold">{a.stage}</td>
                      <td className="p-2 font-mono-code">{a.daysInCurrentStage}d / {a.statutorySlaDays}d</td>
                      <td className="p-2 text-right">
                        <span className={`font-bold px-1.5 py-0.5 rounded text-[10px] ${
                          isBreached ? 'bg-red-100 text-red-900' : 'bg-emerald-100 text-emerald-900'
                        }`}>
                          {isBreached ? 'SLA OVERDUE' : 'COMPLIANT'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Report 2: Regional Performance Scorecard */}
        {selectedReport === 'REGIONAL' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-sm text-slate-900 uppercase">
                2. Regional Offices Processing Velocity &amp; Compliance Index
              </h3>
              <span className="font-mono-code text-slate-500">All 7 AICTE Regional Offices</span>
            </div>

            <table className="w-full text-left text-xs divide-y divide-slate-300 border border-slate-200">
              <thead className="bg-slate-100 font-bold uppercase text-[10px] text-slate-700">
                <tr>
                  <th className="p-2">Regional Office</th>
                  <th className="p-2">Total Filings</th>
                  <th className="p-2">Cleared</th>
                  <th className="p-2">Active Pendency</th>
                  <th className="p-2">Overdue Cases</th>
                  <th className="p-2">Avg Processing Days</th>
                  <th className="p-2 text-right">Compliance Index</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {INITIAL_REGIONAL_PERFORMANCE.map(r => (
                  <tr key={r.region}>
                    <td className="p-2 font-bold text-slate-900">{r.region} Region</td>
                    <td className="p-2 font-mono-code">{r.totalApplications}</td>
                    <td className="p-2 font-mono-code text-emerald-800 font-bold">{r.clearedCount}</td>
                    <td className="p-2 font-mono-code">{r.pendingCount}</td>
                    <td className="p-2 font-mono-code text-red-700 font-bold">{r.overdueCount}</td>
                    <td className="p-2 font-mono-code">{r.avgProcessingDays} Days</td>
                    <td className="p-2 font-mono-code font-bold text-right text-blue-900">{r.complianceScore}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Report 3: EVC Queue Gazette */}
        {selectedReport === 'EVC' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-sm text-slate-900 uppercase">
                3. Expert Visit Committee (EVC) On-Site Inspections Roster
              </h3>
              <span className="font-mono-code text-slate-500">{evcQueue.length} Active Inspections</span>
            </div>

            <table className="w-full text-left text-xs divide-y divide-slate-300 border border-slate-200">
              <thead className="bg-slate-100 font-bold uppercase text-[10px] text-slate-700">
                <tr>
                  <th className="p-2">EVC Ref</th>
                  <th className="p-2">Institution</th>
                  <th className="p-2">Scheduled Date</th>
                  <th className="p-2">Committee Chairman</th>
                  <th className="p-2">Status</th>
                  <th className="p-2 text-right">Delay Days</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {evcQueue.map(e => (
                  <tr key={e.id}>
                    <td className="p-2 font-mono-code font-bold text-indigo-900">{e.id}</td>
                    <td className="p-2 font-semibold text-slate-900">{e.institutionName}</td>
                    <td className="p-2 font-mono-code">{e.scheduledDate ? formatDateIndian(e.scheduledDate) : 'Pending'}</td>
                    <td className="p-2">{e.panelChairman}</td>
                    <td className="p-2 font-bold">{e.status}</td>
                    <td className="p-2 font-mono-code text-right font-bold text-red-700">
                      {e.delayDays > 0 ? `+${e.delayDays}d Overdue` : 'On Schedule'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Report 4: Undertakings Ledger */}
        {selectedReport === 'UNDERTAKINGS' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-sm text-slate-900 uppercase">
                4. Institutional Time-Bound Undertakings &amp; Covenants
              </h3>
              <span className="font-mono-code text-slate-500">{undertakings.length} Undertakings</span>
            </div>

            <table className="w-full text-left text-xs divide-y divide-slate-300 border border-slate-200">
              <thead className="bg-slate-100 font-bold uppercase text-[10px] text-slate-700">
                <tr>
                  <th className="p-2">Ref ID &amp; Clause</th>
                  <th className="p-2">Institution</th>
                  <th className="p-2">Covenant Subject</th>
                  <th className="p-2">Due Date</th>
                  <th className="p-2">Evidence Status</th>
                  <th className="p-2 text-right">Verification</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {undertakings.map(u => (
                  <tr key={u.id}>
                    <td className="p-2 font-mono-code font-bold">{u.id}<br/><span className="text-[10px] font-normal text-slate-500">{u.clause}</span></td>
                    <td className="p-2 font-semibold">{u.institutionName}</td>
                    <td className="p-2">{u.title}</td>
                    <td className="p-2 font-mono-code">{formatDateIndian(u.dueDate)}</td>
                    <td className="p-2 font-mono-code text-[10px]">{u.submittedEvidenceDoc || 'Pending upload'}</td>
                    <td className="p-2 font-bold text-right">
                      <span className={`px-2 py-0.5 rounded text-[10px] ${
                        u.verificationStatus === 'VERIFIED_COMPLIANT' ? 'bg-emerald-100 text-emerald-900' :
                        'bg-amber-100 text-amber-900'
                      }`}>
                        {u.verificationStatus}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Report 5: Section 65B Audit Certificate */}
        {selectedReport === 'AUDIT_CERT' && (
          <div className="space-y-4 bg-slate-50/60 p-5 rounded border border-slate-300">
            <div className="text-center space-y-1">
              <ShieldCheck className="w-8 h-8 text-emerald-700 mx-auto" />
              <h3 className="font-bold text-sm uppercase tracking-wide text-slate-900 font-serif">
                CERTIFICATE OF ELECTRONIC EVIDENCE UNDER SECTION 65B
              </h3>
              <p className="text-[11px] text-slate-600">
                (Indian Evidence Act, 1872 / Bharatiya Sakshya Adhiniyam, 2023)
              </p>
            </div>

            <div className="text-slate-800 space-y-2 leading-relaxed text-[11px]">
              <p>
                1. This is to certify that the computer output containing approval stage transitions, officer human-gate verifications, and compliance logs produced by the <strong>AICTE Chronos Engine</strong> is an authentic, untampered record of statutory proceedings.
              </p>
              <p>
                2. The computer system was operating regularly during the statutory cycle of Approval Process Handbook 2026-27 under the control of the Competent Authority.
              </p>
              <p>
                3. Each administrative transaction has been cryptographically chained using the <strong>SHA-256 standard</strong> (<code className="font-mono-code">h(n) = SHA-256(h(n-1) || payload)</code>) with Head Block #{auditLogs[auditLogs.length - 1]?.blockIndex} anchored externally to BharatNet National Ledger ID <code className="font-mono-code font-bold">#2026-HQ-AICTE</code>.
              </p>
            </div>

            <div className="p-3 bg-white border border-slate-300 rounded font-mono-code text-[11px] space-y-1">
              <div className="text-slate-500">Current Cryptographic Head Hash:</div>
              <div className="font-bold text-blue-900 break-all">{auditLogs[auditLogs.length - 1]?.hash}</div>
              <div className="text-slate-500 pt-1">Total Validated Sequential Blocks: {auditLogs.length} Blocks</div>
            </div>

            <div className="pt-4 flex justify-between items-end border-t border-slate-200">
              <div className="text-[10px] text-slate-500">
                Generated automatically by Chronos Security Module<br/>
                Server Time: {new Date().toISOString()}
              </div>
              <div className="text-right">
                <div className="font-bold text-slate-900">Dr. R. Sundaram</div>
                <div className="text-slate-600 text-[11px]">Authorized Signatory, Bureau Approval Cell</div>
                <div className="text-slate-500 text-[10px]">AICTE HQ, New Delhi</div>
              </div>
            </div>
          </div>
        )}

        {/* Footer of Gazette */}
        <div className="pt-4 border-t border-slate-300 text-center text-[10px] text-slate-500 font-mono-code">
          This document is generated by the AICTE Chronos Integrated Regulatory Engine. Digital Verification: https://aicte-india.org/chronos/verify
        </div>

      </div>

    </div>
  );
};
