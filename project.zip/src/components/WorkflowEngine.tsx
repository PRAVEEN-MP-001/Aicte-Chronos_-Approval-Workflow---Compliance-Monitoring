import React, { useState } from 'react';
import { Application, ApplicationStage, ApprovalRoutePattern, Institution, Region, UserRole } from '../types';
import { 
  FileCheck2, Search, Filter, ShieldCheck, AlertCircle, Eye, 
  ArrowRight, CheckCircle2, Clock, Building2, ChevronRight, FileText, Layers, X 
} from 'lucide-react';
import { formatDateIndian } from '../utils/date';
import { HumanGateModal } from './HumanGateModal';
import { ApplicationDetailModal } from './ApplicationDetailModal';

interface WorkflowEngineProps {
  applications: Application[];
  institutions: Institution[];
  currentUserRole: UserRole;
  selectedRegion: Region;
  onAdvanceStage: (appId: string, nextStage: ApplicationStage, remarks: string, officerName: string) => void;
  onReturnDeficiency: (appId: string, deficiencyNotes: string, remarks: string, officerName: string) => void;
  onVerifyChecklist: (appId: string, checklist: Application['scrutinyChecklist'], remarks: string, officerName: string) => void;
}

export const WorkflowEngine: React.FC<WorkflowEngineProps> = ({
  applications,
  institutions,
  currentUserRole,
  selectedRegion,
  onAdvanceStage,
  onReturnDeficiency,
  onVerifyChecklist,
}) => {
  const [selectedStageFilter, setSelectedStageFilter] = useState<string>('ALL');
  const [selectedRouteFilter, setSelectedRouteFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeRegionFilter, setActiveRegionFilter] = useState<string>(
    currentUserRole === 'REGIONAL_OFFICE' ? selectedRegion : 'ALL'
  );

  const [activeAppForGate, setActiveAppForGate] = useState<Application | null>(null);
  const [activeAppForDetail, setActiveAppForDetail] = useState<Application | null>(null);
  const [activeAppForCaseSummary, setActiveAppForCaseSummary] = useState<Application | null>(null);

  // APH Stages definition
  const stages: { key: ApplicationStage; label: string; desc: string; aphRef: string }[] = [
    { key: 'SUBMISSION', label: '1. Submission', desc: 'Online SARA Filing', aphRef: 'Chapter I' },
    { key: 'SCRUTINY', label: '2. Scrutiny', desc: 'Document Verification', aphRef: 'APH 1.9' },
    { key: 'EVC_INSPECTION', label: '3. EVC Visit', desc: 'Expert Committee', aphRef: 'APH 1.10' },
    { key: 'SAC_APPROVAL', label: '4. SAC / Bureau', desc: 'Appellate Committee', aphRef: 'APH 1.11' },
    { key: 'ISSUANCE', label: '5. LoA / EoA', desc: 'Final Order Issued', aphRef: 'APH 1.12' },
  ];

  // Stage count tally
  const stageCounts = stages.reduce((acc, s) => {
    acc[s.key] = applications.filter(a => a.stage === s.key).length;
    return acc;
  }, {} as Record<ApplicationStage, number>);

  // Filter applications
  const filteredApps = applications.filter((app) => {
    // Stage filter
    if (selectedStageFilter !== 'ALL' && app.stage !== selectedStageFilter) return false;
    
    // Route pattern filter
    if (selectedRouteFilter !== 'ALL' && app.routePattern !== selectedRouteFilter) return false;

    // Region filter
    if (currentUserRole === 'REGIONAL_OFFICE') {
      if (app.region !== selectedRegion) return false;
    } else if (activeRegionFilter !== 'ALL' && app.region !== activeRegionFilter) {
      return false;
    }

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        app.institutionName.toLowerCase().includes(q) ||
        app.applicationNo.toLowerCase().includes(q) ||
        app.type.toLowerCase().includes(q) ||
        app.region.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      
      {/* Interactive APH Workflow Pipeline Stages */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3 border-b border-slate-100 pb-2">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <FileCheck2 className="w-4 h-4 text-blue-800" />
              <span>APH Approval Lifecycle Pipeline (Approval Process Handbook 2026-27)</span>
            </h3>
            <p className="text-xs text-slate-500">
              Module A: Automated stage transitions with multi-route support (Only Scrutiny, Scrutiny + EVC, EVC + SAC, Only EVC, Full APH).
            </p>
          </div>
          <button
            onClick={() => setSelectedStageFilter('ALL')}
            className={`text-xs px-2.5 py-1 rounded border transition-colors cursor-pointer self-start sm:self-auto ${
              selectedStageFilter === 'ALL'
                ? 'bg-blue-900 text-white border-blue-900 font-semibold'
                : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
            }`}
          >
            Show All ({applications.length})
          </button>
        </div>

        {/* Pipeline stage cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2.5">
          {stages.map((stg, idx) => {
            const count = stageCounts[stg.key] || 0;
            const isSelected = selectedStageFilter === stg.key;
            return (
              <button
                key={stg.key}
                type="button"
                onClick={() => setSelectedStageFilter(stg.key)}
                className={`relative p-3 rounded-lg border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'border-blue-900 bg-blue-50/70 shadow-sm ring-2 ring-blue-800/20'
                    : 'border-slate-200 hover:border-slate-300 bg-slate-50/50 hover:bg-white'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-mono-code font-semibold uppercase text-slate-500">
                      {stg.aphRef}
                    </span>
                    <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                      count > 0 ? 'bg-blue-900 text-white' : 'bg-slate-200 text-slate-600'
                    }`}>
                      {count}
                    </span>
                  </div>
                  <h4 className={`text-xs font-bold leading-tight ${isSelected ? 'text-blue-950' : 'text-slate-800'}`}>
                    {stg.label}
                  </h4>
                  <p className="text-[11px] text-slate-500 mt-0.5 truncate">
                    {stg.desc}
                  </p>
                </div>

                <div className="mt-2.5 pt-1.5 border-t border-slate-200/60 flex items-center justify-between text-[10px] text-slate-400">
                  <span>Step {idx + 1} of 5</span>
                  {idx < 4 && <ChevronRight className="w-3 h-3 text-slate-400" />}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4">
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
          
          {/* Search box */}
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search College, App No (e.g. AICTE-SR), program..."
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-700 bg-slate-50/50"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs">
            {/* Route pattern filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-600 font-medium">Route:</span>
              <select
                value={selectedRouteFilter}
                onChange={(e) => setSelectedRouteFilter(e.target.value)}
                className="p-1.5 border border-slate-300 rounded bg-white font-semibold text-slate-800 focus:outline-none text-xs"
              >
                <option value="ALL">All Route Combinations</option>
                <option value="FULL_APH">Full APH (Scrutiny + EVC + SAC)</option>
                <option value="ONLY_SCRUTINY">Only Scrutiny (Routine EoA)</option>
                <option value="SCRUTINY_PLUS_EVC">Scrutiny + EVC</option>
                <option value="EVC_PLUS_SAC">EVC + SAC/SHC</option>
                <option value="ONLY_EVC">Only EVC</option>
              </select>
            </div>

            {/* Region selector */}
            {currentUserRole !== 'REGIONAL_OFFICE' && (
              <div className="flex items-center gap-1.5">
                <span className="text-slate-600 font-medium">Region:</span>
                <select
                  value={activeRegionFilter}
                  onChange={(e) => setActiveRegionFilter(e.target.value)}
                  className="p-1.5 border border-slate-300 rounded bg-white font-semibold text-slate-800 focus:outline-none text-xs"
                >
                  <option value="ALL">All AICTE Regions</option>
                  <option value="Southern">Southern Region</option>
                  <option value="Northern">Northern Region</option>
                  <option value="Western">Western Region</option>
                  <option value="Eastern">Eastern Region</option>
                  <option value="South-Western">South-Western</option>
                </select>
              </div>
            )}

            <div className="text-slate-500 pl-2">
              Showing <strong className="text-slate-900">{filteredApps.length}</strong> applications
            </div>
          </div>
        </div>

        {/* Application Table */}
        <div className="mt-4 overflow-x-auto border border-slate-200 rounded">
          <table className="w-full text-left text-xs divide-y divide-slate-200">
            <thead className="bg-slate-100/80 text-slate-700 font-bold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-2.5 px-3">Application ID &amp; Institute</th>
                <th className="py-2.5 px-3">Route Pattern</th>
                <th className="py-2.5 px-3">Current APH Stage</th>
                <th className="py-2.5 px-3">Ageing / SLA</th>
                <th className="py-2.5 px-3">Regulatory Status</th>
                <th className="py-2.5 px-3 text-right">Human Gate Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 bg-white">
              {filteredApps.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500 italic">
                    No applications found matching the selected filters.
                  </td>
                </tr>
              ) : (
                filteredApps.map((app) => {
                  const isBreached = app.daysInCurrentStage > app.statutorySlaDays;
                  const percent = Math.min(100, Math.round((app.daysInCurrentStage / app.statutorySlaDays) * 100));

                  return (
                    <tr key={app.id} className="hover:bg-blue-50/40 transition-colors">
                      
                      {/* Institute */}
                      <td className="py-3 px-3">
                        <div className="flex items-start gap-2">
                          <Building2 className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" />
                          <div>
                            <span className="font-bold text-slate-900 hover:text-blue-900 transition-colors">
                              {app.institutionName}
                            </span>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className="font-mono-code text-[11px] text-blue-800 bg-blue-50 px-1.5 py-0.2 rounded border border-blue-200">
                                {app.applicationNo}
                              </span>
                              <span className="text-[11px] text-slate-500">
                                {app.region} • {app.type}
                              </span>
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Route Pattern */}
                      <td className="py-3 px-3">
                        <span className="font-mono-code font-bold text-[10px] bg-slate-100 text-slate-800 px-2 py-0.5 rounded border border-slate-300">
                          {app.routePattern.replace(/_/g, ' ')}
                        </span>
                      </td>

                      {/* Stage */}
                      <td className="py-3 px-3">
                        <span className="font-bold text-slate-900 block text-[11px]">
                          {app.stage}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          Officer: {app.assignedOfficer}
                        </span>
                      </td>

                      {/* Ageing / SLA */}
                      <td className="py-3 px-3">
                        <div className="space-y-1">
                          <div className="flex items-center justify-between font-mono-code text-[11px]">
                            <span className={`font-bold ${isBreached ? 'text-red-600' : 'text-slate-800'}`}>
                              {app.daysInCurrentStage} Days
                            </span>
                            <span className="text-slate-400 text-[10px]">SLA: {app.statutorySlaDays}d</span>
                          </div>
                          <div className="w-24 bg-slate-200 rounded-full h-1.5 overflow-hidden">
                            <div
                              className={`h-full ${
                                isBreached ? 'bg-red-600' :
                                percent >= 70 ? 'bg-amber-500' :
                                'bg-emerald-600'
                              }`}
                              style={{ width: `${percent}%` }}
                            />
                          </div>
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3">
                        <div>
                          <span className={`inline-flex items-center gap-1 font-semibold px-2 py-0.5 rounded text-[11px] border ${
                            app.status === 'UNDER_SCRUTINY' ? 'bg-amber-50 text-amber-900 border-amber-300' :
                            app.status === 'DEFICIENCY_NOTICED' ? 'bg-red-50 text-red-900 border-red-300' :
                            app.status === 'EVC_RECOMMENDED' ? 'bg-indigo-50 text-indigo-900 border-indigo-300' :
                            app.status === 'SAC_PENDING' ? 'bg-purple-50 text-purple-900 border-purple-300' :
                            app.status === 'LOA_ISSUED' ? 'bg-emerald-50 text-emerald-900 border-emerald-300' :
                            'bg-slate-50 text-slate-800 border-slate-300'
                          }`}>
                            {app.status === 'DEFICIENCY_NOTICED' && <AlertCircle className="w-3 h-3 text-red-600" />}
                            {app.status === 'LOA_ISSUED' && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
                            <span>{app.status}</span>
                          </span>

                          {app.deficiencyCount > 0 && (
                            <span className="block text-[10px] text-red-600 font-semibold mt-0.5">
                              ⚠️ {app.deficiencyCount} Deficiency flag active
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {app.electronicCaseSummary && (
                            <button
                              type="button"
                              onClick={() => setActiveAppForCaseSummary(app)}
                              className="p-1.5 text-slate-600 hover:text-blue-900 hover:bg-slate-100 rounded border border-slate-200 transition-colors cursor-pointer"
                              title="Electronic Case Summary"
                            >
                              <FileText className="w-3.5 h-3.5" />
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={() => setActiveAppForDetail(app)}
                            className="p-1.5 text-slate-600 hover:text-blue-900 hover:bg-slate-100 rounded border border-slate-200 transition-colors cursor-pointer"
                            title="Inspect Institutional Dossier"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          <button
                            type="button"
                            onClick={() => setActiveAppForGate(app)}
                            className="flex items-center gap-1 px-2.5 py-1.5 bg-blue-900 hover:bg-blue-800 text-white rounded text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                            title="Enter Officer Human Gate decision interface"
                          >
                            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                            <span>Human Gate</span>
                          </button>
                        </div>
                      </td>

                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Electronic Case Summary Modal */}
      {activeAppForCaseSummary && activeAppForCaseSummary.electronicCaseSummary && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-2xl max-w-xl w-full border border-slate-300 overflow-hidden text-slate-800 animate-in fade-in zoom-in-95 duration-150 text-xs">
            <div className="bg-[#0A192F] text-white px-5 py-4 flex items-center justify-between border-b border-amber-500/30">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-base">Electronic Case Summary (APH 2026-27)</h3>
              </div>
              <button
                onClick={() => setActiveAppForCaseSummary(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-3.5">
              <div>
                <span className="text-slate-500 block">Institution &amp; Application No:</span>
                <span className="font-bold text-slate-900 text-sm">{activeAppForCaseSummary.institutionName}</span>
                <span className="font-mono-code text-blue-900 block">{activeAppForCaseSummary.applicationNo} • Route: {activeAppForCaseSummary.routePattern}</span>
              </div>

              <div className="bg-slate-50 p-3 rounded border border-slate-200 space-y-2">
                <div>
                  <span className="font-bold text-slate-700 block">Cadre Ratio Evaluation:</span>
                  <p className="text-slate-800">{activeAppForCaseSummary.electronicCaseSummary.cadreRatioScore}</p>
                </div>
                <div>
                  <span className="font-bold text-slate-700 block">Land &amp; Built Area Norms:</span>
                  <p className="text-slate-800">{activeAppForCaseSummary.electronicCaseSummary.landAdequacySummary}</p>
                </div>
                <div>
                  <span className="font-bold text-slate-700 block">Financial Endowment / Security Deposit:</span>
                  <p className="text-slate-800">
                    {activeAppForCaseSummary.electronicCaseSummary.financialEndowmentVerified ? '✓ Verified in order' : '⚠️ Pending FDR submission'}
                  </p>
                </div>
                <div>
                  <span className="font-bold text-slate-700 block">Statutory Recommendation:</span>
                  <p className="text-blue-900 font-semibold">{activeAppForCaseSummary.electronicCaseSummary.statutoryRecommendation}</p>
                </div>
              </div>

              <div className="flex justify-between items-center text-[10px] text-slate-500 pt-2 border-t border-slate-200">
                <span>Prepared by: {activeAppForCaseSummary.electronicCaseSummary.officerName}</span>
                <span>Date: {formatDateIndian(activeAppForCaseSummary.electronicCaseSummary.preparedDate)}</span>
              </div>
            </div>

            <div className="bg-slate-50 px-5 py-3 border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveAppForCaseSummary(null)}
                className="px-4 py-1.5 bg-blue-900 text-white rounded text-xs font-semibold cursor-pointer"
              >
                Close Summary
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Human Gate Modal */}
      {activeAppForGate && (
        <HumanGateModal
          application={activeAppForGate}
          currentUserRole={currentUserRole}
          onClose={() => setActiveAppForGate(null)}
          onAdvanceStage={onAdvanceStage}
          onReturnDeficiency={onReturnDeficiency}
          onVerifyChecklist={onVerifyChecklist}
        />
      )}

      {/* Dossier Detail Modal */}
      {activeAppForDetail && (
        <ApplicationDetailModal
          application={activeAppForDetail}
          institution={institutions.find(i => i.id === activeAppForDetail.institutionId)}
          onClose={() => setActiveAppForDetail(null)}
          onOpenHumanGate={() => {
            const app = activeAppForDetail;
            setActiveAppForDetail(null);
            setActiveAppForGate(app);
          }}
        />
      )}

    </div>
  );
};
