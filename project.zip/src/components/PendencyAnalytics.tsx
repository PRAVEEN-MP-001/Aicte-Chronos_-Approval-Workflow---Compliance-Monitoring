import React, { useState } from 'react';
import { Application, RegionalPerformance, Region } from '../types';
import { 
  BarChart3, Clock, AlertTriangle, CheckCircle2, TrendingUp, 
  Building2, MapPin, ShieldCheck, ArrowUpRight, Flame, Layers 
} from 'lucide-react';
import { INITIAL_REGIONAL_PERFORMANCE } from '../data/mockData';

interface PendencyAnalyticsProps {
  applications: Application[];
  selectedRegion: Region;
  onSelectApplication: (app: Application) => void;
}

export const PendencyAnalytics: React.FC<PendencyAnalyticsProps> = ({
  applications,
  selectedRegion,
  onSelectApplication,
}) => {
  const [activeView, setActiveView] = useState<'AGEING' | 'REGIONAL' | 'BOTTLENECKS'>('AGEING');
  const [filterRegion, setFilterRegion] = useState<string>('ALL');

  // Ageing Buckets
  const fastTrackApps = applications.filter(a => a.daysInCurrentStage < 7);
  const approachingCeilingApps = applications.filter(a => a.daysInCurrentStage >= 7 && a.daysInCurrentStage <= a.statutorySlaDays);
  const breachedSlaApps = applications.filter(a => a.daysInCurrentStage > a.statutorySlaDays);

  // Stage breakdown
  const stagesCount = {
    SUBMISSION: applications.filter(a => a.stage === 'SUBMISSION').length,
    SCRUTINY: applications.filter(a => a.stage === 'SCRUTINY').length,
    EVC_INSPECTION: applications.filter(a => a.stage === 'EVC_INSPECTION').length,
    SAC_APPROVAL: applications.filter(a => a.stage === 'SAC_APPROVAL').length,
    ISSUANCE: applications.filter(a => a.stage === 'ISSUANCE').length,
  };

  return (
    <div className="space-y-6">
      
      {/* Top Level Metric Tiles */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        
        {/* Total Active Pendency */}
        <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span className="font-semibold uppercase tracking-wider">Total Active Pipeline</span>
            <Layers className="w-4 h-4 text-blue-700" />
          </div>
          <div className="text-2xl font-bold text-slate-900 font-mono-code">
            {applications.length} Applications
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-1">
            <span>AY 2026-27 Approval Processing</span>
          </div>
        </div>

        {/* SLA Breached Bottlenecks */}
        <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span className="font-semibold uppercase tracking-wider">SLA Overdue Bottlenecks</span>
            <AlertTriangle className="w-4 h-4 text-red-600" />
          </div>
          <div className="text-2xl font-bold text-red-600 font-mono-code">
            {breachedSlaApps.length} Cases
          </div>
          <div className="text-[11px] text-red-700 mt-1 font-medium">
            Exceeded statutory processing SLA days
          </div>
        </div>

        {/* Approaching Ceiling */}
        <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span className="font-semibold uppercase tracking-wider">Warning Window (7–15d)</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-amber-600 font-mono-code">
            {approachingCeilingApps.length} Cases
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Approaching statutory APH threshold
          </div>
        </div>

        {/* National Clearance Index */}
        <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span className="font-semibold uppercase tracking-wider">National Clearance Velocity</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-emerald-700 font-mono-code">
            91.6%
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            On-time stage resolution across 8 ROs
          </div>
        </div>

      </div>

      {/* Main Analytics Hub with View Switcher */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4">
        
        {/* Header and Toggle */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 pb-3 mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-blue-900" />
              <span>Integrated Dashboard: Stage-wise Pendency, Ageing &amp; Regional Performance</span>
            </h3>
            <p className="text-xs text-slate-500">
              Module B compliance analytics covering application movement across all 7 Regional Offices.
            </p>
          </div>

          <div className="flex items-center gap-1.5 self-stretch sm:self-auto">
            <button
              onClick={() => setActiveView('AGEING')}
              className={`px-3 py-1.5 text-xs rounded border transition-colors cursor-pointer ${
                activeView === 'AGEING'
                  ? 'bg-blue-900 text-white border-blue-900 font-semibold'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              Application Ageing
            </button>
            <button
              onClick={() => setActiveView('REGIONAL')}
              className={`px-3 py-1.5 text-xs rounded border transition-colors cursor-pointer ${
                activeView === 'REGIONAL'
                  ? 'bg-blue-900 text-white border-blue-900 font-semibold'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              Regional Scorecards (ROs)
            </button>
            <button
              onClick={() => setActiveView('BOTTLENECKS')}
              className={`px-3 py-1.5 text-xs rounded border transition-colors cursor-pointer ${
                activeView === 'BOTTLENECKS'
                  ? 'bg-blue-900 text-white border-blue-900 font-semibold'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              Stage Bottleneck Heatmap
            </button>
          </div>
        </div>

        {/* View 1: Application Ageing Analysis */}
        {activeView === 'AGEING' && (
          <div className="space-y-5">
            
            {/* Ageing Summary Bar */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              
              <div className="p-3.5 rounded-lg border border-emerald-200 bg-emerald-50/50">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-emerald-950">Fast-Track Zone (&lt; 7 Days)</span>
                  <span className="font-mono-code font-bold bg-white text-emerald-800 px-2 py-0.5 rounded border border-emerald-300">
                    {fastTrackApps.length} Cases
                  </span>
                </div>
                <p className="text-emerald-800 text-[11px]">
                  Applications smoothly transitioning within preliminary scrutiny and scheduling limits.
                </p>
              </div>

              <div className="p-3.5 rounded-lg border border-amber-200 bg-amber-50/50">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-amber-950">Warning Window (8–15 Days)</span>
                  <span className="font-mono-code font-bold bg-white text-amber-800 px-2 py-0.5 rounded border border-amber-300">
                    {approachingCeilingApps.length} Cases
                  </span>
                </div>
                <p className="text-amber-800 text-[11px]">
                  Approaching statutory SLA. Automated reminder pings dispatched to assigned Regional Officers.
                </p>
              </div>

              <div className="p-3.5 rounded-lg border border-red-200 bg-red-50/50">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-red-950">SLA Breached Bottlenecks (&gt; 15 Days)</span>
                  <span className="font-mono-code font-bold bg-white text-red-800 px-2 py-0.5 rounded border border-red-300">
                    {breachedSlaApps.length} Cases
                  </span>
                </div>
                <p className="text-red-800 text-[11px]">
                  Overdue beyond statutory deadline. Triggered L2 Bureau escalation and director scrutiny.
                </p>
              </div>

            </div>

            {/* Individual Applications Ageing Table */}
            <div className="border border-slate-200 rounded overflow-hidden">
              <table className="w-full text-left text-xs divide-y divide-slate-200">
                <thead className="bg-slate-100/80 text-slate-700 font-bold uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="py-2.5 px-3">Application &amp; College</th>
                    <th className="py-2.5 px-3">Route Pattern</th>
                    <th className="py-2.5 px-3">Current Stage</th>
                    <th className="py-2.5 px-3">Days in Stage vs SLA</th>
                    <th className="py-2.5 px-3">Ageing Health</th>
                    <th className="py-2.5 px-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 bg-white">
                  {applications.map((app) => {
                    const isBreached = app.daysInCurrentStage > app.statutorySlaDays;
                    const percent = Math.min(100, Math.round((app.daysInCurrentStage / app.statutorySlaDays) * 100));

                    return (
                      <tr key={app.id} className="hover:bg-slate-50 transition-colors">
                        
                        <td className="py-3 px-3">
                          <span className="font-bold text-slate-900 block">{app.institutionName}</span>
                          <span className="font-mono-code text-[11px] text-blue-800">{app.applicationNo} • {app.region} Region</span>
                        </td>

                        <td className="py-3 px-3">
                          <span className="font-mono-code font-bold text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded border border-slate-200">
                            {app.routePattern.replace(/_/g, ' ')}
                          </span>
                        </td>

                        <td className="py-3 px-3 font-semibold text-slate-800">
                          {app.stage}
                        </td>

                        <td className="py-3 px-3">
                          <div className="space-y-1">
                            <div className="flex justify-between font-mono-code text-[11px]">
                              <span>{app.daysInCurrentStage} Days</span>
                              <span className="text-slate-400">SLA: {app.statutorySlaDays}d</span>
                            </div>
                            <div className="w-28 bg-slate-200 rounded-full h-1.5 overflow-hidden">
                              <div
                                className={`h-full ${
                                  isBreached ? 'bg-red-600' :
                                  percent >= 70 ? 'bg-amber-500' :
                                  'bg-emerald-600'
                                }`}
                                style={{ width: `${percent}%` }}
                              />
                            </div>
                          </div>
                        </td>

                        <td className="py-3 px-3">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                            isBreached ? 'bg-red-100 text-red-900 border border-red-300' :
                            percent >= 70 ? 'bg-amber-100 text-amber-900 border border-amber-300' :
                            'bg-emerald-100 text-emerald-900 border border-emerald-300'
                          }`}>
                            {isBreached ? '🚨 SLA Breached' : percent >= 70 ? '⚠️ Warning Window' : '✓ Normal Ageing'}
                          </span>
                        </td>

                        <td className="py-3 px-3 text-right">
                          <button
                            type="button"
                            onClick={() => onSelectApplication(app)}
                            className="text-xs text-blue-900 hover:text-blue-700 font-semibold underline cursor-pointer"
                          >
                            Inspect Dossier
                          </button>
                        </td>

                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

          </div>
        )}

        {/* View 2: Regional Performance Scorecards */}
        {activeView === 'REGIONAL' && (
          <div className="space-y-4 text-xs">
            <div className="flex items-center justify-between text-slate-600 text-xs">
              <span>Performance ranking across 7 Regional Offices based on statutory processing velocity and compliance:</span>
              <span className="font-mono-code font-bold text-blue-900">National Target SLA: ≤ 15.0 Days</span>
            </div>

            <div className="border border-slate-200 rounded overflow-hidden">
              <table className="w-full text-left text-xs divide-y divide-slate-200">
                <thead className="bg-slate-100/80 text-slate-700 font-bold uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="py-2.5 px-3">Regional Office (RO)</th>
                    <th className="py-2.5 px-3">Total Applications</th>
                    <th className="py-2.5 px-3">Cleared</th>
                    <th className="py-2.5 px-3">Active Pending</th>
                    <th className="py-2.5 px-3">SLA Overdue</th>
                    <th className="py-2.5 px-3">Avg Days / Case</th>
                    <th className="py-2.5 px-3 text-right">Compliance Index</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 bg-white">
                  {INITIAL_REGIONAL_PERFORMANCE.map((ro) => {
                    const isHighCompliance = ro.complianceScore >= 90;

                    return (
                      <tr key={ro.region} className="hover:bg-slate-50 transition-colors">
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-2">
                            <MapPin className="w-4 h-4 text-slate-400" />
                            <span className="font-bold text-slate-900">{ro.region} Regional Office</span>
                          </div>
                        </td>

                        <td className="py-3 px-3 font-mono-code font-semibold text-slate-800">
                          {ro.totalApplications}
                        </td>

                        <td className="py-3 px-3 font-mono-code text-emerald-700 font-bold">
                          {ro.clearedCount}
                        </td>

                        <td className="py-3 px-3 font-mono-code text-slate-700 font-medium">
                          {ro.pendingCount}
                        </td>

                        <td className="py-3 px-3 font-mono-code text-red-600 font-bold">
                          {ro.overdueCount} cases ({ro.evcOverdueCount} EVC)
                        </td>

                        <td className="py-3 px-3 font-mono-code text-slate-800">
                          {ro.avgProcessingDays} Days
                        </td>

                        <td className="py-3 px-3 text-right">
                          <span className={`font-mono-code font-bold px-2 py-0.5 rounded text-[11px] ${
                            isHighCompliance ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' :
                            'bg-amber-100 text-amber-900 border border-amber-300'
                          }`}>
                            {ro.complianceScore}%
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* View 3: Stage Bottleneck Heatmap */}
        {activeView === 'BOTTLENECKS' && (
          <div className="space-y-4 text-xs">
            <p className="text-slate-600">
              Distribution of application dwell time across the 5 APH approval stages. Identifies procedural friction points requiring committee scheduling or additional scrutiny officers:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
              
              <div className="p-3 rounded border border-slate-200 bg-slate-50">
                <span className="text-[10px] font-mono-code text-slate-400 uppercase">Stage 1</span>
                <h4 className="font-bold text-slate-900 text-sm mt-0.5">Submission</h4>
                <div className="text-xl font-bold font-mono-code text-blue-900 mt-2">
                  {stagesCount.SUBMISSION}
                </div>
                <div className="text-[11px] text-slate-500 mt-1">Avg Dwell: 1.2 Days</div>
                <div className="mt-2 text-[10px] text-emerald-700 font-semibold">✓ Automated routing</div>
              </div>

              <div className="p-3 rounded border border-amber-300 bg-amber-50/50">
                <span className="text-[10px] font-mono-code text-amber-600 uppercase">Stage 2</span>
                <h4 className="font-bold text-slate-900 text-sm mt-0.5">Document Scrutiny</h4>
                <div className="text-xl font-bold font-mono-code text-amber-700 mt-2">
                  {stagesCount.SCRUTINY}
                </div>
                <div className="text-[11px] text-slate-600 mt-1">Avg Dwell: 14.8 Days</div>
                <div className="mt-2 text-[10px] text-amber-800 font-semibold">⚠️ 2 Deficiencies active</div>
              </div>

              <div className="p-3 rounded border border-red-300 bg-red-50/50">
                <span className="text-[10px] font-mono-code text-red-600 uppercase">Stage 3</span>
                <h4 className="font-bold text-slate-900 text-sm mt-0.5">EVC Inspection</h4>
                <div className="text-xl font-bold font-mono-code text-red-700 mt-2">
                  {stagesCount.EVC_INSPECTION}
                </div>
                <div className="text-[11px] text-slate-600 mt-1">Avg Dwell: 11.2 Days</div>
                <div className="mt-2 text-[10px] text-red-800 font-semibold">🚨 Panel travel bottleneck</div>
              </div>

              <div className="p-3 rounded border border-slate-200 bg-slate-50">
                <span className="text-[10px] font-mono-code text-slate-400 uppercase">Stage 4</span>
                <h4 className="font-bold text-slate-900 text-sm mt-0.5">SAC / Bureau</h4>
                <div className="text-xl font-bold font-mono-code text-blue-900 mt-2">
                  {stagesCount.SAC_APPROVAL}
                </div>
                <div className="text-[11px] text-slate-500 mt-1">Avg Dwell: 5.4 Days</div>
                <div className="mt-2 text-[10px] text-blue-700 font-semibold">Hearing docket active</div>
              </div>

              <div className="p-3 rounded border border-emerald-300 bg-emerald-50/50">
                <span className="text-[10px] font-mono-code text-emerald-600 uppercase">Stage 5</span>
                <h4 className="font-bold text-slate-900 text-sm mt-0.5">LoA / EoA Issued</h4>
                <div className="text-xl font-bold font-mono-code text-emerald-700 mt-2">
                  {stagesCount.ISSUANCE}
                </div>
                <div className="text-[11px] text-slate-500 mt-1">Avg Dwell: 1.0 Day</div>
                <div className="mt-2 text-[10px] text-emerald-800 font-semibold">✓ Digital seal dispatch</div>
              </div>

            </div>

            <div className="bg-slate-50 p-3 rounded border border-slate-200 text-xs text-slate-700">
              <strong className="text-slate-900">Root-Cause Recommendation:</strong> Expert Visit Committee (EVC) panel scheduling holds the highest delay variance due to convener travel coordination across regional borders. AICTE Chronos auto-scheduling roster recommends prioritizing local tier-1 technical experts to compress inspection scheduling from 12 days to 5 days.
            </div>

          </div>
        )}

      </div>

    </div>
  );
};
