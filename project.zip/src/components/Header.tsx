import React from 'react';
import { UserRole, Region } from '../types';
import { IndiaEmblemSvg, AicteEmblemSvg } from './Emblems';
import { Shield, Clock, Building2, UserCheck, Eye, Sparkles, AlertTriangle } from 'lucide-react';
import { formatDateIndian } from '../utils/date';

interface HeaderProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  selectedRegion: Region;
  onRegionChange: (region: Region) => void;
  simulatedDate: string;
  urgentCount: number;
  breachCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  onRoleChange,
  selectedRegion,
  onRegionChange,
  simulatedDate,
  urgentCount,
  breachCount,
}) => {
  const roles: { id: UserRole; label: string; desc: string; icon: React.ReactNode }[] = [
    {
      id: 'INSTITUTION',
      label: 'Institution View (SARA / PSG Tech)',
      desc: 'College portal for compliance & deed upload',
      icon: <Building2 className="w-4 h-4 text-amber-500" />
    },
    {
      id: 'REGIONAL_OFFICE',
      label: 'Regional Office (RO)',
      desc: 'Regional scrutiny & EVC dispatch gate',
      icon: <Shield className="w-4 h-4 text-blue-500" />
    },
    {
      id: 'BUREAU_OFFICER',
      label: 'AICTE Bureau Officer',
      desc: 'HQ Approval Cell & statutory gates',
      icon: <UserCheck className="w-4 h-4 text-emerald-500" />
    },
    {
      id: 'EVC_CONVENER',
      label: 'EVC Convener / Panel',
      desc: 'Expert Visit Committee field inspections',
      icon: <Eye className="w-4 h-4 text-indigo-500" />
    },
    {
      id: 'HQ_EXECUTIVE',
      label: 'AICTE HQ / Executive',
      desc: 'National audit, blockchain hash ledger',
      icon: <Sparkles className="w-4 h-4 text-purple-500" />
    }
  ];

  const regions: Region[] = [
    'Southern',
    'Northern',
    'Western',
    'Eastern',
    'South-Western',
    'Central',
    'North-Western'
  ];

  return (
    <header className="border-b border-slate-700 bg-[#0A192F] text-slate-100 shadow-md sticky top-0 z-40">
      {/* Tricolor Government Top Strip */}
      <div className="nic-tricolor-bar w-full" />

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          
          {/* Official Branding: Government Emblem + AICTE Crest + Title */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 p-1 bg-white/5 rounded border border-white/10 backdrop-blur-sm">
              <div className="text-amber-400">
                <IndiaEmblemSvg className="w-7 h-9" />
              </div>
              <div className="h-8 w-px bg-white/20" />
              <div className="text-amber-300">
                <AicteEmblemSvg className="w-9 h-9" />
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold tracking-tight text-white flex items-center gap-1.5">
                  <span>AICTE CHRONOS ENGINE</span>
                  <span className="text-[10px] font-mono-code font-normal px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                    SIH 2026 • v4.2 PROD
                  </span>
                </h1>
              </div>
              <p className="text-xs text-slate-300 leading-tight">
                अखिल भारतीय तकनीकी शिक्षा परिषद • Integrated Approval Workflow &amp; Statutory Compliance System
              </p>
            </div>
          </div>

          {/* Right Section: Role Switcher & Clock Badge */}
          <div className="flex flex-wrap items-center gap-2.5">
            
            {/* Live Statutory Alerts summary pill */}
            {(urgentCount > 0 || breachCount > 0) && (
              <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded bg-red-950/70 border border-red-500/40 text-red-300 text-xs font-mono-code">
                <AlertTriangle className="w-3.5 h-3.5 text-red-400 animate-pulse" />
                <span>
                  {breachCount} Hard Breaches | {urgentCount} Urgent
                </span>
              </div>
            )}

            {/* Regional Filter (visible for Regional Office role) */}
            {currentRole === 'REGIONAL_OFFICE' && (
              <div className="flex items-center bg-slate-800/80 border border-blue-500/30 rounded px-2 py-1 text-xs">
                <span className="text-blue-300 mr-1.5 font-medium">RO Region:</span>
                <select
                  value={selectedRegion}
                  onChange={(e) => onRegionChange(e.target.value as Region)}
                  className="bg-transparent text-white font-semibold focus:outline-none cursor-pointer"
                >
                  {regions.map((reg) => (
                    <option key={reg} value={reg} className="bg-slate-900 text-white">
                      {reg} Region
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Simulated Date Quick Pill */}
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-800/90 border border-slate-700 rounded text-xs text-slate-300">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-mono-code text-amber-200 font-medium">
                {formatDateIndian(simulatedDate)}
              </span>
            </div>

            {/* Role Switcher Dropdown */}
            <div className="relative">
              <div className="flex items-center bg-slate-800 border border-amber-500/40 rounded px-2.5 py-1 text-xs shadow-sm hover:border-amber-400 transition-colors">
                <span className="text-slate-400 mr-1 font-medium hidden sm:inline">Role:</span>
                <select
                  value={currentRole}
                  onChange={(e) => onRoleChange(e.target.value as UserRole)}
                  className="bg-transparent text-amber-300 font-semibold focus:outline-none cursor-pointer pr-1"
                >
                  {roles.map((r) => (
                    <option key={r.id} value={r.id} className="bg-slate-900 text-white py-1">
                      {r.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* Official Government Notification Ticker */}
      <div className="bg-[#051124] border-t border-slate-800 px-4 py-1 text-[11px] flex items-center justify-between overflow-hidden">
        <div className="flex items-center gap-2 whitespace-nowrap overflow-hidden">
          <span className="bg-amber-600 text-white font-bold px-1.5 py-0.2 rounded text-[10px] tracking-wider uppercase">
            APH 2026-27 GAZETTE
          </span>
          <span className="text-slate-300 truncate">
            Clause 1.11a (7-Day Hard Limit for Scrutiny Appeals) • Clause 2.25f (Joint FDR 15-day Grace with 10%/20% Penal Escalation) • Clause 2.1e/6.17a (Mandatory Lease Validity Covering Complete Program Tenure).
          </span>
        </div>
        <div className="hidden md:flex items-center gap-3 text-slate-400 shrink-0 text-[11px]">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
            <span>NIC Grid: Online</span>
          </span>
          <span className="text-slate-600">|</span>
          <span className="text-amber-300/80 font-mono-code">SHA-256 Ledger: Live</span>
        </div>
      </div>
    </header>
  );
};
