import React from 'react';
import { FastForward, RotateCcw, Calendar, AlertOctagon, TrendingUp, ShieldAlert } from 'lucide-react';
import { formatDateIndian } from '../utils/date';

interface DemoClockBarProps {
  simulatedDate: string;
  onAdvanceDays: (days: number) => void;
  onResetClock: () => void;
  onSetDate: (dateStr: string) => void;
  baseDate: string;
  daysShifted: number;
}

export const DemoClockBar: React.FC<DemoClockBarProps> = ({
  simulatedDate,
  onAdvanceDays,
  onResetClock,
  onSetDate,
  daysShifted,
}) => {
  return (
    <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 border-b border-amber-500/30 text-white shadow-lg px-4 py-2 text-xs">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-2.5">
        
        {/* Left: Engine indicator and current simulated date */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 px-2.5 py-1 rounded">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
            </span>
            <span className="font-semibold text-amber-300 uppercase tracking-wider text-[11px]">
              Chronos Time-Shift Engine
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-slate-200">
            <Calendar className="w-3.5 h-3.5 text-blue-400" />
            <span>Simulated Ledger Clock:</span>
            <span className="font-mono-code font-bold text-amber-300 text-sm bg-black/40 px-2 py-0.5 rounded border border-slate-700">
              {formatDateIndian(simulatedDate)}
            </span>
            {daysShifted > 0 && (
              <span className="bg-emerald-950 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono-code px-1.5 py-0.5 rounded">
                +{daysShifted} Days Forward
              </span>
            )}
          </div>
        </div>

        {/* Center: Fast-forward triggers and quick testing buttons */}
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-slate-400 text-[11px] mr-1 hidden sm:inline">Statutory Stress Testing:</span>
          
          <button
            onClick={() => onAdvanceDays(1)}
            className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded border border-slate-600 transition-colors cursor-pointer active:scale-95"
            title="Advance 1 Day"
          >
            <FastForward className="w-3 h-3 text-amber-400" />
            <span>+1 Day</span>
          </button>

          <button
            onClick={() => onAdvanceDays(7)}
            className="flex items-center gap-1 px-2.5 py-1 bg-blue-900/60 hover:bg-blue-800 text-blue-200 hover:text-white rounded border border-blue-500/40 transition-colors cursor-pointer active:scale-95"
            title="Fast forward 7 days: triggers DTU APH 1.11a Appeal Expiry"
          >
            <AlertOctagon className="w-3 h-3 text-amber-400" />
            <span className="font-medium">+7 Days (Appeal Limit)</span>
          </button>

          <button
            onClick={() => onAdvanceDays(15)}
            className="flex items-center gap-1 px-2.5 py-1 bg-amber-950/60 hover:bg-amber-900 text-amber-200 hover:text-white rounded border border-amber-500/40 transition-colors cursor-pointer active:scale-95"
            title="Fast forward 15 days: triggers VJTI APH 2.25f 10% penalty!"
          >
            <TrendingUp className="w-3 h-3 text-amber-400" />
            <span className="font-medium">+15 Days (10% Penalty)</span>
          </button>

          <button
            onClick={() => onAdvanceDays(30)}
            className="flex items-center gap-1 px-2.5 py-1 bg-red-950/70 hover:bg-red-900 text-red-200 hover:text-white rounded border border-red-500/40 transition-colors cursor-pointer active:scale-95"
            title="Fast forward 30 days: triggers APH 2.25f 20% penalty & Show-Cause Notice!"
          >
            <ShieldAlert className="w-3 h-3 text-red-400" />
            <span className="font-semibold">+30 Days (20% Hard Breach)</span>
          </button>

          {/* Date input for precise jump */}
          <input
            type="date"
            value={simulatedDate}
            onChange={(e) => {
              if (e.target.value) onSetDate(e.target.value);
            }}
            className="bg-slate-800 text-slate-200 text-[11px] px-2 py-0.5 rounded border border-slate-700 focus:outline-none focus:border-amber-400 cursor-pointer"
          />

          {daysShifted > 0 && (
            <button
              onClick={onResetClock}
              className="flex items-center gap-1 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded border border-slate-600 transition-colors cursor-pointer"
              title="Reset to initial base date"
            >
              <RotateCcw className="w-3 h-3 text-slate-400" />
              <span>Reset</span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
