import React, { useState } from 'react';
import { Institution, OcrDeedResult } from '../types';
import { SAMPLE_OCR_DOCUMENTS } from '../data/mockData';
import { FileText, Upload, CheckCircle2, AlertTriangle, ShieldCheck, Cpu, RefreshCw, X } from 'lucide-react';
import { calculateLeaseCriticalDate, formatDateIndian } from '../utils/date';

interface LeaseEngineModalProps {
  institution: Institution;
  currentSimulatedDate: string;
  onClose: () => void;
  onConfirmLeaseUpdate: (
    instId: string,
    newEndDate: string,
    newSurveyNumber: string,
    officerRemarks: string,
    ocrData: OcrDeedResult
  ) => void;
}

export const LeaseEngineModal: React.FC<LeaseEngineModalProps> = ({
  institution,
  currentSimulatedDate,
  onClose,
  onConfirmLeaseUpdate,
}) => {
  const [selectedSample, setSelectedSample] = useState<string>(SAMPLE_OCR_DOCUMENTS[1].id);
  const [isScanning, setIsScanning] = useState(false);
  const [scanComplete, setScanComplete] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);

  // Extracted data (editable by officer)
  const [extractedData, setExtractedData] = useState({
    lessorName: SAMPLE_OCR_DOCUMENTS[1].extractedData.lessorName,
    lesseeName: SAMPLE_OCR_DOCUMENTS[1].extractedData.lesseeName,
    surveyNumber: SAMPLE_OCR_DOCUMENTS[1].extractedData.surveyNumber,
    leaseStartDate: SAMPLE_OCR_DOCUMENTS[1].extractedData.leaseStartDate,
    leaseEndDate: SAMPLE_OCR_DOCUMENTS[1].extractedData.leaseEndDate,
    totalDurationYears: SAMPLE_OCR_DOCUMENTS[1].extractedData.totalDurationYears,
    confidenceScore: SAMPLE_OCR_DOCUMENTS[1].extractedData.confidenceScore,
    rawSnippet: SAMPLE_OCR_DOCUMENTS[1].extractedData.rawSnippet,
  });

  const [officerRemarks, setOfficerRemarks] = useState(
    'Examined registered supplemental lease deed bearing Sub-Registrar endorsement. Duration validated for 30 years.'
  );
  const [officerAffirmed, setOfficerAffirmed] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Handle sample switch
  const handleSelectSample = (sampleId: string) => {
    const s = SAMPLE_OCR_DOCUMENTS.find(doc => doc.id === sampleId);
    if (!s) return;
    setSelectedSample(sampleId);
    setScanComplete(false);
    setScanProgress(0);
    setExtractedData({ ...s.extractedData });
  };

  // Run simulated Tesseract OCR
  const runSimulatedOcr = () => {
    setIsScanning(true);
    setScanProgress(15);
    setErrorMessage('');

    setTimeout(() => setScanProgress(45), 250);
    setTimeout(() => setScanProgress(75), 550);
    setTimeout(() => {
      setScanProgress(100);
      setIsScanning(false);
      setScanComplete(true);
    }, 850);
  };

  // Calculate critical date
  const criticalCalc = calculateLeaseCriticalDate(
    extractedData.leaseEndDate,
    institution.longestCourseYears
  );

  // Check if critical date is already breached compared to simulated current date
  const isBreached = currentSimulatedDate >= criticalCalc.criticalDate;

  const handleConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!officerAffirmed) {
      setErrorMessage('Mandatory: The Officer must affirmatively attest the OCR output matches the registered deed.');
      return;
    }
    if (!officerRemarks.trim()) {
      setErrorMessage('Mandatory: Officer remarks cannot be blank.');
      return;
    }

    const ocrResult: OcrDeedResult = {
      fileName: SAMPLE_OCR_DOCUMENTS.find(s => s.id === selectedSample)?.name || 'uploaded_deed.pdf',
      ...extractedData,
      calculatedCriticalDate: criticalCalc.criticalDate,
      status: 'CONFIRMED'
    };

    onConfirmLeaseUpdate(
      institution.id,
      extractedData.leaseEndDate,
      extractedData.surveyNumber,
      officerRemarks,
      ocrResult
    );

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-lg shadow-2xl max-w-3xl w-full border border-slate-300 overflow-hidden text-slate-800 animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="bg-[#0A192F] text-white px-5 py-4 flex items-center justify-between border-b border-amber-500/30">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-amber-500/20 border border-amber-500/40 rounded text-amber-300">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs uppercase tracking-wider font-semibold text-amber-300">
                Module D &amp; E • Intelligent OCR Lease Deed Verification
              </span>
              <h3 className="font-bold text-base text-white">
                {institution.name}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current status bar */}
        <div className="bg-slate-100 border-b border-slate-200 px-5 py-2.5 text-xs flex flex-wrap items-center justify-between gap-2">
          <div>
            <span className="text-slate-500">Current Registered Lease Expiry: </span>
            <span className="font-bold text-slate-900 font-mono-code">
              {formatDateIndian(institution.leaseEndDate)}
            </span>
          </div>
          <div>
            <span className="text-slate-500">Longest Course Duration: </span>
            <span className="font-bold text-slate-900">{institution.longestCourseYears} Years</span>
          </div>
          <div>
            <span className="text-slate-500">Simulated Ledger Date: </span>
            <span className="font-mono-code font-bold text-blue-900">
              {formatDateIndian(currentSimulatedDate)}
            </span>
          </div>
        </div>

        <form onSubmit={handleConfirm} className="p-5 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
          
          {/* Step 1: Select or Upload Lease Deed */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              1. Select or Upload Registered Lease Deed / Allotment Order:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {SAMPLE_OCR_DOCUMENTS.map((doc) => {
                const isSelected = selectedSample === doc.id;
                return (
                  <button
                    key={doc.id}
                    type="button"
                    onClick={() => handleSelectSample(doc.id)}
                    className={`p-2.5 rounded border text-left transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'border-blue-900 bg-blue-50 text-blue-950 ring-1 ring-blue-800'
                        : 'border-slate-300 hover:border-slate-400 bg-white text-slate-700'
                    }`}
                  >
                    <div>
                      <span className="font-mono-code font-bold text-[11px] block text-blue-900 truncate">
                        {doc.name}
                      </span>
                      <p className="text-[10px] text-slate-500 mt-1 line-clamp-2">
                        {doc.description}
                      </p>
                    </div>
                    <span className="text-[10px] font-semibold text-slate-400 mt-2 block">
                      Expires: {doc.extractedData.leaseEndDate}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* OCR trigger button */}
            <div className="mt-3 flex items-center justify-between bg-slate-50 p-3 rounded border border-slate-200">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-slate-600" />
                <span className="text-slate-700 font-medium">
                  {SAMPLE_OCR_DOCUMENTS.find(d => d.id === selectedSample)?.name}
                </span>
              </div>
              <button
                type="button"
                onClick={runSimulatedOcr}
                disabled={isScanning}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white rounded text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-amber-300 ${isScanning ? 'animate-spin' : ''}`} />
                <span>{isScanning ? 'Running OCR Extraction...' : 'Execute Tesseract OCR Scan'}</span>
              </button>
            </div>
          </div>

          {/* OCR Scanning Progress Animation */}
          {isScanning && (
            <div className="p-3 bg-blue-50 rounded border border-blue-200 space-y-1.5">
              <div className="flex justify-between text-xs text-blue-900 font-semibold">
                <span>Tesseract Neural OCR Engine Processing Stamp Papers...</span>
                <span>{scanProgress}%</span>
              </div>
              <div className="w-full bg-blue-200 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-blue-900 h-full transition-all duration-300"
                  style={{ width: `${scanProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Step 2: Extracted OCR Proposals & Manual Officer Override */}
          <div className="border border-slate-200 rounded p-3.5 bg-white space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <span className="font-bold text-slate-900 uppercase tracking-wider text-xs flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>2. Extracted Deed Metadata (Editable for Officer Manual Verification)</span>
              </span>
              <span className="font-mono-code text-[11px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Confidence: {extractedData.confidenceScore}%
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">Lessor (Land Owner / Trust):</label>
                <input
                  type="text"
                  value={extractedData.lessorName}
                  onChange={(e) => setExtractedData({ ...extractedData, lessorName: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded text-slate-800 bg-slate-50/50"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Lessee (Institution / Society):</label>
                <input
                  type="text"
                  value={extractedData.lesseeName}
                  onChange={(e) => setExtractedData({ ...extractedData, lesseeName: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded text-slate-800 bg-slate-50/50"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Survey / Khasra Numbers:</label>
                <input
                  type="text"
                  value={extractedData.surveyNumber}
                  onChange={(e) => setExtractedData({ ...extractedData, surveyNumber: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded text-slate-800 bg-slate-50/50 font-mono-code"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Lease Start Date:</label>
                  <input
                    type="date"
                    value={extractedData.leaseStartDate}
                    onChange={(e) => setExtractedData({ ...extractedData, leaseStartDate: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded text-slate-800 bg-slate-50/50 font-mono-code text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Lease End Date:</label>
                  <input
                    type="date"
                    value={extractedData.leaseEndDate}
                    onChange={(e) => setExtractedData({ ...extractedData, leaseEndDate: e.target.value })}
                    className="w-full p-2 border border-blue-500 rounded text-blue-900 bg-blue-50/30 font-mono-code font-bold text-xs"
                  />
                </div>
              </div>
            </div>

            {/* OCR text snippet preview */}
            <div className="bg-slate-50 p-2.5 rounded border border-slate-200">
              <span className="text-[10px] font-semibold text-slate-500 block mb-1">
                Raw OCR Text Stream from Stamp Paper:
              </span>
              <p className="font-mono-code text-[11px] text-slate-700 italic leading-relaxed">
                "{extractedData.rawSnippet}"
              </p>
            </div>
          </div>

          {/* Step 3: Statutory APH 2.1e / 6.17a Mathematical Rule Card */}
          <div className={`p-3.5 rounded border text-xs ${
            isBreached 
              ? 'bg-red-50 border-red-300 text-red-950' 
              : 'bg-emerald-50 border-emerald-300 text-emerald-950'
          }`}>
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-2">
                {isBreached ? (
                  <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                )}
                <span className="font-bold uppercase tracking-wider text-xs">
                  Statutory Rule Engine: APH Clause 2.1e &amp; 6.17a
                </span>
              </div>
              <span className="font-mono-code font-bold text-[11px] px-2 py-0.5 rounded bg-white shadow-2xs">
                Formula: Critical Date = Lease End - Course Duration
              </span>
            </div>

            <div className="mt-2 bg-white/80 p-2.5 rounded border border-current/20 space-y-1">
              <p>
                <strong>Calculation:</strong> Lease End ({extractedData.leaseEndDate}) minus Longest Course ({institution.longestCourseYears} Years) = 
                <strong className="font-mono-code ml-1 text-sm">{criticalCalc.criticalDate}</strong>
              </p>
              {isBreached ? (
                <p className="text-red-700 font-semibold">
                  🚨 CRITICAL ALERT ACTIVE: Simulated date ({currentSimulatedDate}) is ON or PAST the Critical Date ({criticalCalc.criticalDate}). A student enrolling today cannot complete the {institution.longestCourseYears}-year curriculum before lease termination. Renewal required immediately!
                </p>
              ) : (
                <p className="text-emerald-700 font-semibold">
                  ✓ COMPLIANT: Valid through graduation cycle of all enrolled cohorts. Cushion available until {criticalCalc.criticalDate}.
                </p>
              )}
            </div>
          </div>

          {/* Step 4: Officer Affirmation & Remarks */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
              3. Officer Statutory Affirmation &amp; Ledger Notes <span className="text-red-500">*</span>
            </label>
            <textarea
              value={officerRemarks}
              onChange={(e) => {
                setOfficerRemarks(e.target.value);
                if (errorMessage) setErrorMessage('');
              }}
              rows={2}
              className="w-full p-2.5 border border-slate-300 rounded text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-700"
              placeholder="Record details of the Sub-Registrar seal, book number, and registration volume..."
            />

            <div className="bg-amber-50 p-2.5 rounded border border-amber-200 text-amber-950">
              <label className="flex items-start gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={officerAffirmed}
                  onChange={(e) => {
                    setOfficerAffirmed(e.target.checked);
                    if (errorMessage) setErrorMessage('');
                  }}
                  className="mt-0.5 rounded text-amber-600"
                />
                <span className="text-[11px] leading-tight">
                  <strong>Mandatory Human Gate Protocol:</strong> I hereby certify that the OCR extracted parameters have been manually cross-verified against the original registered document copy. The compliance clock will calculate based on this confirmed date.
                </span>
              </label>
            </div>
          </div>

          {errorMessage && (
            <div className="p-2.5 bg-red-100 border border-red-300 text-red-800 text-xs rounded font-medium flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Footer buttons */}
          <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 rounded text-slate-700 hover:bg-slate-100 text-xs font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white rounded text-xs font-bold shadow-sm transition-colors cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>Confirm &amp; Inscribe to Chronos Ledger</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
