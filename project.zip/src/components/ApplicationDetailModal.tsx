import React from 'react';
import { Application, Institution } from '../types';
import { X, Building2, MapPin, Calendar, FileText, CheckCircle2, AlertTriangle, ShieldCheck, Download } from 'lucide-react';
import { formatDateIndian } from '../utils/date';

interface ApplicationDetailModalProps {
  application: Application;
  institution?: Institution;
  onClose: () => void;
  onOpenHumanGate: () => void;
}

export const ApplicationDetailModal: React.FC<ApplicationDetailModalProps> = ({
  application,
  institution,
  onClose,
  onOpenHumanGate,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-lg shadow-2xl max-w-3xl w-full border border-slate-300 overflow-hidden text-slate-800 animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="bg-[#0A192F] text-white px-5 py-4 flex items-center justify-between border-b border-amber-500/30">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-900/60 border border-blue-400/30 rounded text-amber-300">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-mono-code text-amber-300">
                {application.applicationNo} • AY {application.academicYear}
              </span>
              <h3 className="font-bold text-lg text-white">
                {application.institutionName}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
          
          {/* Key Facts Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3.5 rounded-md border border-slate-200">
            <div>
              <span className="text-slate-500 block">Application Type:</span>
              <span className="font-semibold text-slate-900">{application.type}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Region:</span>
              <span className="font-semibold text-slate-900">{application.region} Office</span>
            </div>
            <div>
              <span className="text-slate-500 block">Submission Date:</span>
              <span className="font-mono-code font-medium text-slate-800">
                {formatDateIndian(application.submissionDate)}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Assigned Officer:</span>
              <span className="font-medium text-slate-800">{application.assignedOfficer}</span>
            </div>
          </div>

          {/* Current Stage Card */}
          <div className="border border-slate-200 rounded-md p-3.5 bg-white">
            <h4 className="font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-blue-600" />
              <span>Approval Workflow Status</span>
            </h4>
            <div className="flex items-center justify-between p-2.5 bg-blue-50/60 rounded border border-blue-100">
              <div>
                <span className="text-slate-600 block text-[11px]">Active APH Stage:</span>
                <span className="text-sm font-bold text-blue-900">{application.stage}</span>
              </div>
              <div>
                <span className="text-slate-600 block text-[11px]">Regulatory State:</span>
                <span className={`inline-block font-semibold px-2 py-0.5 rounded text-[11px] ${
                  application.status === 'UNDER_SCRUTINY' ? 'bg-amber-100 text-amber-900 border border-amber-300' :
                  application.status === 'DEFICIENCY_NOTICED' ? 'bg-red-100 text-red-900 border border-red-300' :
                  application.status === 'EVC_RECOMMENDED' ? 'bg-indigo-100 text-indigo-900 border border-indigo-300' :
                  application.status === 'LOA_ISSUED' ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' :
                  'bg-slate-100 text-slate-800 border border-slate-300'
                }`}>
                  {application.status}
                </span>
              </div>
            </div>

            {application.deficiencyNotes && (
              <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded text-red-900">
                <div className="flex items-center gap-1.5 font-bold mb-1">
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                  <span>Flagged Regulatory Deficiency Notice:</span>
                </div>
                <p className="text-xs leading-relaxed">{application.deficiencyNotes}</p>
              </div>
            )}
          </div>

          {/* Institutional Land & Lease Covenants */}
          {institution && (
            <div className="border border-slate-200 rounded-md p-3.5 bg-white">
              <h4 className="font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-amber-600" />
                <span>Land &amp; Statutory Lease Covenants (APH Clause 2.1e / 6.17a)</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded">
                <div>
                  <span className="text-slate-500 block">Registered Survey / Khasra No:</span>
                  <span className="font-semibold text-slate-900">{institution.leaseSurveyNumber}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Total Contiguous Land Area:</span>
                  <span className="font-semibold text-slate-900">{institution.landAreaAcres} Acres (Rural/Urban Norm met)</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Longest Course Duration:</span>
                  <span className="font-semibold text-slate-900">
                    {institution.longestCourseYears} Years ({institution.longestCourseName})
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Registered Lease End Date:</span>
                  <span className={`font-mono-code font-bold ${
                    institution.longestCourseYears === 4 && institution.leaseEndDate.startsWith('2029')
                      ? 'text-red-700 bg-red-100 px-1.5 py-0.5 rounded'
                      : 'text-slate-900'
                  }`}>
                    {formatDateIndian(institution.leaseEndDate)}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Scrutiny Norms Breakdown */}
          <div className="border border-slate-200 rounded-md p-3.5 bg-white">
            <h4 className="font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Scrutiny Verification Checklist (APH Chapter II)</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="flex items-center justify-between p-2 bg-slate-50 rounded border border-slate-100">
                <span>Faculty-to-Student Cadre Ratio</span>
                {application.scrutinyChecklist.facultyRatioOk ? (
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Compliant (1:20)
                  </span>
                ) : (
                  <span className="text-red-700 font-semibold flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" /> Deficit Flagged
                  </span>
                )}
              </div>

              <div className="flex items-center justify-between p-2 bg-slate-50 rounded border border-slate-100">
                <span>Land Norms &amp; Lease Validity</span>
                {application.scrutinyChecklist.landNormsOk ? (
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Compliant
                  </span>
                ) : (
                  <span className="text-red-700 font-semibold flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" /> Lease Cushion Breach
                  </span>
                )}
              </div>

              <div className="flex items-center justify-between p-2 bg-slate-50 rounded border border-slate-100">
                <span>FDR Security Deposit Affidavit</span>
                {application.scrutinyChecklist.fdrDepositOk ? (
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Verified
                  </span>
                ) : (
                  <span className="text-amber-700 font-semibold flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" /> Pending Upload
                  </span>
                )}
              </div>

              <div className="flex items-center justify-between p-2 bg-slate-50 rounded border border-slate-100">
                <span>Instructional &amp; Admin Built Area</span>
                {application.scrutinyChecklist.builtUpAreaOk ? (
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Adequate
                  </span>
                ) : (
                  <span className="text-red-700 font-semibold flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" /> Shortfall
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Dossier Repository (Mocked statutory attachments) */}
          <div className="border border-slate-200 rounded-md p-3.5 bg-white">
            <h4 className="font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-slate-600" />
              <span>Statutory Uploads &amp; Certified Enclosures</span>
            </h4>
            <div className="divide-y divide-slate-100 text-xs">
              <div className="py-2 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-800">Part-1 Institutional Profile &amp; AICTE Approval Order 2025</span>
                  <span className="text-slate-400 block text-[11px]">PDF • Signed by Head of Institution • 4.2 MB</span>
                </div>
                <button
                  type="button"
                  onClick={() => alert(`Simulated Download: ${application.applicationNo}_Part1_Profile.pdf`)}
                  className="flex items-center gap-1 px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs cursor-pointer"
                >
                  <Download className="w-3 h-3" /> Download
                </button>
              </div>

              <div className="py-2 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-800">Part-2 Registered Lease Deed / Government Grant Allotment</span>
                  <span className="text-slate-400 block text-[11px]">Sub-Registrar Certified • Stamp Duty Paid • 8.1 MB</span>
                </div>
                <button
                  type="button"
                  onClick={() => alert(`Simulated Download: ${application.applicationNo}_Lease_Deed.pdf`)}
                  className="flex items-center gap-1 px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs cursor-pointer"
                >
                  <Download className="w-3 h-3" /> Download
                </button>
              </div>

              <div className="py-2 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-800">Part-3 Structural Stability &amp; Fire Safety NOC (PWD / CPWD)</span>
                  <span className="text-slate-400 block text-[11px]">Issued by Competent Authority • Valid for AY 2026-27</span>
                </div>
                <button
                  type="button"
                  onClick={() => alert(`Simulated Download: ${application.applicationNo}_Fire_NOC.pdf`)}
                  className="flex items-center gap-1 px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs cursor-pointer"
                >
                  <Download className="w-3 h-3" /> Download
                </button>
              </div>
            </div>
          </div>

        </div>

        {/* Footer actions */}
        <div className="bg-slate-50 px-5 py-3 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-slate-300 rounded text-slate-700 hover:bg-slate-100 text-xs font-semibold cursor-pointer"
          >
            Close Dossier
          </button>
          <button
            onClick={() => {
              onClose();
              onOpenHumanGate();
            }}
            className="flex items-center gap-1.5 px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white rounded text-xs font-bold shadow-sm transition-colors cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span>Open Human-Gate Decision Interface</span>
          </button>
        </div>

      </div>
    </div>
  );
};
