import React, { useState } from 'react';
import { InstitutionalUndertaking, UserRole } from '../types';
import { 
  FileCheck, AlertTriangle, CheckCircle2, Upload, 
  FileText, ShieldCheck, Clock, ExternalLink, X, Search 
} from 'lucide-react';
import { formatDateIndian } from '../utils/date';

interface UndertakingsTrackerProps {
  undertakings: InstitutionalUndertaking[];
  currentUserRole: UserRole;
  currentSimulatedDate: string;
  onVerifyUndertaking: (
    undertakingId: string,
    status: 'VERIFIED_COMPLIANT' | 'DEFICIENT_OVERDUE',
    remarks: string,
    officerName: string
  ) => void;
  onSubmitEvidence: (
    undertakingId: string,
    fileName: string,
    notes: string
  ) => void;
}

export const UndertakingsTracker: React.FC<UndertakingsTrackerProps> = ({
  undertakings,
  currentUserRole,
  currentSimulatedDate,
  onVerifyUndertaking,
  onSubmitEvidence,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<'ALL' | 'PENDING' | 'SUBMITTED' | 'VERIFIED'>('ALL');
  const [activeUndertakingForVerify, setActiveUndertakingForVerify] = useState<InstitutionalUndertaking | null>(null);
  const [activeUndertakingForUpload, setActiveUndertakingForUpload] = useState<InstitutionalUndertaking | null>(null);

  // Verification modal state
  const [verificationRemarks, setVerificationRemarks] = useState('');
  const [officerName, setOfficerName] = useState('Dr. R. Sundaram (Sr. Regional Officer)');

  // Upload modal state
  const [uploadedFileName, setUploadedFileName] = useState('Joint_FDR_Receipt_Stamped_15Lakhs.pdf');
  const [submissionNotes, setSubmissionNotes] = useState('Certified copy of Fixed Deposit Receipt pledged in joint favor of Regional Officer, AICTE.');

  // Filter undertakings
  const filtered = undertakings.filter(u => {
    if (selectedFilter === 'PENDING') return u.verificationStatus === 'PENDING_SUBMISSION';
    if (selectedFilter === 'SUBMITTED') return u.verificationStatus === 'SUBMITTED_AWAITING_VERIFICATION';
    if (selectedFilter === 'VERIFIED') return u.verificationStatus === 'VERIFIED_COMPLIANT';
    return true;
  });

  const handleVerifySubmit = (status: 'VERIFIED_COMPLIANT' | 'DEFICIENT_OVERDUE') => {
    if (!activeUndertakingForVerify) return;
    if (!verificationRemarks.trim()) {
      alert('Officer verification remarks are mandatory.');
      return;
    }
    onVerifyUndertaking(
      activeUndertakingForVerify.id,
      status,
      verificationRemarks,
      officerName
    );
    setActiveUndertakingForVerify(null);
    setVerificationRemarks('');
  };

  const handleEvidenceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeUndertakingForUpload) return;
    onSubmitEvidence(
      activeUndertakingForUpload.id,
      uploadedFileName,
      submissionNotes
    );
    setActiveUndertakingForUpload(null);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-[#0A192F] text-white rounded-lg p-5 border border-amber-500/30 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono-code font-bold uppercase text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded border border-amber-500/30">
                Module D • APH Chapter VI Norms
              </span>
              <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded font-mono-code">
                Evidence Verifiable
              </span>
            </div>
            <h3 className="text-base font-bold text-white mt-1 flex items-center gap-2">
              <FileCheck className="w-5 h-5 text-amber-400" />
              <span>Monitoring of Time-Bound Undertakings &amp; Institutional Compliance</span>
            </h3>
            <p className="text-xs text-slate-300 mt-0.5">
              Digital ledger for conditional approvals granted subject to time-bound covenants (Joint FDRs, Faculty Cadre recruitments, Building Completion Certificates, and Fire Safety NOCs).
            </p>
          </div>

          <div className="flex items-center gap-3 bg-slate-900/80 p-3 rounded border border-slate-700 text-xs shrink-0">
            <div>
              <div className="text-slate-400">Total Tracked Undertakings:</div>
              <div className="text-lg font-bold font-mono-code text-amber-300">
                {undertakings.length} Active Covenants
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Table Card */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4 space-y-4">
        
        {/* Table Filters */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-700">Filter Status:</span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setSelectedFilter('ALL')}
                className={`px-2.5 py-1 text-xs rounded border transition-colors cursor-pointer ${
                  selectedFilter === 'ALL'
                    ? 'bg-blue-900 text-white border-blue-900 font-semibold'
                    : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                }`}
              >
                All ({undertakings.length})
              </button>
              <button
                onClick={() => setSelectedFilter('PENDING')}
                className={`px-2.5 py-1 text-xs rounded border transition-colors cursor-pointer ${
                  selectedFilter === 'PENDING'
                    ? 'bg-blue-900 text-white border-blue-900 font-semibold'
                    : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                }`}
              >
                Pending Submission
              </button>
              <button
                onClick={() => setSelectedFilter('SUBMITTED')}
                className={`px-2.5 py-1 text-xs rounded border transition-colors cursor-pointer ${
                  selectedFilter === 'SUBMITTED'
                    ? 'bg-blue-900 text-white border-blue-900 font-semibold'
                    : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                }`}
              >
                Awaiting Verification
              </button>
              <button
                onClick={() => setSelectedFilter('VERIFIED')}
                className={`px-2.5 py-1 text-xs rounded border transition-colors cursor-pointer ${
                  selectedFilter === 'VERIFIED'
                    ? 'bg-blue-900 text-white border-blue-900 font-semibold'
                    : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                }`}
              >
                Verified Compliant
              </button>
            </div>
          </div>

          <div className="text-xs text-slate-500">
            Showing <strong className="text-slate-900">{filtered.length}</strong> undertakings
          </div>
        </div>

        {/* Undertakings Table */}
        <div className="overflow-x-auto border border-slate-200 rounded">
          <table className="w-full text-left text-xs divide-y divide-slate-200">
            <thead className="bg-slate-100/80 text-slate-700 font-bold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-2.5 px-3">Covenant Title &amp; Clause</th>
                <th className="py-2.5 px-3">Institution &amp; Region</th>
                <th className="py-2.5 px-3">Due Date &amp; Remaining</th>
                <th className="py-2.5 px-3">Submitted Evidence</th>
                <th className="py-2.5 px-3">Verification Status</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 bg-white">
              {filtered.map((item) => {
                const isOverdue = item.verificationStatus === 'DEFICIENT_OVERDUE';

                return (
                  <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                    
                    <td className="py-3 px-3">
                      <div>
                        <span className="font-bold text-slate-900 block">{item.title}</span>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="font-mono-code text-[10px] text-blue-900 bg-blue-50 px-1.5 py-0.2 rounded border border-blue-200">
                            {item.clause}
                          </span>
                          <span className="text-[10px] text-slate-500 font-mono-code">{item.id}</span>
                        </div>
                        <p className="text-[11px] text-slate-600 mt-1 line-clamp-1">
                          {item.prescribedCondition}
                        </p>
                      </div>
                    </td>

                    <td className="py-3 px-3">
                      <span className="font-semibold text-slate-800 block">{item.institutionName}</span>
                      <span className="text-[11px] text-slate-500">{item.region} Region</span>
                    </td>

                    <td className="py-3 px-3">
                      <div className="font-mono-code">
                        <span className="font-bold text-slate-900 block">{formatDateIndian(item.dueDate)}</span>
                        <span className={`text-[11px] font-semibold ${
                          item.daysRemaining <= 5 ? 'text-red-600' : 'text-slate-500'
                        }`}>
                          {item.daysRemaining > 0 ? `${item.daysRemaining} days remaining` : 'Due date reached'}
                        </span>
                      </div>
                    </td>

                    <td className="py-3 px-3">
                      {item.submittedEvidenceDoc ? (
                        <div className="flex items-center gap-1.5 text-blue-800">
                          <FileText className="w-4 h-4 shrink-0" />
                          <div>
                            <span className="font-mono-code text-[11px] block truncate max-w-xs">{item.submittedEvidenceDoc}</span>
                            <span className="text-[10px] text-slate-400">Uploaded {formatDateIndian(item.submissionDate || '')}</span>
                          </div>
                        </div>
                      ) : (
                        <span className="text-amber-700 italic text-[11px]">Pending submission</span>
                      )}
                    </td>

                    <td className="py-3 px-3">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold border ${
                        item.verificationStatus === 'VERIFIED_COMPLIANT' ? 'bg-emerald-50 text-emerald-900 border-emerald-300' :
                        item.verificationStatus === 'SUBMITTED_AWAITING_VERIFICATION' ? 'bg-blue-50 text-blue-900 border-blue-300' :
                        item.verificationStatus === 'DEFICIENT_OVERDUE' ? 'bg-red-50 text-red-900 border-red-300' :
                        'bg-amber-50 text-amber-900 border-amber-300'
                      }`}>
                        {item.verificationStatus === 'VERIFIED_COMPLIANT' && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
                        {item.verificationStatus === 'DEFICIENT_OVERDUE' && <AlertTriangle className="w-3 h-3 text-red-600" />}
                        <span>{item.verificationStatus.replace(/_/g, ' ')}</span>
                      </span>
                    </td>

                    <td className="py-3 px-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {item.verificationStatus === 'PENDING_SUBMISSION' && (
                          <button
                            type="button"
                            onClick={() => setActiveUndertakingForUpload(item)}
                            className="flex items-center gap-1 px-2.5 py-1.5 bg-blue-900 hover:bg-blue-800 text-white rounded text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                          >
                            <Upload className="w-3.5 h-3.5" />
                            <span>Upload Evidence</span>
                          </button>
                        )}

                        {item.verificationStatus === 'SUBMITTED_AWAITING_VERIFICATION' && (
                          <button
                            type="button"
                            onClick={() => setActiveUndertakingForVerify(item)}
                            className="flex items-center gap-1 px-2.5 py-1.5 bg-emerald-800 hover:bg-emerald-700 text-white rounded text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                          >
                            <ShieldCheck className="w-3.5 h-3.5 text-amber-300" />
                            <span>Verify Evidence</span>
                          </button>
                        )}

                        {item.verificationStatus === 'VERIFIED_COMPLIANT' && (
                          <span className="text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded border border-emerald-300">
                            Sealed &amp; Hashed
                          </span>
                        )}
                      </div>
                    </td>

                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Verify Evidence Modal */}
      {activeUndertakingForVerify && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-2xl max-w-xl w-full border border-slate-300 overflow-hidden text-slate-800 animate-in fade-in zoom-in-95 duration-150 text-xs">
            <div className="bg-[#0A192F] text-white px-5 py-4 flex items-center justify-between border-b border-amber-500/30">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-base">Verify Institutional Compliance Evidence</h3>
              </div>
              <button
                onClick={() => setActiveUndertakingForVerify(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-3.5">
              <div>
                <span className="text-slate-500 block">Institution:</span>
                <span className="font-bold text-slate-900 text-sm">{activeUndertakingForVerify.institutionName}</span>
                <span className="text-slate-600 block">{activeUndertakingForVerify.title} ({activeUndertakingForVerify.clause})</span>
              </div>

              <div className="bg-slate-50 p-3 rounded border border-slate-200">
                <span className="font-bold text-slate-700 block mb-1">Prescribed Undertaking Requirement:</span>
                <p className="text-slate-800 leading-relaxed">{activeUndertakingForVerify.prescribedCondition}</p>
              </div>

              <div className="bg-blue-50/70 p-3 rounded border border-blue-200 flex items-center justify-between">
                <div>
                  <span className="font-bold text-blue-900 block">Uploaded Supporting Document:</span>
                  <span className="font-mono-code text-slate-800">{activeUndertakingForVerify.submittedEvidenceDoc}</span>
                </div>
                <button
                  type="button"
                  onClick={() => alert(`Simulated preview: ${activeUndertakingForVerify.submittedEvidenceDoc}`)}
                  className="px-2.5 py-1 bg-white border border-blue-300 text-blue-900 rounded font-semibold hover:bg-blue-50 cursor-pointer"
                >
                  View Attachment
                </button>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Officer Verification Audit Remarks <span className="text-red-500">*</span>:
                </label>
                <textarea
                  value={verificationRemarks}
                  onChange={(e) => setVerificationRemarks(e.target.value)}
                  placeholder="Record verification findings (e.g. verified bank seal, lock-in period, authorized signature confirmed per APH Chapter VI)..."
                  rows={3}
                  className="w-full p-2.5 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-700 bg-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => handleVerifySubmit('DEFICIENT_OVERDUE')}
                  className="px-4 py-2 border border-red-300 bg-red-50 text-red-800 hover:bg-red-100 rounded font-bold cursor-pointer"
                >
                  Reject with Deficiencies
                </button>
                <button
                  type="button"
                  onClick={() => handleVerifySubmit('VERIFIED_COMPLIANT')}
                  className="px-4 py-2 bg-emerald-800 hover:bg-emerald-700 text-white rounded font-bold shadow-sm cursor-pointer"
                >
                  Accept &amp; Seal Compliant
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Upload Evidence Modal */}
      {activeUndertakingForUpload && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-2xl max-w-xl w-full border border-slate-300 overflow-hidden text-slate-800 animate-in fade-in zoom-in-95 duration-150 text-xs">
            <div className="bg-[#0A192F] text-white px-5 py-4 flex items-center justify-between border-b border-amber-500/30">
              <div className="flex items-center gap-2">
                <Upload className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-base">Submit Institutional Compliance Evidence</h3>
              </div>
              <button
                onClick={() => setActiveUndertakingForUpload(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEvidenceSubmit} className="p-5 space-y-3.5">
              <div>
                <span className="text-slate-500 block">Institution:</span>
                <span className="font-bold text-slate-900 text-sm">{activeUndertakingForUpload.institutionName}</span>
                <span className="text-slate-600 block">{activeUndertakingForUpload.title}</span>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Select Certified PDF / Scanned Stamp Paper:
                </label>
                <input
                  type="text"
                  value={uploadedFileName}
                  onChange={(e) => setUploadedFileName(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded text-slate-900 font-mono-code bg-slate-50"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Institutional Explanatory Notes &amp; Dispatch Details:
                </label>
                <textarea
                  value={submissionNotes}
                  onChange={(e) => setSubmissionNotes(e.target.value)}
                  rows={3}
                  className="w-full p-2.5 border border-slate-300 rounded text-slate-900 bg-white"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setActiveUndertakingForUpload(null)}
                  className="px-4 py-2 border border-slate-300 rounded text-slate-700 hover:bg-slate-100 font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white rounded font-bold shadow-sm cursor-pointer"
                >
                  Submit for Officer Scrutiny
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
