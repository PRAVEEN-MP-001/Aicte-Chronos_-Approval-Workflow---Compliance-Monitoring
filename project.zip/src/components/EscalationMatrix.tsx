import React, { useState } from 'react';
import { DeadlineObligation, Application } from '../types';
import { 
  ShieldAlert, AlertTriangle, ArrowUpRight, Flame, Scale, 
  Send, FileSpreadsheet, Lock, CheckCircle2 
} from 'lucide-react';

interface EscalationMatrixProps {
  deadlines: DeadlineObligation[];
  applications: Application[];
  onTriggerEscalationNotice: (title: string, institutionName: string, level: string, clause: string) => void;
}

export const EscalationMatrix: React.FC<EscalationMatrixProps> = ({
  deadlines,
  applications,
  onTriggerEscalationNotice,
}) => {
  const [activeNoticeModal, setActiveNoticeModal] = useState<{
    instName: string;
    clause: string;
    level: string;
  } | null>(null);

  // Group alerts by level
  const l3Alerts = deadlines.filter(d => d.escalationLevel === 'L3_HQ_PENALTY' || (d.isBreached && d.hardLimitDays <= 7));
  const l2Alerts = deadlines.filter(d => d.escalationLevel === 'L2_BUREAU' || (d.isBreached && d.type === 'LEASE_CRITICAL_WINDOW'));
  const l1Alerts = deadlines.filter(d => d.escalationLevel === 'L1_REGIONAL' && !d.isBreached);

  return (
    <div className="space-y-6">
      
      {/* Visual Escalation Ladder Banner */}
      <div className="bg-[#0A192F] text-white rounded-lg p-5 border border-amber-500/30 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4 pb-3 border-b border-white/10">
          <div>
            <span className="text-[10px] font-mono-code font-bold uppercase text-amber-400 tracking-wider">
              AICTE Compliance Enforcement Architecture
            </span>
            <h3 className="text-base font-bold text-white flex items-center gap-2 mt-0.5">
              <ShieldAlert className="w-5 h-5 text-amber-400" />
              <span>Multi-Tiered Automated Escalation Ladder (Module F)</span>
            </h3>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono-code text-slate-300">
            <span>SLA Monitoring: Active</span>
            <span className="text-slate-600">|</span>
            <span className="text-amber-300">Auto-Escalation Engine: Active</span>
          </div>
        </div>

        {/* 3 Tier Steps */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          
          {/* L1 */}
          <div className="bg-blue-950/60 p-3.5 rounded border border-blue-500/40 relative">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-bold text-blue-300 uppercase tracking-wider">
                Tier L1: Regional Notice
              </span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-mono-code bg-blue-500/20 text-blue-200 border border-blue-500/30">
                Grace Period
              </span>
            </div>
            <h4 className="text-sm font-bold text-white">Regional Office Advisory</h4>
            <p className="text-xs text-slate-300 mt-1">
              Active while clock &lt; 70% of statutory ceiling. Regional Officer &amp; College Principal receive advisory push notifications.
            </p>
            <div className="mt-3 text-[11px] text-blue-300 font-semibold flex items-center gap-1">
              <span>{l1Alerts.length} Active Notifications</span>
            </div>
          </div>

          {/* L2 */}
          <div className="bg-amber-950/60 p-3.5 rounded border border-amber-500/40 relative">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-bold text-amber-300 uppercase tracking-wider">
                Tier L2: Bureau Escalation
              </span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-mono-code bg-amber-500/20 text-amber-200 border border-amber-500/30">
                Warning Window
              </span>
            </div>
            <h4 className="text-sm font-bold text-white">AICTE HQ Approval Cell Alert</h4>
            <p className="text-xs text-slate-300 mt-1">
              Clock &gt; 70% or Critical Date Cushion breach. Portal modification locked; Director alerted for immediate remediation.
            </p>
            <div className="mt-3 text-[11px] text-amber-300 font-semibold flex items-center gap-1">
              <span>{l2Alerts.length} Escalations Pending</span>
            </div>
          </div>

          {/* L3 */}
          <div className="bg-red-950/70 p-3.5 rounded border border-red-500/40 relative">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-bold text-red-300 uppercase tracking-wider">
                Tier L3: Statutory Penalty
              </span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-mono-code bg-red-500/30 text-red-200 border border-red-500/40">
                Hard Breach
              </span>
            </div>
            <h4 className="text-sm font-bold text-white">Show Cause &amp; Forfeiture</h4>
            <p className="text-xs text-slate-300 mt-1">
              Hard ceiling breached (7-day appeal lapsed or &gt;30-day deposit delay). Formal Show-Cause notice generated and SAC summoned.
            </p>
            <div className="mt-3 text-[11px] text-red-300 font-semibold flex items-center gap-1">
              <span>{l3Alerts.length} Actionable Defaults</span>
            </div>
          </div>

        </div>
      </div>

      {/* Actionable Escalated Cases */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-2">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Flame className="w-4 h-4 text-red-600" />
              <span>Active Compliance Escalation Roster</span>
            </h3>
            <p className="text-xs text-slate-500">
              Direct officer intervention queue for escalated breaches requiring formal summons or statutory notices.
            </p>
          </div>
        </div>

        {/* List of Escalation Cards */}
        <div className="space-y-3">
          {deadlines.map((item) => {
            const isCritical = item.isBreached || item.escalationLevel === 'L3_HQ_PENALTY';
            const levelBadge = item.isBreached ? 'L3_HQ_PENALTY' : item.escalationLevel;

            return (
              <div
                key={item.id}
                className={`p-3.5 rounded border text-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-3 ${
                  isCritical ? 'border-red-300 bg-red-50/50' : 'border-amber-200 bg-amber-50/30'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`px-2 py-0.5 rounded font-mono-code font-bold text-[10px] uppercase ${
                      isCritical ? 'bg-red-900 text-white' : 'bg-amber-800 text-amber-100'
                    }`}>
                      {levelBadge.replace('_', ' ')}
                    </span>
                    <span className="font-mono-code text-slate-500 font-bold">{item.clause}</span>
                    <h4 className="font-bold text-slate-900 text-xs sm:text-sm">{item.institutionName}</h4>
                  </div>
                  <p className="text-slate-600">
                    <strong>Issue:</strong> {item.title}. Clock status: <span className="font-bold font-mono-code">{item.currentElapsedDays} days elapsed</span> of {item.hardLimitDays} days maximum limit.
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0 self-end md:self-auto">
                  <button
                    type="button"
                    onClick={() => {
                      onTriggerEscalationNotice(
                        item.title,
                        item.institutionName,
                        levelBadge,
                        item.clause
                      );
                      alert(`Statutory Action Dispatched: Official Show-Cause / Escalation Notice served to ${item.institutionName} under ${item.clause}. Inscribed into SHA-256 Audit Chain.`);
                    }}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-bold transition-colors cursor-pointer shadow-2xs ${
                      isCritical
                        ? 'bg-red-900 hover:bg-red-800 text-white'
                        : 'bg-amber-800 hover:bg-amber-700 text-white'
                    }`}
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Issue Statutory Notice</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
