import React, { useState } from 'react';
import { Application, ApplicationStage, ApplicationStatus, UserRole } from '../types';
import { ShieldCheck, AlertCircle, ArrowRight, CheckSquare, X, Lock } from 'lucide-react';

interface HumanGateModalProps {
  application: Application;
  currentUserRole: UserRole;
  onClose: () => void;
  onAdvanceStage: (appId: string, nextStage: ApplicationStage, remarks: string, officerName: string) => void;
  onReturnDeficiency: (appId: string, deficiencyNotes: string, remarks: string, officerName: string) => void;
  onVerifyChecklist: (appId: string, checklist: Application['scrutinyChecklist'], remarks: string, officerName: string) => void;
}

export const HumanGateModal: React.FC<HumanGateModalProps> = ({
  application,
  currentUserRole,
  onClose,
  onAdvanceStage,
  onReturnDeficiency,
  onVerifyChecklist,
}) => {
  const [actionType, setActionType] = useState<'ADVANCE' | 'DEFICIENCY' | 'CHECKLIST'>('ADVANCE');
  const [remarks, setRemarks] = useState('');
  const [deficiencyNotes, setDeficiencyNotes] = useState(application.deficiencyNotes || '');
  const [officerName, setOfficerName] = useState('Dr. R. Sundaram (Sr. Regional Officer)');
  const [statutoryConfirmed, setStatutoryConfirmed] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Editable checklist
  const [checklist, setChecklist] = useState({ ...application.scrutinyChecklist });

  // Compute next stage
  const getNextStage = (curr: ApplicationStage): ApplicationStage => {
    switch (curr) {
      case 'SUBMISSION': return 'SCRUTINY';
      case 'SCRUTINY': return 'EVC_INSPECTION';
      case 'EVC_INSPECTION': return 'SAC_APPROVAL';
      case 'SAC_APPROVAL': return 'ISSUANCE';
      case 'ISSUANCE': return 'ISSUANCE';
    }
  };

  const nextStage = getNextStage(application.stage);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!statutoryConfirmed) {
      setErrorMsg('Mandatory: You must check the statutory affirmation checkbox to proceed.');
      return;
    }
    if (!remarks.trim()) {
      setErrorMsg('Mandatory: Reason / Justification remarks cannot be blank for audit compliance.');
      return;
    }

    if (actionType === 'ADVANCE') {
      onAdvanceStage(application.id, nextStage, remarks, officerName);
    } else if (actionType === 'DEFICIENCY') {
      if (!deficiencyNotes.trim()) {
        setErrorMsg('Mandatory: Please specify the exact deficiency clause and grounds.');
        return;
      }
      onReturnDeficiency(application.id, deficiencyNotes, remarks, officerName);
    } else if (actionType === 'CHECKLIST') {
      onVerifyChecklist(application.id, checklist, remarks, officerName);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-lg shadow-2xl max-w-2xl w-full border border-slate-300 overflow-hidden text-slate-800 animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="bg-[#0A192F] text-white px-5 py-4 flex items-center justify-between border-b border-amber-500/30">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-amber-500/20 border border-amber-500/40 rounded text-amber-300">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase tracking-wider font-semibold text-amber-300">
                  Statutory Human-Gate Decision
                </span>
                <span className="text-[10px] font-mono-code bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded border border-slate-700">
                  {application.applicationNo}
                </span>
              </div>
              <h3 className="font-bold text-base text-white">
                {application.institutionName}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current status strip */}
        <div className="bg-slate-100 border-b border-slate-200 px-5 py-2.5 text-xs flex flex-wrap items-center justify-between gap-2">
          <div>
            <span className="text-slate-500">Current APH Stage: </span>
            <span className="font-bold text-blue-900 bg-blue-100 px-2 py-0.5 rounded border border-blue-200">
              {application.stage}
            </span>
          </div>
          <div>
            <span className="text-slate-500">Status: </span>
            <span className="font-semibold text-slate-700">
              {application.status}
            </span>
          </div>
          <div>
            <span className="text-slate-500">Region: </span>
            <span className="font-semibold text-slate-700">{application.region}</span>
          </div>
        </div>

        {/* Action Type Selector */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Select Officer Action:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              
              <button
                type="button"
                onClick={() => setActionType('ADVANCE')}
                className={`p-3 rounded border text-left flex flex-col justify-between transition-all cursor-pointer ${
                  actionType === 'ADVANCE'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-950 ring-2 ring-emerald-500/30'
                    : 'border-slate-300 hover:border-slate-400 bg-white text-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-xs">Advance Stage</span>
                  <ArrowRight className="w-4 h-4 text-emerald-600" />
                </div>
                <p className="text-[11px] text-slate-600">
                  Move from <span className="font-semibold">{application.stage}</span> to <span className="font-semibold text-emerald-700">{nextStage}</span>
                </p>
              </button>

              <button
                type="button"
                onClick={() => setActionType('DEFICIENCY')}
                className={`p-3 rounded border text-left flex flex-col justify-between transition-all cursor-pointer ${
                  actionType === 'DEFICIENCY'
                    ? 'border-red-600 bg-red-50 text-red-950 ring-2 ring-red-500/30'
                    : 'border-slate-300 hover:border-slate-400 bg-white text-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-xs text-red-800">Flag Deficiency</span>
                  <AlertCircle className="w-4 h-4 text-red-600" />
                </div>
                <p className="text-[11px] text-slate-600">
                  Issue Deficiency Notice &amp; start 7-Day Appeal Clock (APH 1.11a)
                </p>
              </button>

              <button
                type="button"
                onClick={() => setActionType('CHECKLIST')}
                className={`p-3 rounded border text-left flex flex-col justify-between transition-all cursor-pointer ${
                  actionType === 'CHECKLIST'
                    ? 'border-blue-600 bg-blue-50 text-blue-950 ring-2 ring-blue-500/30'
                    : 'border-slate-300 hover:border-slate-400 bg-white text-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-xs text-blue-800">Scrutiny Checklist</span>
                  <CheckSquare className="w-4 h-4 text-blue-600" />
                </div>
                <p className="text-[11px] text-slate-600">
                  Verify individual statutory norms (Land, Faculty, FDR, Space)
                </p>
              </button>
            </div>
          </div>

          {/* Conditional content based on action */}
          {actionType === 'DEFICIENCY' && (
            <div className="bg-red-50/70 p-3 rounded border border-red-200 space-y-2">
              <label className="block text-xs font-bold text-red-900">
                Deficiency Grounds &amp; Statutory Non-Compliance (APH Reference):
              </label>
              <textarea
                value={deficiencyNotes}
                onChange={(e) => setDeficiencyNotes(e.target.value)}
                placeholder="e.g. Cadre ratio deficit in Electrical Engg Dept; Lease expiry critical window non-compliance per APH 2.1e..."
                rows={3}
                className="w-full text-xs p-2.5 border border-red-300 rounded bg-white text-slate-900 focus:outline-none focus:ring-1 focus:ring-red-500 font-sans"
              />
              <p className="text-[11px] text-red-700">
                ⚠️ Notice will be published to the institution portal with an irrevocable 7-Day Appeal countdown clock.
              </p>
            </div>
          )}

          {actionType === 'CHECKLIST' && (
            <div className="bg-slate-50 p-3 rounded border border-slate-200 space-y-2">
              <span className="block text-xs font-bold text-slate-800">
                APH Norms Scrutiny Verification (Section 6, Table 6.1):
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <label className="flex items-center gap-2 p-1.5 bg-white border border-slate-200 rounded cursor-pointer hover:bg-slate-100">
                  <input
                    type="checkbox"
                    checked={checklist.facultyRatioOk}
                    onChange={(e) => setChecklist({ ...checklist, facultyRatioOk: e.target.checked })}
                    className="rounded text-blue-600"
                  />
                  <span>Faculty-Student Ratio (1:15 or 1:20)</span>
                </label>

                <label className="flex items-center gap-2 p-1.5 bg-white border border-slate-200 rounded cursor-pointer hover:bg-slate-100">
                  <input
                    type="checkbox"
                    checked={checklist.landNormsOk}
                    onChange={(e) => setChecklist({ ...checklist, landNormsOk: e.target.checked })}
                    className="rounded text-blue-600"
                  />
                  <span>Contiguous Land &amp; Lease Validity</span>
                </label>

                <label className="flex items-center gap-2 p-1.5 bg-white border border-slate-200 rounded cursor-pointer hover:bg-slate-100">
                  <input
                    type="checkbox"
                    checked={checklist.fdrDepositOk}
                    onChange={(e) => setChecklist({ ...checklist, fdrDepositOk: e.target.checked })}
                    className="rounded text-blue-600"
                  />
                  <span>Security Deposit Joint FDR</span>
                </label>

                <label className="flex items-center gap-2 p-1.5 bg-white border border-slate-200 rounded cursor-pointer hover:bg-slate-100">
                  <input
                    type="checkbox"
                    checked={checklist.builtUpAreaOk}
                    onChange={(e) => setChecklist({ ...checklist, builtUpAreaOk: e.target.checked })}
                    className="rounded text-blue-600"
                  />
                  <span>Instructional &amp; Admin Area</span>
                </label>

                <label className="flex items-center gap-2 p-1.5 bg-white border border-slate-200 rounded cursor-pointer hover:bg-slate-100 sm:col-span-2">
                  <input
                    type="checkbox"
                    checked={checklist.barrierFreeAccessOk}
                    onChange={(e) => setChecklist({ ...checklist, barrierFreeAccessOk: e.target.checked })}
                    className="rounded text-blue-600"
                  />
                  <span>Barrier-Free Built Environment for Divyangjan</span>
                </label>
              </div>
            </div>
          )}

          {/* Mandatory Officer Remarks */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Officer Audit Remarks &amp; Justification <span className="text-red-500">*</span>
            </label>
            <textarea
              value={remarks}
              onChange={(e) => {
                setRemarks(e.target.value);
                if (errorMsg) setErrorMsg('');
              }}
              placeholder="Provide statutory justification for this action. This remark will be permanently inscribed into the SHA-256 audit ledger."
              rows={2}
              required
              className="w-full text-xs p-2.5 border border-slate-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-600 bg-white"
            />
          </div>

          {/* Officer credentials */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block font-semibold text-slate-600 mb-1">Verifying Officer Name &amp; Designation:</label>
              <input
                type="text"
                value={officerName}
                onChange={(e) => setOfficerName(e.target.value)}
                className="w-full p-2 border border-slate-300 rounded bg-slate-50 text-slate-800 font-medium"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-600 mb-1">Actor Role Credential:</label>
              <input
                type="text"
                readOnly
                value={`${currentUserRole} (Authorized Signatory)`}
                className="w-full p-2 border border-slate-200 rounded bg-slate-100 text-slate-600 font-mono-code text-[11px]"
              />
            </div>
          </div>

          {/* Statutory Affirmation Checkbox */}
          <div className="bg-amber-50 p-3 rounded border border-amber-200 text-xs text-amber-950">
            <label className="flex items-start gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={statutoryConfirmed}
                onChange={(e) => {
                  setStatutoryConfirmed(e.target.checked);
                  if (errorMsg) setErrorMsg('');
                }}
                className="mt-0.5 rounded text-amber-600"
              />
              <span className="leading-tight">
                <strong>Statutory Affirmation:</strong> I hereby declare that I have examined the institutional record in conformity with the AICTE Act 1987 and Approval Process Handbook 2026-27. I acknowledge this decision is non-repudiable and will append a cryptographically hashed block to the national audit ledger.
              </span>
            </label>
          </div>

          {errorMsg && (
            <div className="p-2.5 bg-red-100 border border-red-300 text-red-800 text-xs rounded font-medium flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Buttons */}
          <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 rounded text-slate-700 hover:bg-slate-100 text-xs font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white rounded text-xs font-bold shadow-sm transition-colors cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5 text-amber-400" />
              <span>Inscribe Decision into Ledger</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
