import React, { useState } from 'react';
import { DeadlineObligation, Institution, UserRole } from '../types';
import { 
  Hourglass, AlertTriangle, ShieldAlert, CheckCircle2, 
  FileCheck, Calendar, IndianRupee, Cpu, Scale 
} from 'lucide-react';
import { formatDateIndian, calculateDepositPenalty } from '../utils/date';
import { LeaseEngineModal } from './LeaseEngineModal';

interface DeadlineLedgerProps {
  deadlines: DeadlineObligation[];
  institutions: Institution[];
  currentSimulatedDate: string;
  currentUserRole: UserRole;
  onResolveObligation: (obligationId: string, remarks: string) => void;
  onConfirmLeaseUpdate: (
    instId: string,
    newEndDate: string,
    newSurveyNumber: string,
    officerRemarks: string,
    ocrData: any
  ) => void;
}

export const DeadlineLedger: React.FC<DeadlineLedgerProps> = ({
  deadlines,
  institutions,
  currentSimulatedDate,
  currentUserRole,
  onResolveObligation,
  onConfirmLeaseUpdate,
}) => {
  const [activeLeaseModalInst, setActiveLeaseModalInst] = useState<Institution | null>(null);
  const [selectedFilter, setSelectedFilter] = useState<'ALL' | 'APPEAL' | 'DEPOSIT' | 'LEASE'>('ALL');

  // Filter deadlines
  const filteredDeadlines = deadlines.filter((d) => {
    if (selectedFilter === 'APPEAL') return d.type === 'APPEAL_FILING';
    if (selectedFilter === 'DEPOSIT') return d.type === 'SECURITY_DEPOSIT';
    if (selectedFilter === 'LEASE') return d.type === 'LEASE_CRITICAL_WINDOW';
    return true;
  });

  // Calculate dynamic statistics
  const totalObligations = deadlines.length;
  const hardBreaches = deadlines.filter(d => d.isBreached || d.status === 'BREACHED').length;
  const pendingWithinLimit = deadlines.filter(d => !d.isBreached && d.status === 'PENDING').length;
  
  // Total accrued penalty across all deposits
  const totalPenalties = deadlines.reduce((acc, d) => {
    if (d.type === 'SECURITY_DEPOSIT' && d.amountRequired) {
      const pen = calculateDepositPenalty(d.currentElapsedDays, d.amountRequired);
      return acc + pen.penaltyAmount;
    }
    return acc;
  }, 0);

  return (
    <div className="space-y-6">
      
      {/* Statutory Header Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        
        {/* Total Tracked Hard Clocks */}
        <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span className="font-semibold uppercase tracking-wider">Statutory Hard Clocks</span>
            <Hourglass className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 font-mono-code">
            {totalObligations}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Irrevocable clocks governed by APH 2026-27
          </p>
        </div>

        {/* 7-Day Appeal Clocks */}
        <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span className="font-semibold uppercase tracking-wider">7-Day Appeals (APH 1.11a)</span>
            <Scale className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 font-mono-code">
            {deadlines.filter(d => d.type === 'APPEAL_FILING').length}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Pre-hearing SAC limitation countdown
          </p>
        </div>

        {/* Critical Land Expiry Alerts */}
        <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span className="font-semibold uppercase tracking-wider">Lease Cushion Breaches</span>
            <AlertTriangle className="w-4 h-4 text-red-600" />
          </div>
          <div className="text-2xl font-bold text-red-600 font-mono-code">
            {deadlines.filter(d => d.type === 'LEASE_CRITICAL_WINDOW' && d.isBreached).length}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            APH 2.1e / 6.17a graduation cycle shortfall
          </p>
        </div>

        {/* Accrued Deposit Penalties */}
        <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span className="font-semibold uppercase tracking-wider">FDR Penalties Levied</span>
            <IndianRupee className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 font-mono-code">
            ₹{totalPenalties.toLocaleString('en-IN')}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            APH 2.25f (10% at 16d / 20% at 31d)
          </p>
        </div>

      </div>

      {/* Main Ledger Content */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4">
        
        {/* Ledger Header & Tab Filter */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 pb-3 mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Hourglass className="w-4 h-4 text-blue-900" />
              <span>Dynamic Statutory Deadline Ledger &amp; Critical Date Engine</span>
            </h3>
            <p className="text-xs text-slate-500">
              Evaluates real-time compliance based on current simulated ledger date: <strong className="font-mono-code text-blue-900">{formatDateIndian(currentSimulatedDate)}</strong>
            </p>
          </div>

          <div className="flex items-center gap-1.5 self-stretch sm:self-auto">
            <button
              onClick={() => setSelectedFilter('ALL')}
              className={`px-2.5 py-1 text-xs rounded border transition-colors cursor-pointer ${
                selectedFilter === 'ALL'
                  ? 'bg-blue-900 text-white border-blue-900 font-semibold'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              All ({deadlines.length})
            </button>
            <button
              onClick={() => setSelectedFilter('APPEAL')}
              className={`px-2.5 py-1 text-xs rounded border transition-colors cursor-pointer ${
                selectedFilter === 'APPEAL'
                  ? 'bg-blue-900 text-white border-blue-900 font-semibold'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              Appeals (7-Day)
            </button>
            <button
              onClick={() => setSelectedFilter('DEPOSIT')}
              className={`px-2.5 py-1 text-xs rounded border transition-colors cursor-pointer ${
                selectedFilter === 'DEPOSIT'
                  ? 'bg-blue-900 text-white border-blue-900 font-semibold'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              Deposits (15-Day)
            </button>
            <button
              onClick={() => setSelectedFilter('LEASE')}
              className={`px-2.5 py-1 text-xs rounded border transition-colors cursor-pointer ${
                selectedFilter === 'LEASE'
                  ? 'bg-blue-900 text-white border-blue-900 font-semibold'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              Lease Cushion Engine
            </button>
          </div>
        </div>

        {/* Obligations Cards Grid */}
        <div className="space-y-4">
          {filteredDeadlines.map((ob) => {
            const isBreached = ob.isBreached || ob.currentElapsedDays > ob.hardLimitDays;
            const progressPercent = Math.min(100, Math.round((ob.currentElapsedDays / ob.hardLimitDays) * 100));
            
            // Dynamic penalty check for FDR deposits
            const depositPenalty = ob.type === 'SECURITY_DEPOSIT' && ob.amountRequired
              ? calculateDepositPenalty(ob.currentElapsedDays, ob.amountRequired)
              : null;

            // Related institution
            const inst = institutions.find(i => i.name.toLowerCase().includes(ob.institutionName.split(' ')[0].toLowerCase())) || institutions[0];

            return (
              <div
                key={ob.id}
                className={`p-4 rounded-lg border transition-all ${
                  isBreached
                    ? 'border-red-300 bg-red-50/40'
                    : ob.currentElapsedDays >= ob.hardLimitDays * 0.7
                    ? 'border-amber-300 bg-amber-50/40'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  
                  {/* Left: Info */}
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] font-mono-code font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200">
                        {ob.clause}
                      </span>
                      <h4 className="font-bold text-sm text-slate-900">
                        {ob.title}
                      </h4>
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded uppercase tracking-wider ${
                        ob.escalationLevel === 'L3_HQ_PENALTY' ? 'bg-red-900 text-white' :
                        ob.escalationLevel === 'L2_BUREAU' ? 'bg-amber-800 text-amber-100' :
                        'bg-blue-800 text-blue-100'
                      }`}>
                        {ob.escalationLevel.replace('_', ' ')}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-xs text-slate-600">
                      <span className="font-semibold text-slate-800">{ob.institutionName}</span>
                      <span>•</span>
                      <span>Commenced: <strong className="font-mono-code">{formatDateIndian(ob.startDate)}</strong></span>
                      <span>•</span>
                      <span>Statutory Limit: <strong className="font-mono-code">{formatDateIndian(ob.deadlineDate)}</strong> ({ob.hardLimitDays} Days Hard Limit)</span>
                    </div>

                    {/* Specific detail notes per type */}
                    {ob.type === 'APPEAL_FILING' && (
                      <p className="text-xs text-slate-600 mt-1">
                        Institution issued Deficiency Notice on cadre ratio. Under <strong>APH Clause 1.11a</strong>, appeal to Standing Appellate Committee (SAC) expires strictly in 7 calendar days. No condonation of delay permitted.
                      </p>
                    )}

                    {ob.type === 'SECURITY_DEPOSIT' && depositPenalty && (
                      <div className="mt-2 p-2.5 rounded bg-white border border-slate-200 text-xs space-y-1">
                        <div className="flex justify-between items-center">
                          <span className="text-slate-600">Base Joint FDR Deposit Amount:</span>
                          <span className="font-mono-code font-bold text-slate-900">
                            ₹{ob.amountRequired?.toLocaleString('en-IN')}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-600">Statutory Penalty Status (APH 2.25f):</span>
                          <span className={`font-semibold ${depositPenalty.penaltyPercent > 0 ? 'text-red-700' : 'text-emerald-700'}`}>
                            {depositPenalty.statusText}
                          </span>
                        </div>
                      </div>
                    )}

                    {ob.type === 'LEASE_CRITICAL_WINDOW' && (
                      <div className="mt-2 p-2.5 rounded bg-white border border-red-200 text-xs text-red-950 space-y-1">
                        <p>
                          <strong>Critical Date Rule (APH 2.1e / 6.17a):</strong> 
                          <span className="ml-1 font-mono-code bg-red-100 px-1.5 py-0.5 rounded text-red-800">
                            Critical Date = Lease End ({inst.leaseEndDate}) - {inst.longestCourseYears} Yrs = 2025-06-30
                          </span>
                        </p>
                        <p className="text-red-800 font-medium">
                          Status: Active admissions frozen until registered lease deed extension (minimum 30 years) is uploaded and verified by Regional Officer.
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Right: Progress Meter & Action */}
                  <div className="flex flex-col items-end justify-between shrink-0 min-w-[220px] space-y-3">
                    
                    {/* Countdown indicator */}
                    <div className="w-full text-right">
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-slate-500">Elapsed Clock:</span>
                        <span className={`font-mono-code font-bold ${
                          isBreached ? 'text-red-600' : 'text-slate-800'
                        }`}>
                          {ob.currentElapsedDays} / {ob.hardLimitDays} Days
                        </span>
                      </div>

                      {/* Progress bar */}
                      <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                        <div
                          className={`h-full transition-all duration-300 ${
                            isBreached ? 'bg-red-600' :
                            progressPercent >= 70 ? 'bg-amber-500' :
                            'bg-blue-600'
                          }`}
                          style={{ width: `${progressPercent}%` }}
                        />
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2">
                      {ob.type === 'LEASE_CRITICAL_WINDOW' && (
                        <button
                          type="button"
                          onClick={() => setActiveLeaseModalInst(inst)}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white rounded text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                        >
                          <Cpu className="w-3.5 h-3.5 text-amber-400" />
                          <span>Simulate OCR Deed Scan</span>
                        </button>
                      )}

                      {ob.status === 'PENDING' && ob.type !== 'LEASE_CRITICAL_WINDOW' && (
                        <button
                          type="button"
                          onClick={() => {
                            const remarks = prompt(
                              `Record compliance resolution for ${ob.institutionName} (${ob.clause}):`,
                              'Affidavit verified and FDR receipt authenticated by finance cell.'
                            );
                            if (remarks) onResolveObligation(ob.id, remarks);
                          }}
                          className="flex items-center gap-1 px-3 py-1.5 bg-emerald-800 hover:bg-emerald-700 text-white rounded text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Record Compliance</span>
                        </button>
                      )}

                      {ob.status === 'RESOLVED' && (
                        <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-800 bg-emerald-100 px-2.5 py-1 rounded border border-emerald-300">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Resolved &amp; Sealed</span>
                        </span>
                      )}
                    </div>

                  </div>

                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Lease Engine OCR Modal */}
      {activeLeaseModalInst && (
        <LeaseEngineModal
          institution={activeLeaseModalInst}
          currentSimulatedDate={currentSimulatedDate}
          onClose={() => setActiveLeaseModalInst(null)}
          onConfirmLeaseUpdate={onConfirmLeaseUpdate}
        />
      )}

    </div>
  );
};
