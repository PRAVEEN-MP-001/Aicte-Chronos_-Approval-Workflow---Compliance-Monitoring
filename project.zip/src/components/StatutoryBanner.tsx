import React from 'react';
import { ShieldCheck, Scale, FileText, CheckCircle2 } from 'lucide-react';

export const StatutoryBanner: React.FC = () => {
  return (
    <div className="bg-amber-50 border-l-4 border-amber-600 p-3 sm:p-4 rounded-r-md shadow-sm mb-5 text-amber-950">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="p-1.5 bg-amber-200 text-amber-800 rounded-md shrink-0 mt-0.5">
            <Scale className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-xs uppercase tracking-wider text-amber-900 bg-amber-200/80 px-2 py-0.5 rounded">
                Statutory Safeguard
              </span>
              <span className="font-semibold text-sm text-slate-900">
                AICTE Human-Gate Decision Protocol (Section 10(k), AICTE Act 1987)
              </span>
            </div>
            <p className="text-xs text-amber-900/90 mt-1">
              <strong className="text-amber-950">ADVISORY ONLY:</strong> No statutory approval, deficiency issuance, or penalty forfeiture is automated. Algorithms and OCR extract dates and trigger compliance countdowns; all final stage advancements require affirmative Officer digital verification and justification remarks.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
          <span className="inline-flex items-center gap-1 text-[11px] font-medium bg-white text-emerald-800 border border-emerald-300 px-2 py-1 rounded shadow-2xs">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Human-in-the-Loop Active</span>
          </span>
          <span className="inline-flex items-center gap-1 text-[11px] font-medium bg-white text-blue-800 border border-blue-300 px-2 py-1 rounded shadow-2xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
            <span>Hash-Chained</span>
          </span>
        </div>
      </div>
    </div>
  );
};
