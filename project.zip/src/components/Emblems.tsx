import React from 'react';

/**
 * Authentic Government of India Emblem (Ashoka Lion Capital motif)
 */
export const IndiaEmblemSvg: React.FC<{ className?: string }> = ({ className = 'w-10 h-10' }) => (
  <svg 
    viewBox="0 0 100 120" 
    className={className} 
    fill="currentColor"
    aria-label="Government of India Emblem"
  >
    {/* Ashoka Chakra Base */}
    <circle cx="50" cy="100" r="12" fill="none" stroke="currentColor" strokeWidth="2" />
    <circle cx="50" cy="100" r="2" fill="currentColor" />
    {/* Spokes */}
    {Array.from({ length: 12 }).map((_, i) => (
      <line
        key={i}
        x1="50"
        y1="100"
        x2={50 + 12 * Math.cos((i * Math.PI) / 6)}
        y2={100 + 12 * Math.sin((i * Math.PI) / 6)}
        stroke="currentColor"
        strokeWidth="1"
      />
    ))}
    {/* Base Pedestal */}
    <path d="M 20 115 L 80 115 L 75 110 L 25 110 Z" fill="currentColor" />
    <rect x="22" y="112" width="56" height="2" fill="#fff" opacity="0.3" />
    <text x="50" y="119" textAnchor="middle" fontSize="4.5" fontWeight="bold" fill="currentColor">
      सत्यमेव जयते
    </text>
    {/* Central Lion Body & Mane */}
    <path
      d="M 40 38 Q 42 22 50 18 Q 58 22 60 38 Q 66 50 63 65 Q 60 80 50 84 Q 40 80 37 65 Q 34 50 40 38 Z"
      fill="currentColor"
    />
    {/* Left Lion Profile */}
    <path
      d="M 37 40 C 26 35 24 50 28 64 C 31 72 37 78 40 82 C 38 72 36 56 37 40 Z"
      fill="currentColor"
      opacity="0.9"
    />
    {/* Right Lion Profile */}
    <path
      d="M 63 40 C 74 35 76 50 72 64 C 69 72 63 78 60 82 C 62 72 64 56 63 40 Z"
      fill="currentColor"
      opacity="0.9"
    />
    {/* Central Lion Head Details */}
    <circle cx="46" cy="30" r="2" fill="#fff" opacity="0.8" />
    <circle cx="54" cy="30" r="2" fill="#fff" opacity="0.8" />
    <path d="M 47 36 Q 50 39 53 36" stroke="#fff" strokeWidth="1.5" fill="none" opacity="0.8" />
    <path d="M 45 42 Q 50 46 55 42" stroke="#fff" strokeWidth="1.5" fill="none" opacity="0.8" />
    {/* Crown / Top crest */}
    <path d="M 46 16 Q 50 12 54 16 L 50 14 Z" fill="currentColor" />
  </svg>
);

/**
 * AICTE Official Seal (Gear wheel, open book/flame, lotus motif)
 */
export const AicteEmblemSvg: React.FC<{ className?: string }> = ({ className = 'w-11 h-11' }) => (
  <svg 
    viewBox="0 0 100 100" 
    className={className} 
    fill="currentColor"
    aria-label="AICTE Emblem"
  >
    {/* Outer Gear Wheel representing Technology & Engineering */}
    <circle cx="50" cy="50" r="44" fill="#0A192F" stroke="#D97706" strokeWidth="3" />
    {/* Cog teeth */}
    {Array.from({ length: 16 }).map((_, i) => {
      const angle = (i * Math.PI) / 8;
      const x = 50 + 44 * Math.cos(angle);
      const y = 50 + 44 * Math.sin(angle);
      return (
        <circle 
          key={i} 
          cx={x} 
          cy={y} 
          r="3" 
          fill="#D97706" 
        />
      );
    })}
    <circle cx="50" cy="50" r="38" fill="none" stroke="#D97706" strokeWidth="1.5" strokeDasharray="3,2" />
    <circle cx="50" cy="50" r="34" fill="#1E3A8A" />
    
    {/* Central Knowledge Flame / Diya */}
    <path
      d="M 50 24 C 55 32 58 37 54 44 C 52 47 48 47 46 44 C 42 37 45 32 50 24 Z"
      fill="#F59E0B"
    />
    <path
      d="M 50 29 C 52 33 54 36 52 40 C 51 42 49 42 48 40 C 46 36 48 33 50 29 Z"
      fill="#FEF08A"
    />
    
    {/* Open Book of Technical Learning */}
    <path
      d="M 32 60 Q 50 56 50 63 Q 50 56 68 60 L 68 66 Q 50 62 50 69 Q 50 62 32 66 Z"
      fill="#FFFFFF"
      stroke="#D97706"
      strokeWidth="1"
    />
    
    {/* Sun / Rays */}
    <circle cx="50" cy="46" r="3" fill="#FBBF24" />
    
    {/* Inner ring text representation */}
    <text x="50" y="78" textAnchor="middle" fontSize="6" fontWeight="bold" fill="#FBBF24" letterSpacing="0.5">
      AICTE • अभाशिप
    </text>
  </svg>
);
