import React, { useState } from 'react';
import { Application, Institution } from '../types';
import { 
  Building2, AlertTriangle, CheckCircle2, FileUp, Calendar, 
  MapPin, ShieldCheck, Download, Clock, ArrowRight, Cpu 
} from 'lucide-react';
import { formatDateIndian } from '../utils/date';
import { LeaseEngineModal } from './LeaseEngineModal';

interface InstitutionPortalProps {
  institution: Institution;
  application: Application;
  currentSimulatedDate: string;
  onConfirmLeaseUpdate: (
    instId: string,
    newEndDate: string,
    newSurveyNumber: string,
    officerRemarks: string,
    ocrData: any
  ) => void;
  onSubmitInstitutionClarification: (remarks: string) => void;
}

export const InstitutionPortal: React.FC<InstitutionPortalProps> = ({
  institution,
  application,
  currentSimulatedDate,
  onConfirmLeaseUpdate,
  onSubmitInstitutionClarification,
}) => {
  const [showLeaseModal, setShowLeaseModal] = useState(false);
  const [clarificationText, setClarificationText] = useState('');
  const [submittedFeedback, setSubmittedFeedback] = useState(false);

  // Check if lease cushion is breached
  const leaseEndYear = parseInt(institution.leaseEndDate.split('-')[0], 10);
  const criticalDate = `${leaseEndYear - institution.longestCourseYears}-06-30`;
  const isLeaseCritical = currentSimulatedDate >= criticalDate;

  const handleClarificationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clarificationText.trim()) return;
    onSubmitInstitutionClarification(clarificationText);
    setSubmittedFeedback(true);
    setTimeout(() => setSubmittedFeedback(false), 4000);
    setClarificationText('');
  };

  return (
    <div className="space-y-6">
      
      {/* College Banner */}
      <div className="bg-gradient-to-r from-[#0A192F] to-blue-900 text-white rounded-lg p-5 border border-amber-500/30 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-3 bg-amber-500/20 border border-amber-500/40 rounded-lg text-amber-300">
              <Building2 className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono-code font-bold uppercase text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded border border-amber-500/30">
                  AICTE Permanent Institute ID: {institution.code}
                </span>
                <span className="text-[10px] bg-blue-800 text-blue-200 px-2 py-0.5 rounded">
                  {institution.region} Region • {institution.state}
                </span>
              </div>
              <h2 className="text-lg font-bold text-white mt-1">
                {institution.name}
              </h2>
              <p className="text-xs text-slate-300">
                SARA Portal (Student Admission &amp; Regulatory Approval System) • AY 2026-27 Approval Filing
              </p>
            </div>
          </div>

          <div className="bg-slate-900/80 p-3 rounded border border-slate-700 text-xs shrink-0">
            <div className="text-slate-400">Active Application:</div>
            <div className="font-mono-code font-bold text-amber-300 text-sm">
              {application.applicationNo}
            </div>
            <div className="text-slate-300 mt-0.5">
              Type: <strong className="text-white">{application.type}</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Critical Statutory Alert for PSG Tech (Lease Cushion) */}
      {isLeaseCritical ? (
        <div className="bg-red-50 border-l-4 border-red-600 p-4 rounded-r-md shadow-sm text-red-950">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5 shrink-0" />
              <div>
                <h4 className="font-bold text-sm text-red-900">
                  CRITICAL COMPLIANCE NOTICE: APH Clause 2.1e / 6.17a (Land Lease Cushion Expired)
                </h4>
                <p className="text-xs text-red-800 mt-1 leading-relaxed">
                  Your registered lease expires on <strong>{formatDateIndian(institution.leaseEndDate)}</strong>. 
                  Because your institution offers a <strong>{institution.longestCourseYears}-year program</strong> ({institution.longestCourseName}), 
                  the statutory Critical Date was <strong>{formatDateIndian(criticalDate)}</strong>. 
                  Under APH rules, freshmen admissions cannot be approved without a registered lease deed extension covering the complete graduation cycle (minimum 30 years).
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowLeaseModal(true)}
              className="flex items-center gap-1.5 px-4 py-2 bg-red-900 hover:bg-red-800 text-white rounded text-xs font-bold shadow-sm transition-colors cursor-pointer shrink-0"
            >
              <Cpu className="w-4 h-4 text-amber-300" />
              <span>Upload Registered Extension (OCR)</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-emerald-50 border-l-4 border-emerald-600 p-4 rounded-r-md shadow-sm text-emerald-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <div>
              <h4 className="font-bold text-sm text-emerald-900">
                Land &amp; Lease Norms Compliant (Valid till {formatDateIndian(institution.leaseEndDate)})
              </h4>
              <p className="text-xs text-emerald-800">
                Covers complete tenure of all admitted student batches per APH Chapter VI.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowLeaseModal(true)}
            className="text-xs font-semibold text-emerald-900 underline hover:text-emerald-700 cursor-pointer"
          >
            Update Deed Records
          </button>
        </div>
      )}

      {/* Main Grid: Application Status & Clarification Form */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Progress & Checklist */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Status Tracker */}
          <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
            <h3 className="font-bold text-sm text-slate-900 mb-3 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-blue-900" />
              <span>Current Approval Stage Tracking</span>
            </h3>

            <div className="p-3 bg-blue-50/60 rounded border border-blue-100 flex items-center justify-between text-xs mb-4">
              <div>
                <span className="text-slate-500 block">Regulatory State:</span>
                <span className="text-sm font-bold text-blue-950">{application.stage} ({application.status})</span>
              </div>
              <div>
                <span className="text-slate-500 block">Assigned Regional Officer:</span>
                <span className="font-semibold text-slate-800">{application.assignedOfficer}</span>
              </div>
            </div>

            {/* Checklist */}
            <div className="space-y-2 text-xs">
              <span className="font-bold text-slate-700 uppercase tracking-wider text-[11px] block">
                Scrutiny Verification Matrix:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="flex items-center justify-between p-2 bg-slate-50 rounded border border-slate-200">
                  <span>Faculty Cadre Ratio (1:20)</span>
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Compliant
                  </span>
                </div>

                <div className="flex items-center justify-between p-2 bg-slate-50 rounded border border-slate-200">
                  <span>Land &amp; Registered Lease</span>
                  {isLeaseCritical ? (
                    <span className="text-red-700 font-semibold flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" /> Expiry Notice
                    </span>
                  ) : (
                    <span className="text-emerald-700 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Verified Valid
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-between p-2 bg-slate-50 rounded border border-slate-200">
                  <span>FDR Security Deposit</span>
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Deposited
                  </span>
                </div>

                <div className="flex items-center justify-between p-2 bg-slate-50 rounded border border-slate-200">
                  <span>Fire Safety &amp; Built Area NOC</span>
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Certified
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Institutional Deficiency Response / Clarification Submission */}
          <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
            <h3 className="font-bold text-sm text-slate-900 mb-2 flex items-center gap-2">
              <FileUp className="w-4 h-4 text-blue-900" />
              <span>Submit Institutional Clarification / Compliance Undertaking</span>
            </h3>
            <p className="text-xs text-slate-500 mb-3">
              Official submissions are timestamped and inscribed directly into the AICTE Chronos Hash Ledger.
            </p>

            <form onSubmit={handleClarificationSubmit} className="space-y-3 text-xs">
              <textarea
                value={clarificationText}
                onChange={(e) => setClarificationText(e.target.value)}
                placeholder="Type your official representation or clarification to the Scrutiny Committee / Regional Officer..."
                rows={3}
                className="w-full p-2.5 border border-slate-300 rounded text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-700"
              />

              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  Authorized Signatory: Principal / Registrar
                </span>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white rounded text-xs font-bold transition-colors cursor-pointer"
                >
                  Submit Representation to AICTE RO
                </button>
              </div>

              {submittedFeedback && (
                <div className="p-2.5 bg-emerald-100 border border-emerald-300 text-emerald-800 text-xs rounded font-medium flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Representation submitted successfully and queued for Officer Scrutiny.</span>
                </div>
              )}
            </form>
          </div>

        </div>

        {/* Right 1 Col: Quick Links & Campus Specs */}
        <div className="space-y-6">
          
          <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm text-xs space-y-3">
            <h3 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] border-b border-slate-100 pb-2">
              Registered Campus Demographics
            </h3>
            <div>
              <span className="text-slate-500 block">Revenue Survey Number:</span>
              <span className="font-semibold text-slate-800">{institution.leaseSurveyNumber}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Total Land Holding:</span>
              <span className="font-semibold text-slate-800">{institution.landAreaAcres} Acres</span>
            </div>
            <div>
              <span className="text-slate-500 block">Longest Course:</span>
              <span className="font-semibold text-slate-800">
                {institution.longestCourseYears} Years ({institution.longestCourseName})
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Registered Lease Expiry:</span>
              <span className="font-mono-code font-bold text-slate-900">
                {formatDateIndian(institution.leaseEndDate)}
              </span>
            </div>
          </div>

          <div className="bg-slate-50 rounded-lg border border-slate-200 p-4 text-xs space-y-2">
            <h4 className="font-bold text-slate-800">Need Guidance on APH 2026-27 Norms?</h4>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              Refer to Chapter VI (Norms for Land, Built-up Area and Equipment) and Appendix 6 for standard forms of FDR security deposit undertakings.
            </p>
            <button
              type="button"
              onClick={() => alert('Simulated Download: AICTE_Approval_Process_Handbook_2026_27_Gazette.pdf')}
              className="flex items-center gap-1.5 text-blue-900 font-semibold hover:underline pt-1 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download APH 2026-27 PDF (4.8 MB)</span>
            </button>
          </div>

        </div>

      </div>

      {/* Lease Modal */}
      {showLeaseModal && (
        <LeaseEngineModal
          institution={institution}
          currentSimulatedDate={currentSimulatedDate}
          onClose={() => setShowLeaseModal(false)}
          onConfirmLeaseUpdate={onConfirmLeaseUpdate}
        />
      )}

    </div>
  );
};
