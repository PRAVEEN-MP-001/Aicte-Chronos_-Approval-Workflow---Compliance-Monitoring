import React, { useState } from 'react';
import { EvcInspection, Region, UserRole } from '../types';
import { 
  Eye, Calendar, UserCheck, AlertTriangle, Clock, 
  CheckCircle2, Plus, Sparkles, Building, X 
} from 'lucide-react';
import { formatDateIndian } from '../utils/date';

interface EvcQueueProps {
  evcList: EvcInspection[];
  currentUserRole: UserRole;
  selectedRegion: Region;
  onAssignPanel: (
    evcId: string,
    chairman: string,
    member1: string,
    member2: string,
    scheduledDate: string,
    remarks: string
  ) => void;
  onSubmitReport: (
    evcId: string,
    recommendation: 'RECOMMENDED_FOR_APPROVAL' | 'DEFICIENCIES_FOUND' | 'RE_INSPECTION_ADVISED',
    summary: string,
    officerRemarks: string
  ) => void;
}

export const EvcQueue: React.FC<EvcQueueProps> = ({
  evcList,
  currentUserRole,
  selectedRegion,
  onAssignPanel,
  onSubmitReport,
}) => {
  const [activeEvcForAssign, setActiveEvcForAssign] = useState<EvcInspection | null>(null);
  const [activeEvcForReport, setActiveEvcForReport] = useState<EvcInspection | null>(null);

  // Filter based on region if RO
  const filteredEvc = evcList.filter((e) => {
    if (currentUserRole === 'REGIONAL_OFFICE') {
      return e.region === selectedRegion;
    }
    return true;
  });

  // Assign Panel Modal State
  const [chairman, setChairman] = useState('Prof. A. K. Sundararajan (Dept. of Mechanical Engg., IIT Madras)');
  const [member1, setMember1] = useState('Dr. P. V. Ramana (Director, CSIR-CECRI)');
  const [member2, setMember2] = useState('Ar. Shalini Rane (Council of Architecture Certified)');
  const [scheduledDate, setScheduledDate] = useState('2026-11-05');
  const [assignRemarks, setAssignRemarks] = useState('Expert panel formed from AICTE National Roster per APH Chapter I Clause 1.10.');

  // Report Modal State
  const [recommendation, setRecommendation] = useState<'RECOMMENDED_FOR_APPROVAL' | 'DEFICIENCIES_FOUND' | 'RE_INSPECTION_ADVISED'>('RECOMMENDED_FOR_APPROVAL');
  const [reportSummary, setReportSummary] = useState('Physical verification of AI lab workstations, faculty Biometric logs, and campus boundary verified in order.');
  const [reportRemarks, setReportRemarks] = useState('Committee completed on-site inspection. Video recording and geo-tagged photographs archived.');

  const handleAssignSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeEvcForAssign) return;
    onAssignPanel(
      activeEvcForAssign.id,
      chairman,
      member1,
      member2,
      scheduledDate,
      assignRemarks
    );
    setActiveEvcForAssign(null);
  };

  const handleReportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeEvcForReport) return;
    onSubmitReport(
      activeEvcForReport.id,
      recommendation,
      reportSummary,
      reportRemarks
    );
    setActiveEvcForReport(null);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span className="font-semibold uppercase tracking-wider">Total EVC Inspections</span>
            <Eye className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 font-mono-code">
            {evcList.length}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Expert Visit Committee on-site verifications
          </p>
        </div>

        <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span className="font-semibold uppercase tracking-wider">Pending Panel Assignment</span>
            <UserCheck className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-amber-600 font-mono-code">
            {evcList.filter(e => e.status === 'PENDING_ASSIGNMENT').length}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Awaiting 3-member expert committee constitution
          </p>
        </div>

        <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span className="font-semibold uppercase tracking-wider">Overdue EVC Alerts</span>
            <AlertTriangle className="w-4 h-4 text-red-600" />
          </div>
          <div className="text-2xl font-bold text-red-600 font-mono-code">
            {evcList.filter(e => e.isOverdue || e.status === 'OVERDUE').length}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Visits delayed past statutory scheduling window
          </p>
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 pb-3 mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Eye className="w-4 h-4 text-indigo-700" />
              <span>Expert Visit Committee (EVC) Inspection Queue &amp; Roster Management</span>
            </h3>
            <p className="text-xs text-slate-500">
              Per APH Chapter I Clause 1.10: Unscheduled visits are subject to auto-escalation to Regional Director.
            </p>
          </div>

          <div className="text-xs text-slate-500">
            Showing <strong className="text-slate-900">{filteredEvc.length}</strong> queued visits
          </div>
        </div>

        {/* EVC Inspection Table */}
        <div className="overflow-x-auto border border-slate-200 rounded">
          <table className="w-full text-left text-xs divide-y divide-slate-200">
            <thead className="bg-slate-100/80 text-slate-700 font-bold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-2.5 px-3">EVC Ref &amp; College</th>
                <th className="py-2.5 px-3">Region</th>
                <th className="py-2.5 px-3">Scheduled Date</th>
                <th className="py-2.5 px-3">Assigned Expert Panel</th>
                <th className="py-2.5 px-3">Status &amp; Delay</th>
                <th className="py-2.5 px-3 text-right">Committee Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 bg-white">
              {filteredEvc.map((item) => {
                const isOverdue = item.isOverdue || item.status === 'OVERDUE';

                return (
                  <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                    
                    {/* College & Ref */}
                    <td className="py-3 px-3">
                      <div>
                        <span className="font-bold text-slate-900 block">{item.institutionName}</span>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="font-mono-code text-[11px] text-indigo-800 bg-indigo-50 px-1.5 py-0.2 rounded border border-indigo-200">
                            {item.id}
                          </span>
                          <span className="text-[11px] text-slate-400 font-mono-code">
                            {item.applicationNo}
                          </span>
                        </div>
                      </div>
                    </td>

                    {/* Region */}
                    <td className="py-3 px-3 font-medium text-slate-700">
                      {item.region}
                    </td>

                    {/* Scheduled Date */}
                    <td className="py-3 px-3">
                      {item.scheduledDate ? (
                        <div className="flex items-center gap-1.5 font-mono-code text-slate-800">
                          <Calendar className="w-3.5 h-3.5 text-blue-600" />
                          <span>{formatDateIndian(item.scheduledDate)}</span>
                        </div>
                      ) : (
                        <span className="text-amber-700 italic font-medium">Unscheduled</span>
                      )}
                    </td>

                    {/* Assigned Panel */}
                    <td className="py-3 px-3">
                      <div className="space-y-0.5 text-[11px]">
                        <div className="font-medium text-slate-800">
                          <strong>Chairman:</strong> {item.panelChairman}
                        </div>
                        {item.panelMember1 !== 'Pending Confirmation' && (
                          <div className="text-slate-500 truncate max-w-xs">
                            <strong>Member:</strong> {item.panelMember1}
                          </div>
                        )}
                      </div>
                    </td>

                    {/* Status & Delay */}
                    <td className="py-3 px-3">
                      <div>
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold border ${
                          isOverdue ? 'bg-red-50 text-red-900 border-red-300' :
                          item.status === 'PENDING_ASSIGNMENT' ? 'bg-amber-50 text-amber-900 border-amber-300' :
                          item.status === 'SCHEDULED' ? 'bg-blue-50 text-blue-900 border-blue-300' :
                          'bg-emerald-50 text-emerald-900 border-emerald-300'
                        }`}>
                          {isOverdue && <AlertTriangle className="w-3 h-3 text-red-600" />}
                          <span>{item.status}</span>
                        </span>

                        {item.delayDays > 0 && (
                          <span className="block text-[10px] text-red-700 font-mono-code font-bold mt-0.5">
                            +{item.delayDays} Days Delay Flagged
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {item.status === 'PENDING_ASSIGNMENT' ? (
                          <button
                            type="button"
                            onClick={() => setActiveEvcForAssign(item)}
                            className="flex items-center gap-1 px-2.5 py-1.5 bg-indigo-900 hover:bg-indigo-800 text-white rounded text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                          >
                            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                            <span>Assign Panel</span>
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setActiveEvcForReport(item)}
                            className="flex items-center gap-1 px-2.5 py-1.5 bg-blue-900 hover:bg-blue-800 text-white rounded text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                          >
                            <UserCheck className="w-3.5 h-3.5 text-amber-400" />
                            <span>Submit Report</span>
                          </button>
                        )}
                      </div>
                    </td>

                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assign Panel Modal */}
      {activeEvcForAssign && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-2xl max-w-xl w-full border border-slate-300 overflow-hidden text-slate-800 animate-in fade-in zoom-in-95 duration-150">
            <div className="bg-[#0A192F] text-white px-5 py-4 flex items-center justify-between border-b border-amber-500/30">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-base">Assign Expert Visit Committee (EVC) Panel</h3>
              </div>
              <button
                onClick={() => setActiveEvcForAssign(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAssignSubmit} className="p-5 space-y-3.5 text-xs">
              <div>
                <span className="text-slate-500 block">Institution:</span>
                <span className="font-bold text-slate-900 text-sm">{activeEvcForAssign.institutionName}</span>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Panel Chairman (Senior Professor / Director):
                </label>
                <input
                  type="text"
                  value={chairman}
                  onChange={(e) => setChairman(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded text-slate-900 bg-slate-50/50"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Panel Member 1 (Technical Subject Specialist):
                </label>
                <input
                  type="text"
                  value={member1}
                  onChange={(e) => setMember1(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded text-slate-900 bg-slate-50/50"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Panel Member 2 (Architect / Civil Infrastructure Expert):
                </label>
                <input
                  type="text"
                  value={member2}
                  onChange={(e) => setMember2(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded text-slate-900 bg-slate-50/50"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Proposed Inspection Date:</label>
                  <input
                    type="date"
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded text-slate-900 bg-slate-50/50 font-mono-code"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Regulatory Standard:</label>
                  <input
                    type="text"
                    readOnly
                    value="APH 2026-27 Table 1.3"
                    className="w-full p-2 border border-slate-200 rounded bg-slate-100 text-slate-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Office Remarks &amp; Justification:</label>
                <textarea
                  value={assignRemarks}
                  onChange={(e) => setAssignRemarks(e.target.value)}
                  rows={2}
                  className="w-full p-2 border border-slate-300 rounded text-slate-900"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setActiveEvcForAssign(null)}
                  className="px-4 py-2 border border-slate-300 rounded text-slate-700 hover:bg-slate-100 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-900 hover:bg-indigo-800 text-white rounded text-xs font-bold shadow-sm cursor-pointer"
                >
                  Confirm Panel Assignment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Submit Report Modal */}
      {activeEvcForReport && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-2xl max-w-xl w-full border border-slate-300 overflow-hidden text-slate-800 animate-in fade-in zoom-in-95 duration-150">
            <div className="bg-[#0A192F] text-white px-5 py-4 flex items-center justify-between border-b border-amber-500/30">
              <div className="flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-base">Submit EVC On-Site Inspection Findings</h3>
              </div>
              <button
                onClick={() => setActiveEvcForReport(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleReportSubmit} className="p-5 space-y-3.5 text-xs">
              <div>
                <span className="text-slate-500 block">Inspected Institution:</span>
                <span className="font-bold text-slate-900 text-sm">{activeEvcForReport.institutionName}</span>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  EVC Panel Recommendation:
                </label>
                <select
                  value={recommendation}
                  onChange={(e) => setRecommendation(e.target.value as any)}
                  className="w-full p-2 border border-slate-300 rounded text-slate-900 font-semibold bg-white"
                >
                  <option value="RECOMMENDED_FOR_APPROVAL">Recommended for Approval (Zero Deficiencies)</option>
                  <option value="DEFICIENCIES_FOUND">Deficiencies Identified (Refer to SAC)</option>
                  <option value="RE_INSPECTION_ADVISED">Re-Inspection Advised (Surprise EVC)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Committee Physical Verification Findings:
                </label>
                <textarea
                  value={reportSummary}
                  onChange={(e) => setReportSummary(e.target.value)}
                  rows={3}
                  className="w-full p-2 border border-slate-300 rounded text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Convener Affirmation Remarks:
                </label>
                <textarea
                  value={reportRemarks}
                  onChange={(e) => setReportRemarks(e.target.value)}
                  rows={2}
                  className="w-full p-2 border border-slate-300 rounded text-slate-900"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setActiveEvcForReport(null)}
                  className="px-4 py-2 border border-slate-300 rounded text-slate-700 hover:bg-slate-100 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white rounded text-xs font-bold shadow-sm cursor-pointer"
                >
                  Submit &amp; Append to Audit Chain
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
