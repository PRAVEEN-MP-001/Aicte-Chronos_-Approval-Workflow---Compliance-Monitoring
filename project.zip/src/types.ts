export type UserRole = 
  | 'INSTITUTION' 
  | 'REGIONAL_OFFICE' 
  | 'BUREAU_OFFICER' 
  | 'EVC_CONVENER' 
  | 'HQ_EXECUTIVE';

export type Region = 
  | 'Southern' 
  | 'Northern' 
  | 'Western' 
  | 'Eastern' 
  | 'South-Western' 
  | 'Central' 
  | 'North-Western';

export type ApplicationStage = 
  | 'SUBMISSION' 
  | 'SCRUTINY' 
  | 'EVC_INSPECTION' 
  | 'SAC_APPROVAL' 
  | 'ISSUANCE';

export type ApprovalRoutePattern = 
  | 'FULL_APH'             // Scrutiny -> EVC -> SAC -> Bureau -> Issuance (e.g. New Technical Campus)
  | 'ONLY_SCRUTINY'         // Scrutiny -> Bureau -> Issuance (e.g. Routine EoA without changes)
  | 'SCRUTINY_PLUS_EVC'     // Scrutiny -> EVC -> Bureau -> Issuance (e.g. Increase in Intake)
  | 'EVC_PLUS_SAC'          // EVC -> SAC Hearing -> Bureau (e.g. Re-inspection / Deficiencies contested)
  | 'ONLY_EVC';             // Direct EVC -> Issuance (e.g. Surprise inspection / Closure verification)

export type ApplicationStatus = 
  | 'SUBMITTED' 
  | 'UNDER_SCRUTINY' 
  | 'SCRUTINY_PASSED' 
  | 'DEFICIENCY_NOTICED' 
  | 'EVC_RECOMMENDED' 
  | 'EVC_REJECTED' 
  | 'SAC_PENDING' 
  | 'LOA_ISSUED' 
  | 'REJECTED';

export type AlertLevel = 'L1_REGIONAL' | 'L2_BUREAU' | 'L3_HQ_PENALTY';

export interface Institution {
  id: string;
  code: string;
  name: string;
  region: Region;
  state: string;
  city: string;
  longestCourseYears: number; // e.g. 4 for B.Tech, 5 for B.Arch
  longestCourseName: string;
  leaseEndDate: string; // YYYY-MM-DD
  leaseSurveyNumber: string;
  landAreaAcres: number;
  contactEmail: string;
}

export interface ScrutinyChecklist {
  facultyRatioOk: boolean;
  landNormsOk: boolean;
  fdrDepositOk: boolean;
  builtUpAreaOk: boolean;
  barrierFreeAccessOk: boolean;
}

export interface ElectronicCaseSummary {
  preparedDate: string;
  officerName: string;
  cadreRatioScore: string;
  landAdequacySummary: string;
  financialEndowmentVerified: boolean;
  evcScorePercent?: number;
  statutoryRecommendation: string;
}

export interface Application {
  id: string;
  applicationNo: string;
  institutionId: string;
  institutionName: string;
  region: Region;
  academicYear: string;
  type: 'Extension of Approval (EoA)' | 'New Technical Campus (LoA)' | 'Increase in Intake' | 'New Supernumerary Seats';
  routePattern: ApprovalRoutePattern;
  stage: ApplicationStage;
  status: ApplicationStatus;
  submissionDate: string;
  lastUpdated: string;
  daysInCurrentStage: number;
  statutorySlaDays: number; // SLA limit in days for this stage
  assignedOfficer: string;
  deficiencyCount: number;
  deficiencyNotes?: string;
  scrutinyChecklist: ScrutinyChecklist;
  electronicCaseSummary?: ElectronicCaseSummary;
}

export interface EvcInspection {
  id: string;
  applicationId: string;
  applicationNo: string;
  institutionName: string;
  region: Region;
  status: 'PENDING_ASSIGNMENT' | 'SCHEDULED' | 'VISITED' | 'REPORT_SUBMITTED' | 'OVERDUE';
  scheduledDate: string | null;
  assignedDate: string;
  panelChairman: string;
  panelMember1: string;
  panelMember2: string;
  delayDays: number;
  isOverdue: boolean;
  reportSummary?: string;
  recommendation?: 'RECOMMENDED_FOR_APPROVAL' | 'DEFICIENCIES_FOUND' | 'RE_INSPECTION_ADVISED';
}

export interface DeadlineObligation {
  id: string;
  applicationId: string;
  institutionName: string;
  type: 'APPEAL_FILING' | 'SECURITY_DEPOSIT' | 'LEASE_CRITICAL_WINDOW' | 'TIME_BOUND_UNDERTAKING';
  clause: string; // e.g. "APH 1.11a", "APH 2.25f", "APH 2.1e / 6.17a", "APH 6.1"
  title: string;
  startDate: string;
  deadlineDate: string;
  hardLimitDays: number;
  amountRequired?: number; // In INR for security deposit
  currentElapsedDays: number;
  penaltyPercentage: number;
  penaltyAmount: number;
  isBreached: boolean;
  escalationLevel: AlertLevel;
  status: 'PENDING' | 'RESOLVED' | 'BREACHED' | 'HEARING_CALLED';
}

export interface InstitutionalUndertaking {
  id: string;
  applicationId: string;
  institutionId: string;
  institutionName: string;
  region: Region;
  clause: string;
  title: string;
  prescribedCondition: string;
  dueDate: string;
  daysRemaining: number;
  submittedEvidenceDoc?: string;
  submissionDate?: string;
  verificationStatus: 'PENDING_SUBMISSION' | 'SUBMITTED_AWAITING_VERIFICATION' | 'VERIFIED_COMPLIANT' | 'DEFICIENT_OVERDUE';
  penaltyAccrued: number;
  responsibleOfficer: string;
  verificationRemarks?: string;
}

export interface SacHearing {
  id: string;
  applicationId: string;
  institutionName: string;
  hearingType: 'SAC' | 'SHC'; // Standing Appellate Committee or Standing Hearing Committee
  hearingDate: string;
  committeeMembers: string[];
  appealGrounds: string;
  verdict: 'PENDING' | 'APPEAL_UPHELD_APPROVAL_GRANTED' | 'CONDITIONAL_APPROVAL_WITH_UNDERTAKING' | 'APPEAL_DISMISSED_NO_ADMISSION';
  hearingMinutes?: string;
  recordedOfficer: string;
}

export interface RegionalPerformance {
  region: Region;
  totalApplications: number;
  clearedCount: number;
  pendingCount: number;
  overdueCount: number;
  evcOverdueCount: number;
  avgProcessingDays: number;
  complianceScore: number; // percentage
}

export interface AuditLogEntry {
  blockIndex: number;
  timestamp: string;
  actor: string;
  role: UserRole;
  action: string;
  entityId: string;
  entityName: string;
  details: string;
  previousHash: string;
  hash: string;
  statutoryAffirmation: boolean;
}

export interface OcrDeedResult {
  fileName: string;
  lessorName: string;
  lesseeName: string;
  surveyNumber: string;
  leaseStartDate: string;
  leaseEndDate: string;
  totalDurationYears: number;
  calculatedCriticalDate: string;
  confidenceScore: number;
  rawSnippet: string;
  status: 'PROPOSED' | 'CONFIRMED' | 'REJECTED';
}
