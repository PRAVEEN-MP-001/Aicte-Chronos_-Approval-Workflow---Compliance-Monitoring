/**
 * Date calculations and APH Statutory rules engine
 */

export function parseDate(dateStr: string): Date {
  return new Date(dateStr + 'T00:00:00Z');
}

export function formatDateIndian(dateStr: string | Date): string {
  const d = typeof dateStr === 'string' ? new Date(dateStr) : dateStr;
  if (isNaN(d.getTime())) return dateStr as string;
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
}

export function formatDateTimeIndian(dateStr: string | Date): string {
  const d = typeof dateStr === 'string' ? new Date(dateStr) : dateStr;
  if (isNaN(d.getTime())) return dateStr as string;
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  });
}

export function addDays(baseDateStr: string, days: number): string {
  const d = new Date(baseDateStr + 'T00:00:00Z');
  d.setDate(d.getDate() + days);
  return d.toISOString().split('T')[0];
}

export function differenceInDays(fromDateStr: string, toDateStr: string): number {
  const d1 = new Date(fromDateStr + 'T00:00:00Z').getTime();
  const d2 = new Date(toDateStr + 'T00:00:00Z').getTime();
  const diffTime = d2 - d1;
  return Math.floor(diffTime / (1000 * 60 * 60 * 24));
}

/**
 * APH 2.1e / 6.17a Formula:
 * Critical Date = Lease End Date - Duration of Longest Course (in years)
 * E.g., Lease ending 2029-06-30 for 4-year B.Tech:
 * Critical Date = 2025-06-30.
 * If current simulated date >= Critical Date, flag CRITICAL ALERT:
 * Fresh admissions cannot be granted without registered lease extension.
 */
export function calculateLeaseCriticalDate(leaseEndDateStr: string, longestCourseYears: number): {
  criticalDate: string;
  isBreached: boolean;
  yearsRemaining: number;
  daysUntilCritical: number;
  warningNotice: string;
} {
  const parts = leaseEndDateStr.split('-');
  const leaseEndYear = parseInt(parts[0], 10);
  const criticalYear = leaseEndYear - longestCourseYears;
  const criticalDate = `${criticalYear}-${parts[1] || '06'}-${parts[2] || '30'}`;

  return {
    criticalDate,
    isBreached: false, // will be evaluated against current simulated date
    yearsRemaining: 0,
    daysUntilCritical: 0,
    warningNotice: `Per APH Clause 2.1e / 6.17a: Institution running ${longestCourseYears}-yr course requires registered lease valid through full student cycle (${longestCourseYears} years prior to expiry: ${criticalDate}).`
  };
}

/**
 * APH 2.25f Security Deposit Penalty Calculator:
 * - Grace limit: 15 days
 * - Days 16 - 30: 10% penalty
 * - Days 31+: 20% penalty + Show Cause
 */
export function calculateDepositPenalty(daysElapsed: number, baseDepositAmount: number): {
  penaltyPercent: number;
  penaltyAmount: number;
  statusText: string;
  isLate: boolean;
} {
  if (daysElapsed <= 15) {
    return {
      penaltyPercent: 0,
      penaltyAmount: 0,
      statusText: `${15 - daysElapsed} days remaining within statutory window (APH 2.25f)`,
      isLate: false
    };
  } else if (daysElapsed <= 30) {
    const penaltyAmount = Math.round(baseDepositAmount * 0.10);
    return {
      penaltyPercent: 10,
      penaltyAmount,
      statusText: `L1 Statutory Violation: 10% Penalty (₹${penaltyAmount.toLocaleString('en-IN')}) levied for ${daysElapsed - 15} days delay`,
      isLate: true
    };
  } else {
    const penaltyAmount = Math.round(baseDepositAmount * 0.20);
    return {
      penaltyPercent: 20,
      penaltyAmount,
      statusText: `L3 Hard Breach: 20% Penalty (₹${penaltyAmount.toLocaleString('en-IN')}) + Show Cause Notice initiated`,
      isLate: true
    };
  }
}
