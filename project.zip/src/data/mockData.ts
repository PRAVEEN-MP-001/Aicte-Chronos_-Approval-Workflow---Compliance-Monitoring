import { 
  Application, AuditLogEntry, DeadlineObligation, EvcInspection, 
  Institution, InstitutionalUndertaking, RegionalPerformance, SacHearing 
} from '../types';
import { calculateNextHash, sha256Sync } from '../utils/crypto';

export const INITIAL_INSTITUTIONS: Institution[] = [
  {
    id: 'INST-001',
    code: '1-10948291',
    name: 'PSG College of Technology, Coimbatore',
    region: 'Southern',
    state: 'Tamil Nadu',
    city: 'Coimbatore',
    longestCourseYears: 4,
    longestCourseName: 'B.Tech in Artificial Intelligence & Robotics',
    leaseEndDate: '2029-06-30', // Critical Date: 2025-06-30 (Breached if 2026!)
    leaseSurveyNumber: 'SF No. 412/1A & 412/1B, Peelamedu Village',
    landAreaAcres: 45.2,
    contactEmail: 'principal@psgtech.edu'
  },
  {
    id: 'INST-002',
    code: '1-34829104',
    name: 'Delhi Technological University (DTU)',
    region: 'Northern',
    state: 'Delhi (NCT)',
    city: 'Rohini, New Delhi',
    longestCourseYears: 4,
    longestCourseName: 'B.Tech in Computer Science & Engineering',
    leaseEndDate: '2042-12-31',
    leaseSurveyNumber: 'Khasra No. 129/4 & 130, Bawana Road',
    landAreaAcres: 164.0,
    contactEmail: 'dean.acad@dtu.ac.in'
  },
  {
    id: 'INST-003',
    code: '1-51290344',
    name: 'Veermata Jijabai Technological Institute (VJTI)',
    region: 'Western',
    state: 'Maharashtra',
    city: 'Matunga, Mumbai',
    longestCourseYears: 4,
    longestCourseName: 'B.Tech in Mechanical Engineering',
    leaseEndDate: '2045-05-15',
    leaseSurveyNumber: 'Cadastral Survey No. 289, H.R. Mahajani Marg',
    landAreaAcres: 16.5,
    contactEmail: 'director@vjti.ac.in'
  },
  {
    id: 'INST-004',
    code: '1-74921008',
    name: 'Jadavpur University - Faculty of Engg & Tech',
    region: 'Eastern',
    state: 'West Bengal',
    city: 'Kolkata',
    longestCourseYears: 5,
    longestCourseName: 'B.Arch (Bachelor of Architecture)',
    leaseEndDate: '2050-01-01',
    leaseSurveyNumber: 'R.S. Dag No. 891, Raja S.C. Mallick Road',
    landAreaAcres: 58.0,
    contactEmail: 'dean.fet@jadavpuruniversity.in'
  },
  {
    id: 'INST-005',
    code: '1-89104721',
    name: 'R.V. College of Engineering (RVCE)',
    region: 'South-Western',
    state: 'Karnataka',
    city: 'Bengaluru',
    longestCourseYears: 4,
    longestCourseName: 'B.E. in Information Science',
    leaseEndDate: '2038-08-31',
    leaseSurveyNumber: 'Survey No. 17/1, Mysore Road, RV Vidyanikethan',
    landAreaAcres: 16.85,
    contactEmail: 'principal@rvce.edu.in'
  },
  {
    id: 'INST-006',
    code: '1-62049182',
    name: 'COEP Technological University',
    region: 'Western',
    state: 'Maharashtra',
    city: 'Shivajinagar, Pune',
    longestCourseYears: 4,
    longestCourseName: 'B.Tech in Civil Engineering',
    leaseEndDate: '2035-03-31',
    leaseSurveyNumber: 'Survey No. 5, Wellesley Road',
    landAreaAcres: 36.4,
    contactEmail: 'registrar@coep.ac.in'
  }
];

export const INITIAL_APPLICATIONS: Application[] = [
  {
    id: 'APP-2026-SR-90412',
    applicationNo: 'AICTE-SR-2026-90412',
    institutionId: 'INST-001',
    institutionName: 'PSG College of Technology, Coimbatore',
    region: 'Southern',
    academicYear: '2026-27',
    type: 'Extension of Approval (EoA)',
    routePattern: 'SCRUTINY_PLUS_EVC',
    stage: 'SCRUTINY',
    status: 'UNDER_SCRUTINY',
    submissionDate: '2026-10-15',
    lastUpdated: '2026-10-25',
    daysInCurrentStage: 12,
    statutorySlaDays: 15,
    assignedOfficer: 'Dr. R. Sundaram (RO-Chennai)',
    deficiencyCount: 1,
    deficiencyNotes: 'Per APH 2.1e/6.17a: Registered Lease expires in 2029 (< 4 years graduation cushion). Lease renewal deed required.',
    scrutinyChecklist: {
      facultyRatioOk: true,
      landNormsOk: false, // lease expiry issue
      fdrDepositOk: true,
      builtUpAreaOk: true,
      barrierFreeAccessOk: true
    },
    electronicCaseSummary: {
      preparedDate: '2026-10-25',
      officerName: 'Dr. R. Sundaram',
      cadreRatioScore: '1:18.4 (Compliant with AICTE 1:20 norm)',
      landAdequacySummary: '45.2 Acres available against 7.5 Acres requirement; Registered lease cushion deficit noted.',
      financialEndowmentVerified: true,
      statutoryRecommendation: 'Subject to submission of 30-year registered lease deed extension before EVC dispatch.'
    }
  },
  {
    id: 'APP-2026-NR-38104',
    applicationNo: 'AICTE-NR-2026-38104',
    institutionId: 'INST-002',
    institutionName: 'Delhi Technological University (DTU)',
    region: 'Northern',
    academicYear: '2026-27',
    type: 'Increase in Intake',
    routePattern: 'EVC_PLUS_SAC',
    stage: 'SCRUTINY',
    status: 'DEFICIENCY_NOTICED',
    submissionDate: '2026-10-12',
    lastUpdated: '2026-10-22',
    daysInCurrentStage: 15,
    statutorySlaDays: 15,
    assignedOfficer: 'Er. Sandeep Verma (RO-Kanpur)',
    deficiencyCount: 1,
    deficiencyNotes: 'Discrepancy in AICTE Cadre Ratio for Associate Professors in CSE Dept. Appeal filed under APH Clause 1.11a.',
    scrutinyChecklist: {
      facultyRatioOk: false,
      landNormsOk: true,
      fdrDepositOk: true,
      builtUpAreaOk: true,
      barrierFreeAccessOk: true
    },
    electronicCaseSummary: {
      preparedDate: '2026-10-22',
      officerName: 'Er. Sandeep Verma',
      cadreRatioScore: 'Shortfall of 3 Associate Professors in Dept of CSE',
      landAdequacySummary: '164.0 Acres perpetual government allotment verified.',
      financialEndowmentVerified: true,
      statutoryRecommendation: 'Refer to Standing Appellate Committee (SAC) after receipt of 7-day institutional appeal representation.'
    }
  },
  {
    id: 'APP-2026-WR-51290',
    applicationNo: 'AICTE-WR-2026-51290',
    institutionId: 'INST-003',
    institutionName: 'Veermata Jijabai Technological Institute (VJTI)',
    region: 'Western',
    academicYear: '2026-27',
    type: 'New Technical Campus (LoA)',
    routePattern: 'FULL_APH',
    stage: 'SCRUTINY',
    status: 'UNDER_SCRUTINY',
    submissionDate: '2026-10-08',
    lastUpdated: '2026-10-24',
    daysInCurrentStage: 19,
    statutorySlaDays: 15,
    assignedOfficer: 'Mrs. Pratibha Shinde (RO-Mumbai)',
    deficiencyCount: 0,
    deficiencyNotes: 'Awaiting submission of Security Deposit FDR Affidavit under APH Clause 2.25f.',
    scrutinyChecklist: {
      facultyRatioOk: true,
      landNormsOk: true,
      fdrDepositOk: false, // 12 days elapsed
      builtUpAreaOk: true,
      barrierFreeAccessOk: true
    },
    electronicCaseSummary: {
      preparedDate: '2026-10-24',
      officerName: 'Mrs. Pratibha Shinde',
      cadreRatioScore: '1:17.2 verified against sanctioned cadre',
      landAdequacySummary: 'Cadastral Survey No. 289, 16.5 Acres in Municipal Urban zone compliant.',
      financialEndowmentVerified: false,
      statutoryRecommendation: 'Security Deposit FDR of ₹15 Lakhs required within statutory 15 days window.'
    }
  },
  {
    id: 'APP-2026-ER-74921',
    applicationNo: 'AICTE-ER-2026-74921',
    institutionId: 'INST-004',
    institutionName: 'Jadavpur University - Faculty of Engg & Tech',
    region: 'Eastern',
    academicYear: '2026-27',
    type: 'Extension of Approval (EoA)',
    routePattern: 'SCRUTINY_PLUS_EVC',
    stage: 'EVC_INSPECTION',
    status: 'EVC_RECOMMENDED',
    submissionDate: '2026-09-28',
    lastUpdated: '2026-10-26',
    daysInCurrentStage: 7,
    statutorySlaDays: 10,
    assignedOfficer: 'Dr. B. K. Ghosh (RO-Kolkata)',
    deficiencyCount: 0,
    scrutinyChecklist: {
      facultyRatioOk: true,
      landNormsOk: true,
      fdrDepositOk: true,
      builtUpAreaOk: true,
      barrierFreeAccessOk: true
    },
    electronicCaseSummary: {
      preparedDate: '2026-10-20',
      officerName: 'Dr. B. K. Ghosh',
      cadreRatioScore: '1:15.8 (Exceeds norms)',
      landAdequacySummary: '58.0 Acres permanent campus verified.',
      financialEndowmentVerified: true,
      evcScorePercent: 94.5,
      statutoryRecommendation: 'Scrutiny passed. Physical on-site lab inspection queued for Expert Visit Committee.'
    }
  },
  {
    id: 'APP-2026-SW-89104',
    applicationNo: 'AICTE-SW-2026-89104',
    institutionId: 'INST-005',
    institutionName: 'R.V. College of Engineering (RVCE)',
    region: 'South-Western',
    academicYear: '2026-27',
    type: 'Extension of Approval (EoA)',
    routePattern: 'ONLY_SCRUTINY',
    stage: 'SAC_APPROVAL',
    status: 'SAC_PENDING',
    submissionDate: '2026-09-20',
    lastUpdated: '2026-10-25',
    daysInCurrentStage: 5,
    statutorySlaDays: 10,
    assignedOfficer: 'Dr. C. N. Murthy (RO-Bangalore)',
    deficiencyCount: 0,
    scrutinyChecklist: {
      facultyRatioOk: true,
      landNormsOk: true,
      fdrDepositOk: true,
      builtUpAreaOk: true,
      barrierFreeAccessOk: true
    },
    electronicCaseSummary: {
      preparedDate: '2026-10-25',
      officerName: 'Dr. C. N. Murthy',
      cadreRatioScore: '1:14.6 (Exemplary tier-1 research faculty)',
      landAdequacySummary: '16.85 Acres on Mysore Road, certified title verified.',
      financialEndowmentVerified: true,
      statutoryRecommendation: 'All APH parameters fully satisfied. Recommended for final Letter of Extension of Approval (EoA).'
    }
  },
  {
    id: 'APP-2026-WR-62049',
    applicationNo: 'AICTE-WR-62049',
    institutionId: 'INST-006',
    institutionName: 'COEP Technological University',
    region: 'Western',
    academicYear: '2026-27',
    type: 'Extension of Approval (EoA)',
    routePattern: 'ONLY_SCRUTINY',
    stage: 'ISSUANCE',
    status: 'LOA_ISSUED',
    submissionDate: '2026-09-10',
    lastUpdated: '2026-10-20',
    daysInCurrentStage: 1,
    statutorySlaDays: 5,
    assignedOfficer: 'Dr. Pratibha Shinde (RO-Mumbai)',
    deficiencyCount: 0,
    scrutinyChecklist: {
      facultyRatioOk: true,
      landNormsOk: true,
      fdrDepositOk: true,
      builtUpAreaOk: true,
      barrierFreeAccessOk: true
    },
    electronicCaseSummary: {
      preparedDate: '2026-10-20',
      officerName: 'Member Secretary, AICTE',
      cadreRatioScore: '1:15.0',
      landAdequacySummary: 'Wellesley Road heritage campus certified.',
      financialEndowmentVerified: true,
      statutoryRecommendation: 'Extension of Approval granted for Academic Year 2026-27.'
    }
  }
];

export const INITIAL_DEADLINES: DeadlineObligation[] = [
  {
    id: 'DL-001',
    applicationId: 'APP-2026-NR-38104',
    institutionName: 'Delhi Technological University (DTU)',
    type: 'APPEAL_FILING',
    clause: 'APH Clause 1.11a',
    title: 'Statutory Appeal Filing Against Scrutiny Observation',
    startDate: '2026-10-22',
    deadlineDate: '2026-10-29',
    hardLimitDays: 7,
    currentElapsedDays: 5,
    penaltyPercentage: 0,
    penaltyAmount: 0,
    isBreached: false,
    escalationLevel: 'L1_REGIONAL',
    status: 'PENDING'
  },
  {
    id: 'DL-002',
    applicationId: 'APP-2026-WR-51290',
    institutionName: 'Veermata Jijabai Technological Institute (VJTI)',
    type: 'SECURITY_DEPOSIT',
    clause: 'APH Clause 2.25f',
    title: 'Joint FDR Security Deposit Undertaking & Affidavit',
    startDate: '2026-10-15',
    deadlineDate: '2026-10-30',
    hardLimitDays: 15,
    amountRequired: 1500000, // ₹15,00,000
    currentElapsedDays: 12,
    penaltyPercentage: 0,
    penaltyAmount: 0,
    isBreached: false,
    escalationLevel: 'L1_REGIONAL',
    status: 'PENDING'
  },
  {
    id: 'DL-003',
    applicationId: 'APP-2026-SR-90412',
    institutionName: 'PSG College of Technology, Coimbatore',
    type: 'LEASE_CRITICAL_WINDOW',
    clause: 'APH Clause 2.1e / 6.17a',
    title: 'Land Lease Expiry Cushion (Critical Date Breach)',
    startDate: '2026-10-15',
    deadlineDate: '2026-11-15',
    hardLimitDays: 30,
    currentElapsedDays: 12,
    penaltyPercentage: 0,
    penaltyAmount: 0,
    isBreached: true, // Already past critical date because lease ends in 2029 for 4yr course!
    escalationLevel: 'L2_BUREAU',
    status: 'BREACHED'
  }
];

export const INITIAL_UNDERTAKINGS: InstitutionalUndertaking[] = [
  {
    id: 'UND-001',
    applicationId: 'APP-2026-SR-90412',
    institutionId: 'INST-001',
    institutionName: 'PSG College of Technology, Coimbatore',
    region: 'Southern',
    clause: 'APH Clause 2.1e & 6.17a',
    title: 'Registered Lease Extension Undertaking',
    prescribedCondition: 'Submission of registered 30-year supplemental lease deed covering uninterrupted graduation tenure.',
    dueDate: '2026-11-10',
    daysRemaining: 14,
    verificationStatus: 'PENDING_SUBMISSION',
    penaltyAccrued: 0,
    responsibleOfficer: 'Dr. R. Sundaram (RO-Chennai)'
  },
  {
    id: 'UND-002',
    applicationId: 'APP-2026-WR-51290',
    institutionId: 'INST-003',
    institutionName: 'Veermata Jijabai Technological Institute (VJTI)',
    region: 'Western',
    clause: 'APH Clause 2.25f',
    title: 'Joint Fixed Deposit Receipt (FDR) Undertaking',
    prescribedCondition: 'Joint FDR of ₹15,00,000 in favor of Regional Officer, AICTE Western Regional Office for 10-year lock-in.',
    dueDate: '2026-10-30',
    daysRemaining: 3,
    verificationStatus: 'PENDING_SUBMISSION',
    penaltyAccrued: 0,
    responsibleOfficer: 'Mrs. Pratibha Shinde (RO-Mumbai)'
  },
  {
    id: 'UND-003',
    applicationId: 'APP-2026-NR-38104',
    institutionId: 'INST-002',
    institutionName: 'Delhi Technological University (DTU)',
    region: 'Northern',
    clause: 'APH Clause 6.1 (Cadre Ratio Undertaking)',
    title: 'Faculty Cadre Recruitment Affidavit',
    prescribedCondition: 'Notarized affidavit on ₹100 stamp paper committing recruitment of 3 Associate Professors within 90 days.',
    dueDate: '2026-11-20',
    daysRemaining: 24,
    submittedEvidenceDoc: 'DTU_Faculty_Recruitment_Affidavit_Stamped.pdf',
    submissionDate: '2026-10-25',
    verificationStatus: 'SUBMITTED_AWAITING_VERIFICATION',
    penaltyAccrued: 0,
    responsibleOfficer: 'Er. Sandeep Verma (RO-Kanpur)'
  },
  {
    id: 'UND-004',
    applicationId: 'APP-2026-ER-74921',
    institutionId: 'INST-004',
    institutionName: 'Jadavpur University - Faculty of Engg & Tech',
    region: 'Eastern',
    clause: 'APH Clause 6.14',
    title: 'Structural Stability & Fire Safety Renewal Undertaking',
    prescribedCondition: 'Submission of renewed Fire Safety NOC from West Bengal Fire & Emergency Services for Architecture wing.',
    dueDate: '2026-11-05',
    daysRemaining: 9,
    submittedEvidenceDoc: 'WB_Fire_Safety_Renewal_NOC_2026.pdf',
    submissionDate: '2026-10-24',
    verificationStatus: 'VERIFIED_COMPLIANT',
    penaltyAccrued: 0,
    responsibleOfficer: 'Dr. B. K. Ghosh (RO-Kolkata)',
    verificationRemarks: 'NOC verified with issuing Fire Officer. Validity recorded till October 2027.'
  },
  {
    id: 'UND-005',
    applicationId: 'APP-2026-SW-89104',
    institutionId: 'INST-005',
    institutionName: 'R.V. College of Engineering (RVCE)',
    region: 'South-Western',
    clause: 'APH Clause 6.3',
    title: 'Building Occupancy Certificate (BCC) from BBMP',
    prescribedCondition: 'Submission of Occupancy Certificate from Bruhat Bengaluru Mahanagara Palike for new Innovation Block.',
    dueDate: '2026-11-30',
    daysRemaining: 34,
    submittedEvidenceDoc: 'BBMP_Occupancy_Cert_Innovation_Block.pdf',
    submissionDate: '2026-10-21',
    verificationStatus: 'VERIFIED_COMPLIANT',
    penaltyAccrued: 0,
    responsibleOfficer: 'Dr. C. N. Murthy (RO-Bangalore)',
    verificationRemarks: 'Civil norms compliant. Certified by Superintending Engineer BBMP.'
  }
];

export const INITIAL_EVC_QUEUE: EvcInspection[] = [
  {
    id: 'EVC-2026-001',
    applicationId: 'APP-2026-ER-74921',
    applicationNo: 'AICTE-ER-2026-74921',
    institutionName: 'Jadavpur University - Faculty of Engg & Tech',
    region: 'Eastern',
    status: 'SCHEDULED',
    assignedDate: '2026-10-20',
    scheduledDate: '2026-10-29',
    panelChairman: 'Prof. Kalyan Sengupta (Senior Prof., IIT Kharagpur)',
    panelMember1: 'Dr. Arindam Banerjee (Ex-Director, CSIR-CGCRI)',
    panelMember2: 'Ar. Subhasish Mitra (Council of Architecture Fellow)',
    delayDays: 0,
    isOverdue: false,
    reportSummary: 'Awaiting physical on-site inspection. Lab inventory & geo-tagged classroom inspection scheduled.'
  },
  {
    id: 'EVC-2026-002',
    applicationId: 'APP-2026-SR-90412',
    applicationNo: 'AICTE-SR-2026-90412',
    institutionName: 'PSG College of Technology, Coimbatore',
    region: 'Southern',
    status: 'PENDING_ASSIGNMENT',
    assignedDate: '2026-10-24',
    scheduledDate: null,
    panelChairman: 'Pending AICTE Automated Panel Roster',
    panelMember1: 'Pending Confirmation',
    panelMember2: 'Pending Confirmation',
    delayDays: 2,
    isOverdue: false,
    reportSummary: 'Document scrutiny completed. EVC inspection contingent on resolved Lease Deed undertaking.'
  },
  {
    id: 'EVC-2026-003',
    applicationId: 'APP-2026-NR-38104',
    applicationNo: 'AICTE-NR-2026-38104',
    institutionName: 'Delhi Technological University (DTU)',
    region: 'Northern',
    status: 'OVERDUE',
    assignedDate: '2026-10-10',
    scheduledDate: '2026-10-25',
    panelChairman: 'Prof. V. K. Aggarwal (IIT Delhi)',
    panelMember1: 'Prof. S. R. Sharma (NIT Kurukshetra)',
    panelMember2: 'Er. Manoj Gupta (Chief Engineer, CPWD)',
    delayDays: 2,
    isOverdue: true,
    reportSummary: 'Panel visit overdue by 2 days due to convener travel rescheduling. Triggered automated RO alert.'
  }
];

export const INITIAL_SAC_HEARINGS: SacHearing[] = [
  {
    id: 'SAC-2026-001',
    applicationId: 'APP-2026-NR-38104',
    institutionName: 'Delhi Technological University (DTU)',
    hearingType: 'SAC',
    hearingDate: '2026-11-02',
    committeeMembers: [
      'Justice (Retd.) M. K. Sharma (Chairman, SAC)',
      'Prof. K. K. Aggarwal (Former Chairman, NBA)',
      'Prof. Rajive Kumar (Member Secretary, AICTE)'
    ],
    appealGrounds: 'Institutional representation contesting Cadre Ratio calculation in CSE Department; submission of adjunct faculty credentials.',
    verdict: 'PENDING',
    recordedOfficer: 'Er. Sandeep Verma (RO-Kanpur)'
  }
];

export const INITIAL_REGIONAL_PERFORMANCE: RegionalPerformance[] = [
  {
    region: 'Southern',
    totalApplications: 412,
    clearedCount: 298,
    pendingCount: 114,
    overdueCount: 8,
    evcOverdueCount: 3,
    avgProcessingDays: 14.2,
    complianceScore: 92.4
  },
  {
    region: 'Northern',
    totalApplications: 384,
    clearedCount: 260,
    pendingCount: 124,
    overdueCount: 14,
    evcOverdueCount: 5,
    avgProcessingDays: 17.5,
    complianceScore: 86.8
  },
  {
    region: 'Western',
    totalApplications: 456,
    clearedCount: 340,
    pendingCount: 116,
    overdueCount: 11,
    evcOverdueCount: 4,
    avgProcessingDays: 15.1,
    complianceScore: 90.2
  },
  {
    region: 'Eastern',
    totalApplications: 218,
    clearedCount: 175,
    pendingCount: 43,
    overdueCount: 4,
    evcOverdueCount: 1,
    avgProcessingDays: 13.8,
    complianceScore: 94.1
  },
  {
    region: 'South-Western',
    totalApplications: 365,
    clearedCount: 288,
    pendingCount: 77,
    overdueCount: 6,
    evcOverdueCount: 2,
    avgProcessingDays: 12.9,
    complianceScore: 95.0
  },
  {
    region: 'Central',
    totalApplications: 195,
    clearedCount: 145,
    pendingCount: 50,
    overdueCount: 5,
    evcOverdueCount: 2,
    avgProcessingDays: 16.0,
    complianceScore: 89.3
  },
  {
    region: 'North-Western',
    totalApplications: 240,
    clearedCount: 182,
    pendingCount: 58,
    overdueCount: 7,
    evcOverdueCount: 3,
    avgProcessingDays: 15.6,
    complianceScore: 88.7
  }
];

export const INITIAL_AUDIT_LOG: AuditLogEntry[] = [
  {
    blockIndex: 0,
    timestamp: '2026-10-01T00:00:00Z',
    actor: 'SYSTEM_GENESIS_ROOT',
    role: 'HQ_EXECUTIVE',
    action: 'GENESIS_BLOCK_INITIALIZED',
    entityId: 'ROOT-CHRONOS-2026',
    entityName: 'National Approval Process Handbook 2026-27',
    details: 'AICTE Chronos Immutable Audit Chain deployed under IT Act 2000 & statutory mandates.',
    previousHash: '0000000000000000000000000000000000000000000000000000000000000000',
    hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    statutoryAffirmation: true
  },
  {
    blockIndex: 1,
    timestamp: '2026-10-15T10:30:14Z',
    actor: 'Er. Sandeep Verma',
    role: 'REGIONAL_OFFICE',
    action: 'SCRUTINY_DEFICIENCY_RECORDED',
    entityId: 'APP-2026-NR-38104',
    entityName: 'Delhi Technological University (DTU)',
    details: 'Officer flagged Cadre Ratio deficiency. 7-Day statutory appeal clock started per APH 1.11a.',
    previousHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    hash: sha256Sync('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855::APP-2026-NR-38104::SCRUTINY_DEFICIENCY_RECORDED'),
    statutoryAffirmation: true
  },
  {
    blockIndex: 2,
    timestamp: '2026-10-24T14:15:40Z',
    actor: 'CHRONOS_LEASE_ENGINE',
    role: 'BUREAU_OFFICER',
    action: 'CRITICAL_DATE_ALERT_TRIGGERED',
    entityId: 'APP-2026-SR-90412',
    entityName: 'PSG College of Technology, Coimbatore',
    details: 'Algorithm flagged lease end 2029 against 4-year course duration. Expiry cushion formula breached.',
    previousHash: sha256Sync('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855::APP-2026-NR-38104::SCRUTINY_DEFICIENCY_RECORDED'),
    hash: sha256Sync(sha256Sync('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855::APP-2026-NR-38104::SCRUTINY_DEFICIENCY_RECORDED') + '::APP-2026-SR-90412::CRITICAL_DATE_ALERT_TRIGGERED'),
    statutoryAffirmation: true
  }
];

export const SAMPLE_OCR_DOCUMENTS = [
  {
    id: 'SAMPLE-1',
    name: 'PSG_Tech_Registered_Lease_Deed_1999_2029.pdf',
    description: 'Registered 30-year Perpetual Lease (Expiring June 2029 - Triggers Critical Alert)',
    institutionName: 'PSG College of Technology, Coimbatore',
    extractedData: {
      lessorName: 'PSG & Sons Charities Trust (Represented by Managing Trustee)',
      lesseeName: 'PSG College of Technology (Governing Council)',
      surveyNumber: 'SF No. 412/1A, 412/1B, Peelamedu Village, Coimbatore Taluk',
      leaseStartDate: '1999-07-01',
      leaseEndDate: '2029-06-30',
      totalDurationYears: 30,
      confidenceScore: 98.4,
      rawSnippet: '...THIS INDENTURE OF LEASE entered on 1st July 1999 BETWEEN PSG & SONS CHARITIES... for a period of 30 (Thirty) Years expiring on 30th June 2029...'
    }
  },
  {
    id: 'SAMPLE-2',
    name: 'PSG_Tech_Supplemental_Lease_Extension_2026_2056.pdf',
    description: 'Supplemental Deed of 30-year Extension (Valid till June 2056 - Resolves Critical Alert)',
    institutionName: 'PSG College of Technology, Coimbatore',
    extractedData: {
      lessorName: 'PSG & Sons Charities Trust (Registration Vol. 410, Page 88)',
      lesseeName: 'PSG College of Technology, Peelamedu',
      surveyNumber: 'SF No. 412/1A, 412/1B & 413/2 (Registered at Gandhipuram SRO)',
      leaseStartDate: '2026-04-01',
      leaseEndDate: '2056-03-31',
      totalDurationYears: 30,
      confidenceScore: 99.1,
      rawSnippet: '...REGISTERED SUPPLEMENTAL DEED OF LEASE EXTENSION: The lessor hereby extends the demise of technical campus premises for a further period of 30 years up to 31st March 2056 in compliance with AICTE APH Chapter VI...'
    }
  },
  {
    id: 'SAMPLE-3',
    name: 'DTU_Government_Allotment_Deed_Permanent.pdf',
    description: 'Delhi Government Allotment Notification & Registered Perpetual Lease',
    institutionName: 'Delhi Technological University (DTU)',
    extractedData: {
      lessorName: 'Lt. Governor of NCT of Delhi / Land & Building Dept',
      lesseeName: 'Delhi Technological University (Formerly Delhi College of Engineering)',
      surveyNumber: 'Khasra No. 129/4 & 130, Shahbad Daulatpur, Bawana Road',
      leaseStartDate: '1992-01-01',
      leaseEndDate: '2042-12-31',
      totalDurationYears: 50,
      confidenceScore: 96.8,
      rawSnippet: '...Perpetual allotment of 164.0 Acres for Delhi College of Engineering campus, subject to statutory covenants and uninterrupted educational use...'
    }
  }
];
