import React, { useState } from 'react';
import { 
  Application, ApplicationStage, AuditLogEntry, DeadlineObligation, 
  EvcInspection, Institution, InstitutionalUndertaking, Region, SacHearing, UserRole 
} from './types';
import { 
  INITIAL_APPLICATIONS, INITIAL_AUDIT_LOG, INITIAL_DEADLINES, 
  INITIAL_EVC_QUEUE, INITIAL_INSTITUTIONS, INITIAL_SAC_HEARINGS, INITIAL_UNDERTAKINGS 
} from './data/mockData';
import { addDays, differenceInDays } from './utils/date';
import { calculateNextHash } from './utils/crypto';
import { Header } from './components/Header';
import { DemoClockBar } from './components/DemoClockBar';
import { StatutoryBanner } from './components/StatutoryBanner';
import { WorkflowEngine } from './components/WorkflowEngine';
import { PendencyAnalytics } from './components/PendencyAnalytics';
import { DeadlineLedger } from './components/DeadlineLedger';
import { EvcQueue } from './components/EvcQueue';
import { UndertakingsTracker } from './components/UndertakingsTracker';
import { EscalationMatrix } from './components/EscalationMatrix';
import { ReportsCenter } from './components/ReportsCenter';
import { AuditLogChain } from './components/AuditLogChain';
import { InstitutionPortal } from './components/InstitutionPortal';
import { SacHearingsModal } from './components/SacHearingsModal';
import { 
  FileCheck2, Hourglass, Eye, ShieldAlert, 
  Lock, Building2, BarChart3, CheckCircle2, FileSpreadsheet, Scale, FileText 
} from 'lucide-react';

export default function App() {
  // Base Date
  const BASE_DATE = '2026-10-27';
  
  // State
  const [currentRole, setCurrentRole] = useState<UserRole>('BUREAU_OFFICER');
  const [selectedRegion, setSelectedRegion] = useState<Region>('Southern');
  const [simulatedDate, setSimulatedDate] = useState<string>(BASE_DATE);
  const [daysShifted, setDaysShifted] = useState<number>(0);

  // Active module tab
  const [activeTab, setActiveTab] = useState<
    'WORKFLOW' | 'PENDENCY' | 'DEADLINES' | 'EVC' | 'UNDERTAKINGS' | 'ESCALATIONS' | 'REPORTS' | 'AUDIT_LOG'
  >('WORKFLOW');

  // Core Data
  const [institutions, setInstitutions] = useState<Institution[]>(INITIAL_INSTITUTIONS);
  const [applications, setApplications] = useState<Application[]>(INITIAL_APPLICATIONS);
  const [deadlines, setDeadlines] = useState<DeadlineObligation[]>(INITIAL_DEADLINES);
  const [undertakings, setUndertakings] = useState<InstitutionalUndertaking[]>(INITIAL_UNDERTAKINGS);
  const [evcQueue, setEvcQueue] = useState<EvcInspection[]>(INITIAL_EVC_QUEUE);
  const [sacHearings, setSacHearings] = useState<SacHearing[]>(INITIAL_SAC_HEARINGS);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(INITIAL_AUDIT_LOG);

  // Active SAC modal
  const [activeSacHearing, setActiveSacHearing] = useState<SacHearing | null>(null);

  // Notification Toast Banner
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'alert' } | null>(null);

  const showToast = (text: string, type: 'success' | 'alert' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4500);
  };

  // Helper to append a new hash-chained block to the immutable audit log
  const appendAuditLog = (
    actor: string,
    role: UserRole,
    action: string,
    entityId: string,
    entityName: string,
    details: string
  ) => {
    const prevBlock = auditLogs[auditLogs.length - 1];
    const prevHash = prevBlock ? prevBlock.hash : '0000000000000000000000000000000000000000000000000000000000000000';
    const blockIndex = auditLogs.length;
    const timestamp = new Date().toISOString();

    const payload = {
      blockIndex,
      timestamp,
      actor,
      role,
      action,
      entityId,
      entityName,
      details,
      statutoryAffirmation: true
    };

    const newHash = calculateNextHash(prevHash, payload);

    const newEntry: AuditLogEntry = {
      ...payload,
      previousHash: prevHash,
      hash: newHash
    };

    setAuditLogs((prev) => [...prev, newEntry]);
  };

  // Time Travel Handler: Recalculates all deadline clocks, penalties, and EVC overdue flags!
  const updateStateForSimulatedDate = (newDateStr: string, totalDaysShifted: number) => {
    setSimulatedDate(newDateStr);
    setDaysShifted(totalDaysShifted);

    // 1. Recalculate Deadline Obligations
    setDeadlines((prev) =>
      prev.map((d) => {
        const elapsed = differenceInDays(d.startDate, newDateStr);
        const isBreached = elapsed > d.hardLimitDays;
        
        let escalation = d.escalationLevel;
        if (isBreached) {
          escalation = 'L3_HQ_PENALTY';
        } else if (elapsed >= d.hardLimitDays * 0.7) {
          escalation = 'L2_BUREAU';
        }

        return {
          ...d,
          currentElapsedDays: Math.max(0, elapsed),
          isBreached,
          escalationLevel: escalation,
          status: isBreached && d.status === 'PENDING' ? 'BREACHED' : d.status
        };
      })
    );

    // 2. Recalculate Time-Bound Undertakings
    setUndertakings((prev) =>
      prev.map((u) => {
        const remaining = differenceInDays(newDateStr, u.dueDate);
        const isOverdue = remaining < 0 && u.verificationStatus !== 'VERIFIED_COMPLIANT';
        return {
          ...u,
          daysRemaining: remaining,
          verificationStatus: isOverdue ? 'DEFICIENT_OVERDUE' : u.verificationStatus
        };
      })
    );

    // 3. Recalculate Application Ageing
    setApplications((prev) =>
      prev.map((app) => {
        const initialAgeing = app.daysInCurrentStage;
        const newAgeing = initialAgeing + (totalDaysShifted - daysShifted);
        return {
          ...app,
          daysInCurrentStage: Math.max(1, newAgeing)
        };
      })
    );

    // 4. Recalculate EVC Delays & Overdues
    setEvcQueue((prev) =>
      prev.map((evc) => {
        if (!evc.scheduledDate) return evc;
        const diff = differenceInDays(evc.scheduledDate, newDateStr);
        const isOverdue = diff > 0 && evc.status === 'SCHEDULED';
        return {
          ...evc,
          isOverdue,
          delayDays: Math.max(0, diff),
          status: isOverdue ? 'OVERDUE' : evc.status
        };
      })
    );

    appendAuditLog(
      'CHRONOS_TIME_ENGINE',
      'HQ_EXECUTIVE',
      'TIME_SHIFT_OBSERVED',
      'CLOCK-SIMULATOR',
      'AICTE Chronos Ledger Clock',
      `Ledger date fast-forwarded to ${newDateStr} (+${totalDaysShifted} days). Statutory compliance countdowns recalculated.`
    );

    showToast(`Chronos clock advanced to ${newDateStr} (+${totalDaysShifted}d). Deadlines and penalties recalculated.`);
  };

  const handleAdvanceDays = (days: number) => {
    const newTotal = daysShifted + days;
    const newDate = addDays(BASE_DATE, newTotal);
    updateStateForSimulatedDate(newDate, newTotal);
  };

  const handleResetClock = () => {
    updateStateForSimulatedDate(BASE_DATE, 0);
  };

  const handleSetCustomDate = (dateStr: string) => {
    const days = differenceInDays(BASE_DATE, dateStr);
    updateStateForSimulatedDate(dateStr, days);
  };

  // Workflow Human Gate Handlers
  const handleAdvanceStage = (
    appId: string,
    nextStage: ApplicationStage,
    remarks: string,
    officerName: string
  ) => {
    const targetApp = applications.find(a => a.id === appId);
    if (!targetApp) return;

    let newStatus = targetApp.status;
    if (nextStage === 'EVC_INSPECTION') newStatus = 'EVC_RECOMMENDED';
    else if (nextStage === 'SAC_APPROVAL') newStatus = 'SAC_PENDING';
    else if (nextStage === 'ISSUANCE') newStatus = 'LOA_ISSUED';
    else if (nextStage === 'SCRUTINY') newStatus = 'UNDER_SCRUTINY';

    setApplications(prev =>
      prev.map(app =>
        app.id === appId
          ? {
              ...app,
              stage: nextStage,
              status: newStatus,
              daysInCurrentStage: 1, // reset ageing clock for new stage
              lastUpdated: simulatedDate
            }
          : app
      )
    );

    appendAuditLog(
      officerName,
      currentRole,
      'STAGE_ADVANCED',
      appId,
      targetApp.institutionName,
      `Advanced application stage from ${targetApp.stage} to ${nextStage}. Officer remarks: "${remarks}"`
    );

    showToast(`Application ${targetApp.applicationNo} successfully advanced to ${nextStage}. Inscribed into block #${auditLogs.length}.`);
  };

  const handleReturnDeficiency = (
    appId: string,
    deficiencyNotes: string,
    remarks: string,
    officerName: string
  ) => {
    const targetApp = applications.find(a => a.id === appId);
    if (!targetApp) return;

    setApplications(prev =>
      prev.map(app =>
        app.id === appId
          ? {
              ...app,
              status: 'DEFICIENCY_NOTICED',
              deficiencyCount: app.deficiencyCount + 1,
              deficiencyNotes,
              lastUpdated: simulatedDate
            }
          : app
      )
    );

    // Create a new 7-Day Appeal Filing obligation under APH 1.11a
    const newDeadline: DeadlineObligation = {
      id: `DL-APP-${Date.now().toString().slice(-4)}`,
      applicationId: appId,
      institutionName: targetApp.institutionName,
      type: 'APPEAL_FILING',
      clause: 'APH Clause 1.11a',
      title: 'Statutory Appeal Filing Against Scrutiny Deficiency',
      startDate: simulatedDate,
      deadlineDate: addDays(simulatedDate, 7),
      hardLimitDays: 7,
      currentElapsedDays: 0,
      penaltyPercentage: 0,
      penaltyAmount: 0,
      isBreached: false,
      escalationLevel: 'L1_REGIONAL',
      status: 'PENDING'
    };

    setDeadlines(prev => [newDeadline, ...prev]);

    appendAuditLog(
      officerName,
      currentRole,
      'DEFICIENCY_NOTICE_ISSUED',
      appId,
      targetApp.institutionName,
      `Issued deficiency notice: "${deficiencyNotes}". 7-Day Appeal Clock activated per APH 1.11a.`
    );

    showToast(`Deficiency notice issued to ${targetApp.institutionName}. 7-Day appeal clock initiated.`, 'alert');
  };

  const handleVerifyChecklist = (
    appId: string,
    checklist: Application['scrutinyChecklist'],
    remarks: string,
    officerName: string
  ) => {
    const targetApp = applications.find(a => a.id === appId);
    if (!targetApp) return;

    setApplications(prev =>
      prev.map(app =>
        app.id === appId
          ? {
              ...app,
              scrutinyChecklist: { ...checklist },
              lastUpdated: simulatedDate
            }
          : app
      )
    );

    appendAuditLog(
      officerName,
      currentRole,
      'SCRUTINY_CHECKLIST_VERIFIED',
      appId,
      targetApp.institutionName,
      `Verified scrutiny norms checklist. Officer notes: "${remarks}"`
    );

    showToast(`Checklist verified for ${targetApp.institutionName}.`);
  };

  // Lease OCR Confirm Handler
  const handleConfirmLeaseUpdate = (
    instId: string,
    newEndDate: string,
    newSurveyNumber: string,
    officerRemarks: string,
    ocrData: any
  ) => {
    const inst = institutions.find(i => i.id === instId);
    if (!inst) return;

    setInstitutions(prev =>
      prev.map(i =>
        i.id === instId
          ? {
              ...i,
              leaseEndDate: newEndDate,
              leaseSurveyNumber: newSurveyNumber
            }
          : i
      )
    );

    // Update related deadline obligation
    setDeadlines(prev =>
      prev.map(d => {
        if (d.institutionName.includes(inst.name.split(' ')[0]) && d.type === 'LEASE_CRITICAL_WINDOW') {
          return {
            ...d,
            isBreached: false,
            status: 'RESOLVED',
            escalationLevel: 'L1_REGIONAL'
          };
        }
        return d;
      })
    );

    // Update related undertaking
    setUndertakings(prev =>
      prev.map(u => {
        if (u.institutionId === instId && u.clause.includes('2.1e')) {
          return {
            ...u,
            verificationStatus: 'VERIFIED_COMPLIANT',
            submittedEvidenceDoc: ocrData.fileName || 'PSG_Supplemental_Lease_2056.pdf',
            verificationRemarks: 'Registered 30-year supplemental lease verified by Regional Officer.'
          };
        }
        return u;
      })
    );

    // Clear deficiency if on PSG Tech application
    setApplications(prev =>
      prev.map(app => {
        if (app.institutionId === instId) {
          return {
            ...app,
            deficiencyCount: Math.max(0, app.deficiencyCount - 1),
            scrutinyChecklist: {
              ...app.scrutinyChecklist,
              landNormsOk: true
            }
          };
        }
        return app;
      })
    );

    appendAuditLog(
      'Dr. R. Sundaram (Sr. Regional Officer)',
      'BUREAU_OFFICER',
      'LEASE_DEED_EXTENSION_CONFIRMED',
      instId,
      inst.name,
      `OCR Lease extraction confirmed and committed. New Lease Expiry: ${newEndDate}. Survey: ${newSurveyNumber}. Remarks: "${officerRemarks}"`
    );

    showToast(`Registered lease deed for ${inst.name} confirmed until ${newEndDate}. Critical alert resolved!`);
  };

  // EVC Panel Assignment Handler
  const handleAssignPanel = (
    evcId: string,
    chairman: string,
    member1: string,
    member2: string,
    scheduledDateStr: string,
    remarks: string
  ) => {
    const evc = evcQueue.find(e => e.id === evcId);
    if (!evc) return;

    setEvcQueue(prev =>
      prev.map(e =>
        e.id === evcId
          ? {
              ...e,
              panelChairman: chairman,
              panelMember1: member1,
              panelMember2: member2,
              scheduledDate: scheduledDateStr,
              status: 'SCHEDULED'
            }
          : e
      )
    );

    appendAuditLog(
      'Regional Officer (AICTE Southern Office)',
      'REGIONAL_OFFICE',
      'EVC_PANEL_CONSTITUTED',
      evcId,
      evc.institutionName,
      `Assigned 3-member EVC panel: Chairman ${chairman}. Scheduled Date: ${scheduledDateStr}. Remarks: "${remarks}"`
    );

    showToast(`EVC panel assigned for ${evc.institutionName}. Scheduled for ${scheduledDateStr}.`);
  };

  // EVC Report Submit Handler
  const handleSubmitEvcReport = (
    evcId: string,
    recommendation: any,
    summary: string,
    officerRemarks: string
  ) => {
    const evc = evcQueue.find(e => e.id === evcId);
    if (!evc) return;

    setEvcQueue(prev =>
      prev.map(e =>
        e.id === evcId
          ? {
              ...e,
              status: 'REPORT_SUBMITTED',
              recommendation,
              reportSummary: summary
            }
          : e
      )
    );

    appendAuditLog(
      'EVC Committee Convener',
      'EVC_CONVENER',
      'EVC_REPORT_SUBMITTED',
      evcId,
      evc.institutionName,
      `Submitted inspection findings: Recommendation [${recommendation}]. Summary: "${summary}"`
    );

    showToast(`EVC Inspection report submitted for ${evc.institutionName}.`);
  };

  // Time-Bound Undertaking Handlers
  const handleVerifyUndertaking = (
    undertakingId: string,
    status: 'VERIFIED_COMPLIANT' | 'DEFICIENT_OVERDUE',
    remarks: string,
    officerName: string
  ) => {
    const target = undertakings.find(u => u.id === undertakingId);
    if (!target) return;

    setUndertakings(prev =>
      prev.map(u =>
        u.id === undertakingId
          ? {
              ...u,
              verificationStatus: status,
              verificationRemarks: remarks,
              responsibleOfficer: officerName
            }
          : u
      )
    );

    appendAuditLog(
      officerName,
      currentRole,
      'UNDERTAKING_EVIDENCE_VERIFIED',
      undertakingId,
      target.institutionName,
      `Verified compliance evidence for ${target.clause} (${target.title}). Outcome: ${status}. Remarks: "${remarks}"`
    );

    showToast(`Undertaking ${target.clause} verified for ${target.institutionName}. Inscribed into audit chain.`);
  };

  const handleSubmitEvidence = (
    undertakingId: string,
    fileName: string,
    notes: string
  ) => {
    const target = undertakings.find(u => u.id === undertakingId);
    if (!target) return;

    setUndertakings(prev =>
      prev.map(u =>
        u.id === undertakingId
          ? {
              ...u,
              submittedEvidenceDoc: fileName,
              submissionDate: simulatedDate,
              verificationStatus: 'SUBMITTED_AWAITING_VERIFICATION'
            }
          : u
      )
    );

    appendAuditLog(
      'Institution Authorized Signatory',
      'INSTITUTION',
      'UNDERTAKING_EVIDENCE_SUBMITTED',
      undertakingId,
      target.institutionName,
      `Submitted evidence document "${fileName}" for ${target.clause}. Notes: "${notes}"`
    );

    showToast(`Evidence submitted for ${target.title}. Queued for Officer verification.`);
  };

  // SAC Hearing Verdict Handler
  const handleSubmitSacVerdict = (
    hearingId: string,
    verdict: SacHearing['verdict'],
    minutes: string,
    officerRemarks: string
  ) => {
    const hearing = sacHearings.find(h => h.id === hearingId);
    if (!hearing) return;

    setSacHearings(prev =>
      prev.map(h =>
        h.id === hearingId
          ? {
              ...h,
              verdict,
              hearingMinutes: minutes
            }
          : h
      )
    );

    // If appeal upheld or conditional, advance related application
    if (verdict === 'APPEAL_UPHELD_APPROVAL_GRANTED' || verdict === 'CONDITIONAL_APPROVAL_WITH_UNDERTAKING') {
      setApplications(prev =>
        prev.map(a =>
          a.id === hearing.applicationId
            ? {
                ...a,
                stage: 'ISSUANCE',
                status: 'LOA_ISSUED',
                deficiencyCount: 0
              }
            : a
        )
      );
    }

    appendAuditLog(
      'Chairman, Standing Appellate Committee',
      'HQ_EXECUTIVE',
      'SAC_VERDICT_DELIVERED',
      hearingId,
      hearing.institutionName,
      `Appellate Bench issued verdict: [${verdict}]. Minutes: "${minutes}". Remarks: "${officerRemarks}"`
    );

    showToast(`SAC Verdict [${verdict}] recorded for ${hearing.institutionName}. Application advanced.`);
  };

  // Resolve Obligation Handler
  const handleResolveObligation = (obligationId: string, remarks: string) => {
    const ob = deadlines.find(d => d.id === obligationId);
    if (!ob) return;

    setDeadlines(prev =>
      prev.map(d =>
        d.id === obligationId
          ? {
              ...d,
              status: 'RESOLVED',
              isBreached: false
            }
          : d
      )
    );

    appendAuditLog(
      'Compliance Officer (HQ Bureau)',
      'BUREAU_OFFICER',
      'OBLIGATION_RESOLVED',
      obligationId,
      ob.institutionName,
      `Compliance recorded for ${ob.clause} (${ob.title}). Officer remarks: "${remarks}"`
    );

    showToast(`Obligation ${ob.clause} resolved for ${ob.institutionName}.`);
  };

  // Escalation Notice Handler
  const handleTriggerEscalationNotice = (
    title: string,
    institutionName: string,
    level: string,
    clause: string
  ) => {
    appendAuditLog(
      'Statutory Vigilance Cell',
      'HQ_EXECUTIVE',
      'STATUTORY_SHOW_CAUSE_ISSUED',
      `ESC-${Date.now().toString().slice(-4)}`,
      institutionName,
      `Formal statutory notice dispatched under ${clause} (${level}). Summons issued to Principal for Standing Appellate hearing.`
    );
  };

  // Institution representation submission
  const handleSubmitInstitutionClarification = (remarks: string) => {
    appendAuditLog(
      'PSG Tech Principal & Authorized Signatory',
      'INSTITUTION',
      'INSTITUTIONAL_REPRESENTATION_FILED',
      'INST-001',
      'PSG College of Technology, Coimbatore',
      `College filed official clarification representation: "${remarks}"`
    );
    showToast('Representation submitted to Regional Officer.');
  };

  // Calculations for top alert pills
  const activeBreaches = deadlines.filter(d => d.isBreached).length;
  const activeUrgents = deadlines.filter(d => !d.isBreached && d.currentElapsedDays >= d.hardLimitDays * 0.7).length;

  return (
    <div className="min-h-screen bg-slate-100/90 text-slate-800 flex flex-col">
      
      {/* Official Government of India & AICTE Header */}
      <Header
        currentRole={currentRole}
        onRoleChange={setCurrentRole}
        selectedRegion={selectedRegion}
        onRegionChange={setSelectedRegion}
        simulatedDate={simulatedDate}
        urgentCount={activeUrgents}
        breachCount={activeBreaches}
      />

      {/* Module F: Shiftable Demo Clock Controller */}
      <DemoClockBar
        simulatedDate={simulatedDate}
        onAdvanceDays={handleAdvanceDays}
        onResetClock={handleResetClock}
        onSetDate={handleSetCustomDate}
        baseDate={BASE_DATE}
        daysShifted={daysShifted}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex-1 w-full space-y-5">
        
        {/* Statutory Safeguard Banner */}
        <StatutoryBanner />

        {/* Dynamic Toast Feedback Notification */}
        {toastMessage && (
          <div className={`p-3 rounded-md text-xs font-semibold flex items-center justify-between shadow-md transition-all animate-in fade-in duration-150 ${
            toastMessage.type === 'alert'
              ? 'bg-red-900 text-white border border-red-700'
              : 'bg-emerald-900 text-white border border-emerald-700'
          }`}>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-amber-300" />
              <span>{toastMessage.text}</span>
            </div>
            <button
              onClick={() => setToastMessage(null)}
              className="text-white/70 hover:text-white text-xs cursor-pointer ml-3"
            >
              ✕
            </button>
          </div>
        )}

        {/* If Role is INSTITUTION, render the dedicated SARA College Portal */}
        {currentRole === 'INSTITUTION' ? (
          <InstitutionPortal
            institution={institutions[0]}
            application={applications[0]}
            currentSimulatedDate={simulatedDate}
            onConfirmLeaseUpdate={handleConfirmLeaseUpdate}
            onSubmitInstitutionClarification={handleSubmitInstitutionClarification}
          />
        ) : (
          <>
            {/* Navigation Tabs for Officer / HQ / EVC views */}
            <div className="border-b border-slate-300 flex flex-wrap items-center justify-between gap-2">
              <nav className="flex space-x-1 sm:space-x-1.5 -mb-px overflow-x-auto">
                
                <button
                  onClick={() => setActiveTab('WORKFLOW')}
                  className={`flex items-center gap-1.5 py-2.5 px-3 border-b-2 text-xs font-bold transition-colors cursor-pointer ${
                    activeTab === 'WORKFLOW'
                      ? 'border-blue-900 text-blue-900 bg-white shadow-2xs rounded-t'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                  }`}
                >
                  <FileCheck2 className="w-4 h-4 text-blue-800" />
                  <span>Workflow &amp; Human Gate</span>
                  <span className="ml-1 text-[10px] font-mono-code bg-blue-100 text-blue-900 px-1.5 py-0.2 rounded">
                    {applications.length}
                  </span>
                </button>

                <button
                  onClick={() => setActiveTab('PENDENCY')}
                  className={`flex items-center gap-1.5 py-2.5 px-3 border-b-2 text-xs font-bold transition-colors cursor-pointer ${
                    activeTab === 'PENDENCY'
                      ? 'border-blue-900 text-blue-900 bg-white shadow-2xs rounded-t'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                  }`}
                >
                  <BarChart3 className="w-4 h-4 text-emerald-800" />
                  <span>Pendency &amp; Ageing</span>
                </button>

                <button
                  onClick={() => setActiveTab('EVC')}
                  className={`flex items-center gap-1.5 py-2.5 px-3 border-b-2 text-xs font-bold transition-colors cursor-pointer ${
                    activeTab === 'EVC'
                      ? 'border-blue-900 text-blue-900 bg-white shadow-2xs rounded-t'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                  }`}
                >
                  <Eye className="w-4 h-4 text-indigo-700" />
                  <span>EVC Queue</span>
                  <span className="ml-1 text-[10px] font-mono-code bg-indigo-100 text-indigo-900 px-1.5 py-0.2 rounded">
                    {evcQueue.length}
                  </span>
                </button>

                <button
                  onClick={() => setActiveTab('UNDERTAKINGS')}
                  className={`flex items-center gap-1.5 py-2.5 px-3 border-b-2 text-xs font-bold transition-colors cursor-pointer ${
                    activeTab === 'UNDERTAKINGS'
                      ? 'border-blue-900 text-blue-900 bg-white shadow-2xs rounded-t'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4 text-teal-700" />
                  <span>Time-Bound Undertakings</span>
                  <span className="ml-1 text-[10px] font-mono-code bg-teal-100 text-teal-900 px-1.5 py-0.2 rounded">
                    {undertakings.length}
                  </span>
                </button>

                <button
                  onClick={() => setActiveTab('DEADLINES')}
                  className={`flex items-center gap-1.5 py-2.5 px-3 border-b-2 text-xs font-bold transition-colors cursor-pointer ${
                    activeTab === 'DEADLINES'
                      ? 'border-blue-900 text-blue-900 bg-white shadow-2xs rounded-t'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                  }`}
                >
                  <Hourglass className="w-4 h-4 text-amber-700" />
                  <span>Deadline Ledger &amp; Lease</span>
                  {activeBreaches > 0 && (
                    <span className="ml-1 text-[10px] font-mono-code bg-red-600 text-white px-1.5 py-0.2 rounded font-bold">
                      {activeBreaches}
                    </span>
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('ESCALATIONS')}
                  className={`flex items-center gap-1.5 py-2.5 px-3 border-b-2 text-xs font-bold transition-colors cursor-pointer ${
                    activeTab === 'ESCALATIONS'
                      ? 'border-blue-900 text-blue-900 bg-white shadow-2xs rounded-t'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                  }`}
                >
                  <ShieldAlert className="w-4 h-4 text-red-700" />
                  <span>Escalation Ladder</span>
                </button>

                <button
                  onClick={() => setActiveTab('REPORTS')}
                  className={`flex items-center gap-1.5 py-2.5 px-3 border-b-2 text-xs font-bold transition-colors cursor-pointer ${
                    activeTab === 'REPORTS'
                      ? 'border-blue-900 text-blue-900 bg-white shadow-2xs rounded-t'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                  }`}
                >
                  <FileSpreadsheet className="w-4 h-4 text-purple-700" />
                  <span>Gazette Reports</span>
                </button>

                <button
                  onClick={() => setActiveTab('AUDIT_LOG')}
                  className={`flex items-center gap-1.5 py-2.5 px-3 border-b-2 text-xs font-bold transition-colors cursor-pointer ${
                    activeTab === 'AUDIT_LOG'
                      ? 'border-blue-900 text-blue-900 bg-white shadow-2xs rounded-t'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                  }`}
                >
                  <Lock className="w-4 h-4 text-emerald-700" />
                  <span>Audit Ledger</span>
                  <span className="ml-1 text-[10px] font-mono-code bg-emerald-100 text-emerald-900 px-1.5 py-0.2 rounded">
                    #{auditLogs.length - 1}
                  </span>
                </button>

              </nav>

              {/* SAC Hearing Trigger Button if any active appeal */}
              <div className="flex items-center gap-2">
                {sacHearings.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setActiveSacHearing(sacHearings[0])}
                    className="flex items-center gap-1 px-2.5 py-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-900 border border-amber-500/40 rounded text-xs font-bold cursor-pointer transition-colors"
                  >
                    <Scale className="w-3.5 h-3.5 text-amber-700" />
                    <span>Convene SAC Hearing ({sacHearings.length})</span>
                  </button>
                )}
                
                <div className="text-[11px] font-mono-code text-slate-500 hidden xl:flex items-center gap-1 pb-1">
                  <span>Profile:</span>
                  <span className="font-bold text-slate-900 bg-white px-2 py-0.5 rounded border border-slate-200">
                    {currentRole}
                  </span>
                </div>
              </div>
            </div>

            {/* Tab Views */}
            {activeTab === 'WORKFLOW' && (
              <WorkflowEngine
                applications={applications}
                institutions={institutions}
                currentUserRole={currentRole}
                selectedRegion={selectedRegion}
                onAdvanceStage={handleAdvanceStage}
                onReturnDeficiency={handleReturnDeficiency}
                onVerifyChecklist={handleVerifyChecklist}
              />
            )}

            {activeTab === 'PENDENCY' && (
              <PendencyAnalytics
                applications={applications}
                selectedRegion={selectedRegion}
                onSelectApplication={(app) => {
                  setActiveTab('WORKFLOW');
                }}
              />
            )}

            {activeTab === 'EVC' && (
              <EvcQueue
                evcList={evcQueue}
                currentUserRole={currentRole}
                selectedRegion={selectedRegion}
                onAssignPanel={handleAssignPanel}
                onSubmitReport={handleSubmitEvcReport}
              />
            )}

            {activeTab === 'UNDERTAKINGS' && (
              <UndertakingsTracker
                undertakings={undertakings}
                currentUserRole={currentRole}
                currentSimulatedDate={simulatedDate}
                onVerifyUndertaking={handleVerifyUndertaking}
                onSubmitEvidence={handleSubmitEvidence}
              />
            )}

            {activeTab === 'DEADLINES' && (
              <DeadlineLedger
                deadlines={deadlines}
                institutions={institutions}
                currentSimulatedDate={simulatedDate}
                currentUserRole={currentRole}
                onResolveObligation={handleResolveObligation}
                onConfirmLeaseUpdate={handleConfirmLeaseUpdate}
              />
            )}

            {activeTab === 'ESCALATIONS' && (
              <EscalationMatrix
                deadlines={deadlines}
                applications={applications}
                onTriggerEscalationNotice={handleTriggerEscalationNotice}
              />
            )}

            {activeTab === 'REPORTS' && (
              <ReportsCenter
                applications={applications}
                deadlines={deadlines}
                evcQueue={evcQueue}
                undertakings={undertakings}
                auditLogs={auditLogs}
                currentSimulatedDate={simulatedDate}
              />
            )}

            {activeTab === 'AUDIT_LOG' && (
              <AuditLogChain
                auditLogs={auditLogs}
              />
            )}
          </>
        )}

      </main>

      {/* SAC Hearing Modal */}
      {activeSacHearing && (
        <SacHearingsModal
          hearing={activeSacHearing}
          application={applications.find(a => a.id === activeSacHearing.applicationId)}
          onClose={() => setActiveSacHearing(null)}
          onSubmitVerdict={handleSubmitSacVerdict}
        />
      )}

      {/* Official Government Footer */}
      <footer className="bg-[#0A192F] text-slate-400 border-t border-slate-800 text-xs py-5 mt-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="font-bold text-slate-200 text-sm tracking-wide">
              AICTE CHRONOS ENGINE
            </span>
            <span className="text-slate-600">|</span>
            <span>National Informatics Centre (NIC) Standards</span>
            <span className="text-slate-600">|</span>
            <span>Smart India Hackathon (SIH 2026)</span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span>Section 10(k), AICTE Act 1987</span>
            <span>•</span>
            <span>APH 2026-27 Compliant</span>
            <span>•</span>
            <span className="text-emerald-400 font-mono-code">SHA-256 Verified</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
