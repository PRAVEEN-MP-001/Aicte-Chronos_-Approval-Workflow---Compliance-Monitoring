# AICTE Chronos: Integrated Approval Workflow Automation, Compliance Monitoring and Alert Management System

> **Smart India Hackathon (SIH 2026)**  
> **Ministry of Education, Government of India • All India Council for Technical Education (AICTE)**  
> Built to **National Informatics Centre (NIC)** Digital Governance Standards & **Approval Process Handbook (APH 2026-27)**.

[![AICTE Standards](https://img.shields.io/badge/AICTE-APH%202026--27-0A192F?style=for-the-badge&logo=shield)](https://aicte-india.org)
[![Statutory Framework](https://img.shields.io/badge/Statutory%20Act-Section%2010(k)%20AICTE%20Act%201987-D97706?style=for-the-badge)](https://aicte-india.org)
[![Security Standard](https://img.shields.io/badge/Audit%20Integrity-SHA--256%20Hash%20Chained-16A34A?style=for-the-badge)](https://nic.in)
[![Legal Admissibility](https://img.shields.io/badge/Legal%20Admissibility-Section%2065B%20IEA%20/%20BSA%202023-1E3A8A?style=for-the-badge)](https://nic.in)

---

## 🏛️ Executive Summary

**AICTE Chronos** is an enterprise-grade digital governance and regulatory monitoring platform designed for the All India Council for Technical Education (AICTE). It automates complex institutional approval lifecycles, enforces statutory deadlines, schedules Expert Visit Committees (EVC), monitors time-bound compliance covenants, and provides tamper-evident audit trails.

### Core Value Proposition:
- **Zero Missed Statutory Deadlines**: Active countdown engines for mandatory 7-day appeals (APH 1.11a), 15-day Joint FDR security deposits (APH 2.25f), and land lease cushions (APH 2.1e/6.17a).
- **Non-Automated Statutory Decisions ("Human Gate")**: Strictly compliant with the **Section 10(k) AICTE Act 1987** advisory safeguard—algorithms extract data and flag deadlines, but all stage advancements and deficiency issuances require affirmative Officer digital signatures and justification remarks.
- **Cryptographic Non-Repudiation**: Every administrative observation, decision, and document upload is sealed into an immutable **SHA-256 hash chain** linked to an external anchor (*BharatNet / NIC National Blockchain Anchor*).
- **Time-Travel Simulation Engine**: An interactive, shiftable demo clock widget allowing hackathon evaluators to fast-forward time (+1, +7, +15, +30 days) to witness real-time statutory escalations, automated penalty realization, and overdue alerts.

---

## 📦 Functional Architecture (SIH Modules A to F)

### 🔹 Module A: End-to-End Approval Workflow Automation
- **Configurable Routing Patterns**:
  - `ONLY_SCRUTINY`: Fast-track processing for routine Extension of Approval (EoA) without changes.
  - `SCRUTINY_PLUS_EVC`: Routine scrutiny followed by physical campus inspection (e.g., Increase in Intake, Introduction of New Programs).
  - `EVC_PLUS_SAC`: On-site inspection followed by Standing Appellate Committee (SAC) hearings for contested findings.
  - `ONLY_EVC`: Targeted surprise inspections or campus closure verifications.
  - `FULL_APH`: End-to-end 5-stage pipeline for New Technical Campuses (LoA).
- **Stage Progression Engine**: Interactive lifecycle pipeline (`Submission` ➔ `Scrutiny` ➔ `EVC Inspection` ➔ `SAC / Bureau Approval` ➔ `LoA / EoA Issuance`).
- **Human-Gate Decision Interface**: Modals with mandatory reason/justification text, scrutiny checklist toggles, and officer employee credential validation.
- **Electronic Case Summaries**: Auto-generated statutory summary sheets evaluating cadre ratios, land norms, and financial endowments.

### 🔹 Module B: Integrated Dashboard & Ageing Monitor
- **Application Ageing Classification**:
  - 🟢 **Fast-Track Zone** ($< 7$ Days): Healthy movement within statutory limits.
  - 🟡 **Warning Window** ($8 - 15$ Days): Approaching statutory threshold; proactive officer pings.
  - 🔴 **SLA Overdue** ($> 15$ Days): Stage ceiling breached; triggers automated Bureau escalation.
- **Regional Office (RO) Scorecards**: Side-by-side performance comparison of all 7 Regional Offices (*Southern, Northern, Western, Eastern, South-Western, Central, North-Western*) tracking filing counts, clearance velocity, overdue rates, and compliance scores.
- **Stage Bottleneck Heatmap**: Empirical dwell-time analysis pinpointing procedural delays across the 5 processing stages.

### 🔹 Module C: EVC Scheduling & Automated Delay Alerts
- **Queue Management**: Segregated queues for scheduled visits, overdue visits, and pending panel assignments.
- **3-Member Committee Constitution**:
  - Panel Chairman (Senior IIT/NIT Professor or Director roster)
  - Member 1 (Subject Matter Technical / Industry Expert)
  - Member 2 (Architect / PWD Civil Infrastructure Specialist)
- **Inspection Findings Submission**: Recording physical inspection verdicts (*Recommended for Approval*, *Deficiencies Found*, *Surprise Re-Inspection Advised*).

### 🔹 Module D: Monitoring Time-Bound Undertakings & Compliance
- **Digital Covenant Ledger**: Tracks conditional approvals subject to undertakings:
  - Joint Fixed Deposit Receipt (FDR) undertakings (APH Clause 2.25f)
  - Faculty Cadre recruitment undertakings (APH Clause 6.1)
  - Building Occupancy Certificates (BCC) from Municipal Authorities (APH Clause 6.3)
  - Structural Stability & Fire Safety NOC renewals (APH Clause 6.14)
- **Online Evidence Submission & Officer Verification**: Institutions upload certified PDFs/stamped affidavits; authorized officers inspect seals, verify lock-in periods, and seal compliant records.

### 🔹 Module E: Lease & Document Validity Engine
- **Statutory Critical Date Formula (APH 2.1e / 6.17a)**:
  $$\text{Critical Date} = \text{Lease End Date} - \text{Duration of Longest Course (Years)}$$
  *Example*: A college running a 4-year B.Tech program whose registered lease expires on `2029-06-30` has a Critical Date of `2025-06-30`. In 2026, fresh admissions cannot be approved without a 30-year registered lease extension.
- **Intelligent Tesseract OCR Scanner**:
  - Upload or select sample deeds (*e.g., PSG Tech 1999–2029 deed, 2026–2056 supplemental extension, DTU government allotment deed*).
  - Neural text extraction showing Lessor, Lessee, Survey/Khasra numbers, Start/End dates, and confidence scores.
  - Mandatory Human-Gate verification before clock initiation.

### 🔹 Module F: Multi-Tiered Alert Ladder & Gazette Reporting
- **Automated Escalation Matrix**:
  - **Tier L1 (Regional Notice)**: Active during statutory grace period ($< 70\%$ of time ceiling); advisory pings to Principal & RO.
  - **Tier L2 (Bureau Escalation)**: Activated when clock exceeds $70\%$ or lease cushion is breached; freeze on portal modifications.
  - **Tier L3 (Statutory Penalty / Show Cause)**: Hard ceiling breached; automated summons for Standing Appellate Committee hearing and deposit forfeiture warnings.
- **Consolidated Gazette Reports**:
  - National Application Pendency & Ageing Ledger
  - Regional Office Processing Velocity & Scorecard
  - EVC Inspection Queue Gazette
  - Institutional Undertakings & Penalties Ledger
  - **Section 65B Electronic Evidence & SHA-256 Cryptographic Audit Certificate** (Printable & CSV Exportable).

---

## 🔒 Cryptographic Data Integrity Engine

Every transaction is cryptographically chained using the SHA-256 standard:

$$h(n) = \text{SHA-256}\Big(h(n-1) \;\parallel\; \text{JSON.stringify}(\text{event\_payload})\Big)$$

```
┌──────────────────────┐         ┌──────────────────────┐         ┌──────────────────────┐
│  Genesis Block #0    │         │     Block #1         │         │     Block #2 (Head)  │
│  Root Hash: e3b0c... ├────────►│  Prev: e3b0c...      ├────────►│  Prev: 8f41a...      │
│  State: Initialized  │         │  Hash: 8f41a...      │         │  Hash: c92d0...      │
└──────────────────────┘         └──────────────────────┘         └──────────┬───────────┘
                                                                             │
                                                                   External Anchor:
                                                                BharatNet Ledger Anchor
                                                                    #2026-HQ-AICTE
```

- **Interactive Verification**: The built-in "Verify Cryptographic Chain Integrity" engine recalculates all hashes from Genesis (Block #0) to the current Head Block, ensuring 100% tamper resistance.

---

## 👥 Role-Based Portals (RBAC)

Use the top **Role Switcher** dropdown to navigate through all 5 organizational views:

1. **Institution View (SARA / PSG Tech College Portal)**:
   - View real-time approval status (`AICTE-SR-2026-90412`).
   - Warning banner for lease cushion breach with direct **OCR Supplemental Lease Upload**.
   - Deficiency clarification submission interface.
2. **Regional Office (RO) View**:
   - Filter cases by region (*Southern, Northern, Western, etc.*).
   - Scrutiny desks, EVC dispatch triggers, and regional ageing monitors.
3. **AICTE Bureau Officer View**:
   - HQ Approval Cell workflow gates, scrutiny checklist verifications, and deficiency issuance.
4. **EVC Convener / Committee Member View**:
   - On-site inspection queues, panel constitution, and report findings submission.
5. **AICTE HQ / Executive View**:
   - High-level national pendency analytics, SLA bottleneck heatmaps, and blockchain audit chain verification.

---

## ⚡ Statutory Penalty Calculations (APH Clause 2.25f)

For institutional security deposit FDRs:
- **Days 0 to 15**: Statutory Grace Window (0% penalty)
- **Days 16 to 30**: L1 Violation $\rightarrow$ **10% Penalty** levied on base deposit
  - *Example*: ₹15,00,000 base deposit $\rightarrow$ **₹1,50,000 penalty**
- **Days 31+**: L3 Hard Default $\rightarrow$ **20% Penalty** + Formal Show-Cause Notice
  - *Example*: ₹15,00,000 base deposit $\rightarrow$ **₹3,00,000 penalty**

---

## 🧪 Quick Demo Walkthrough Guide for Evaluators

1. **Test the Lease Expiry Cushion (Module D & E)**:
   - Select **Institution View** (PSG College of Technology).
   - Notice the prominent critical alert: Lease ends in 2029 for a 4-year course; Critical Date was 2025.
   - Click **"Upload Registered Extension (OCR)"**.
   - Select `PSG_Tech_Supplemental_Lease_Extension_2026_2056.pdf`.
   - Click **"Execute Tesseract OCR Scan"** and review extracted dates.
   - Affirm statutory checkbox and click **"Confirm & Inscribe to Chronos Ledger"**.
   - Notice the alert resolve instantly and log Block #3 in the Audit Chain!

2. **Test Time Travel & Fast-Forward Clocks (Module F)**:
   - In the top bar, click **"+7 Days (Appeal Limit)"**:
     - Delhi Technological University's (DTU) 7-day appeal clock expires $\rightarrow$ triggers **L3 Hard Breach**.
   - Click **"+15 Days (10% Penalty)"**:
     - VJTI's FDR deposit clock exceeds 15 days $\rightarrow$ automatic **10% penalty (₹1,50,000)** is calculated.
   - Click **"+30 Days (20% Hard Breach)"**:
     - Penalty escalates to **20% (₹3,00,000)** and Show-Cause notice is generated.

3. **Test Officer Human-Gate Decisions (Module A)**:
   - Switch role to **Bureau Officer**.
   - Open **Workflow & Human Gate** tab.
   - Click **"Human Gate"** on DTU or Jadavpur University.
   - Select **Advance Stage**, enter mandatory officer remarks, check the statutory affirmation, and inscribe into the ledger.

4. **Convene a Standing Appellate Committee (SAC) Hearing**:
   - In the top navigation bar, click **"Convene SAC Hearing"**.
   - Inspect the appellate bench (Retired High Court Judge Chairman, NBA Member, AICTE Member Secretary).
   - Select verdict (*Conditional Approval with Undertaking*), enter minutes, and seal the verdict.

5. **Verify Cryptographic Chain Integrity**:
   - Navigate to the **Audit Ledger** tab.
   - Click **"Verify Cryptographic Chain Integrity"**.
   - Observe the green certificate banner confirming 100% mathematical integrity from Block #0 to Head.

6. **Generate Official Gazette Reports**:
   - Navigate to the **Gazette Reports** tab.
   - Toggle between Pendency, Regional Scorecards, EVC Roster, and the **Section 65B Electronic Evidence Certificate**.
   - Click **"Export CSV"** or **"Print Gazette Report"**.

---

## 🛠️ Technology Stack & Dependencies

- **Frontend Core**: React 19, TypeScript, Vite
- **Styling & Design System**: Tailwind CSS v4, Custom NIC & AICTE official typography (Plus Jakarta Sans, Cinzel, JetBrains Mono)
- **Icons**: Lucide React
- **Cryptography**: Native Web Crypto API & Synchronous SHA-256 engine for instant block chaining
- **Server / Backend Runtime**: Express.js with Vite middleware support

---

## 🚀 Local Development Setup

### Prerequisites
- Node.js (v18.0.0 or higher)
- npm (v9.0.0 or higher)

### Installation
```bash
# Clone or navigate to the project directory
cd aicte-chronos

# Install dependencies
npm install

# Start development server on port 3000
npm run dev
```

### Production Build
```bash
# Compile and create production bundle
npm run build

# Preview production build
npm run preview
```

---

## 📜 Regulatory Safeguard Notice

> **ADVISORY ONLY**: In compliance with Section 10(k) of the AICTE Act 1987 and the Approval Process Handbook (APH 2026-27), automated algorithms, OCR extraction, and deadline countdowns provide advisory alerts and calculations. No statutory decision, approval order, deficiency notice, or penalty forfeiture is automated without affirmative Officer digital sign-off and recorded administrative justification.
